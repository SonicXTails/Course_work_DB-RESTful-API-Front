--
-- PostgreSQL database dump
--

-- Dumped from database version 16.0
-- Dumped by pg_dump version 16.0

SET statement_timeout = 0;
SET lock_timeout = 0;
SET idle_in_transaction_session_timeout = 0;
SET client_encoding = 'UTF8';
SET standard_conforming_strings = on;
SELECT pg_catalog.set_config('search_path', '', false);
SET check_function_bodies = false;
SET xmloption = content;
SET client_min_messages = warning;
SET row_security = off;

--
-- Name: hstore; Type: EXTENSION; Schema: -; Owner: -
--

CREATE EXTENSION IF NOT EXISTS hstore WITH SCHEMA public;


--
-- Name: EXTENSION hstore; Type: COMMENT; Schema: -; Owner: -
--

COMMENT ON EXTENSION hstore IS 'data type for storing sets of (key, value) pairs';


--
-- Name: audit_row(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.audit_row() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE rec_id text;
BEGIN
  -- Универсально вынимаем PK: сначала id, если нет — VIN (для core_car)
  rec_id := COALESCE(
              (to_jsonb(NEW)->>'id'),
              (to_jsonb(OLD)->>'id'),
              (to_jsonb(NEW)->>'VIN'),
              (to_jsonb(OLD)->>'VIN')
           );

  INSERT INTO core_auditlog(user_id, action, table_name, record_id, old_data, new_data, action_time)
  VALUES (NULL, TG_OP, TG_TABLE_NAME, rec_id, to_jsonb(OLD), to_jsonb(NEW), now());
  RETURN COALESCE(NEW, OLD);
END; $$;


--
-- Name: sp_bulk_reprice(integer, numeric); Type: PROCEDURE; Schema: public; Owner: -
--

CREATE PROCEDURE public.sp_bulk_reprice(IN p_make_id integer, IN p_percent numeric)
    LANGUAGE plpgsql
    AS $$
BEGIN
  UPDATE core_car
  SET price = ROUND(price * (1 + p_percent/100.0), 2)
  WHERE make_id = p_make_id AND status IN ('available','reserved');
END;
$$;


--
-- Name: sp_cancel_reservation(integer, text); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.sp_cancel_reservation(p_order_id integer, p_reason text DEFAULT NULL::text) RETURNS void
    LANGUAGE plpgsql
    AS $$
DECLARE v_car_vin VARCHAR;
BEGIN
SELECT car_id INTO v_car_vin FROM core_order WHERE id = p_order_id FOR UPDATE;
IF NOT FOUND THEN RAISE EXCEPTION 'ORDER_NOT_FOUND' USING HINT='Заказ не найден'; END IF;


PERFORM 1 FROM core_order WHERE id = p_order_id AND status = 'pending';
IF NOT FOUND THEN RAISE EXCEPTION 'ORDER_INVALID_STATE' USING HINT='Отменять можно только pending'; END IF;


UPDATE core_order SET status='cancelled' WHERE id = p_order_id;
UPDATE core_car SET status='available' WHERE "VIN" = v_car_vin;
END; $$;


--
-- Name: sp_complete_sale(integer); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.sp_complete_sale(p_order_id integer) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE v_tx_id INT; v_car_vin VARCHAR; v_amount NUMERIC;
BEGIN
  SELECT car_id, total_amount INTO v_car_vin, v_amount FROM core_order WHERE id=p_order_id FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'ORDER_NOT_FOUND'; END IF;

  PERFORM 1 FROM core_order WHERE id=p_order_id AND status='pending';
  IF NOT FOUND THEN RAISE EXCEPTION 'ORDER_INVALID_STATE' USING HINT='Продажа возможна только из pending'; END IF;

  INSERT INTO core_transaction(order_id, amount, transaction_date, status)
  VALUES(p_order_id, v_amount, now(), 'completed')
  RETURNING id INTO v_tx_id;

  UPDATE core_order SET status='paid' WHERE id=p_order_id;
  UPDATE core_car   SET status='sold' WHERE "VIN"=v_car_vin;

  RETURN v_tx_id;
END;
$$;


--
-- Name: sp_reserve_car(integer, character varying); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.sp_reserve_car(p_user_id integer, p_car_vin character varying) RETURNS integer
    LANGUAGE plpgsql
    AS $$
DECLARE v_order_id INT; v_price NUMERIC;
BEGIN
  PERFORM 1 FROM core_car WHERE "VIN"=p_car_vin AND status='available' FOR UPDATE;
  IF NOT FOUND THEN RAISE EXCEPTION 'CAR_NOT_AVAILABLE' USING HINT='Авто недоступно'; END IF;

  SELECT price INTO v_price FROM core_car WHERE "VIN"=p_car_vin;
  INSERT INTO core_order(buyer_id, car_id, status, order_date, total_amount)
  VALUES(p_user_id, p_car_vin, 'pending', now(), v_price)
  RETURNING id INTO v_order_id;

  UPDATE core_car SET status='reserved' WHERE "VIN"=p_car_vin;
  RETURN v_order_id;
END;
$$;


--
-- Name: trg_validate_tx(); Type: FUNCTION; Schema: public; Owner: -
--

CREATE FUNCTION public.trg_validate_tx() RETURNS trigger
    LANGUAGE plpgsql
    AS $$
DECLARE v_order_status TEXT;
BEGIN
  SELECT status INTO v_order_status FROM core_order WHERE id = NEW.order_id;
  IF v_order_status <> 'pending' THEN
    RAISE EXCEPTION 'ORDER_INVALID_STATE' USING HINT='Транзакцию можно создать только из pending';
  END IF;
  RETURN NEW;
END; $$;


SET default_tablespace = '';

SET default_table_access_method = heap;

--
-- Name: auth_group; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_group (
    id integer NOT NULL,
    name character varying(150) NOT NULL
);


--
-- Name: auth_group_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.auth_group ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_group_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_group_permissions (
    id bigint NOT NULL,
    group_id integer NOT NULL,
    permission_id integer NOT NULL
);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.auth_group_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_group_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: auth_permission; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.auth_permission (
    id integer NOT NULL,
    name character varying(255) NOT NULL,
    content_type_id integer NOT NULL,
    codename character varying(100) NOT NULL
);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.auth_permission ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.auth_permission_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: authtoken_token; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.authtoken_token (
    key character varying(40) NOT NULL,
    created timestamp with time zone NOT NULL,
    user_id bigint NOT NULL
);


--
-- Name: core_auditlog; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.core_auditlog (
    id bigint NOT NULL,
    action character varying(100) NOT NULL,
    table_name character varying(50) NOT NULL,
    record_id character varying(255),
    old_data jsonb,
    new_data jsonb,
    action_time timestamp with time zone NOT NULL,
    user_id bigint,
    actor_label character varying(150)
);


--
-- Name: core_auditlog_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.core_auditlog ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_auditlog_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_backupconfig; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.core_backupconfig (
    id smallint NOT NULL,
    last_run_at timestamp with time zone,
    CONSTRAINT core_backupconfig_id_check CHECK ((id >= 0))
);


--
-- Name: core_backupfile; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.core_backupfile (
    id bigint NOT NULL,
    created_at timestamp with time zone NOT NULL,
    method character varying(16) NOT NULL,
    status character varying(16) NOT NULL,
    file_path character varying(512) NOT NULL,
    file_size bigint NOT NULL,
    checksum_sha256 character varying(64) NOT NULL,
    log text NOT NULL,
    created_by_id bigint
);


--
-- Name: core_backupfile_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.core_backupfile ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_backupfile_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_car; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.core_car (
    "VIN" character varying(17) NOT NULL,
    year integer NOT NULL,
    price numeric(12,2) NOT NULL,
    status character varying(20) NOT NULL,
    description text NOT NULL,
    created_at timestamp with time zone NOT NULL,
    seller_id bigint,
    make_id bigint NOT NULL,
    model_id bigint NOT NULL
);


--
-- Name: core_carimage; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.core_carimage (
    id bigint NOT NULL,
    image character varying(100) NOT NULL,
    car_id character varying(17) NOT NULL
);


--
-- Name: core_carimage_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.core_carimage ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_carimage_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_make; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.core_make (
    id bigint NOT NULL,
    name character varying(50) NOT NULL
);


--
-- Name: core_make_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.core_make ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_make_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_model; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.core_model (
    id bigint NOT NULL,
    name character varying(50) NOT NULL,
    make_id bigint NOT NULL
);


--
-- Name: core_model_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.core_model ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_model_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_order; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.core_order (
    id bigint NOT NULL,
    order_date timestamp with time zone NOT NULL,
    status character varying(20) NOT NULL,
    total_amount numeric(12,2) NOT NULL,
    buyer_id bigint,
    car_id character varying(17) NOT NULL
);


--
-- Name: core_order_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.core_order ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_order_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_review; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.core_review (
    id bigint NOT NULL,
    rating smallint NOT NULL,
    comment text,
    created_at timestamp with time zone NOT NULL,
    author_id bigint NOT NULL,
    target_id bigint NOT NULL,
    CONSTRAINT core_review_rating_check CHECK ((rating >= 0))
);


--
-- Name: core_review_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.core_review ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_review_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_role; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.core_role (
    id bigint NOT NULL,
    name character varying(50) NOT NULL
);


--
-- Name: core_role_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.core_role ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_role_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_transaction; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.core_transaction (
    id bigint NOT NULL,
    amount numeric(12,2) NOT NULL,
    transaction_date timestamp with time zone NOT NULL,
    status character varying(20) NOT NULL,
    order_id bigint NOT NULL
);


--
-- Name: core_transaction_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.core_transaction ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_transaction_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_user; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.core_user (
    id bigint NOT NULL,
    password character varying(128) NOT NULL,
    last_login timestamp with time zone,
    is_superuser boolean NOT NULL,
    username character varying(150) NOT NULL,
    first_name character varying(150) NOT NULL,
    last_name character varying(150) NOT NULL,
    email character varying(254) NOT NULL,
    is_staff boolean NOT NULL,
    is_active boolean NOT NULL,
    date_joined timestamp with time zone NOT NULL
);


--
-- Name: core_user_groups; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.core_user_groups (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    group_id integer NOT NULL
);


--
-- Name: core_user_groups_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.core_user_groups ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_user_groups_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_user_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.core_user ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_user_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_user_user_permissions; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.core_user_user_permissions (
    id bigint NOT NULL,
    user_id bigint NOT NULL,
    permission_id integer NOT NULL
);


--
-- Name: core_user_user_permissions_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.core_user_user_permissions ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_user_user_permissions_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_userprofile; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.core_userprofile (
    id bigint NOT NULL,
    phone_masked character varying(32) NOT NULL,
    user_id bigint NOT NULL
);


--
-- Name: core_userprofile_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.core_userprofile ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_userprofile_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_userrole; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.core_userrole (
    id bigint NOT NULL,
    role_id bigint NOT NULL,
    user_id bigint NOT NULL
);


--
-- Name: core_userrole_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.core_userrole ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_userrole_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: core_usersettings; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.core_usersettings (
    id bigint NOT NULL,
    theme character varying(10) NOT NULL,
    date_format character varying(12) NOT NULL,
    number_format character varying(12) NOT NULL,
    page_size smallint NOT NULL,
    saved_filters jsonb NOT NULL,
    created_at timestamp with time zone NOT NULL,
    updated_at timestamp with time zone NOT NULL,
    user_id bigint NOT NULL,
    CONSTRAINT core_usersettings_page_size_check CHECK ((page_size >= 0)),
    CONSTRAINT usersettings_page_size_range CHECK (((page_size >= 5) AND (page_size <= 200)))
);


--
-- Name: core_usersettings_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.core_usersettings ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.core_usersettings_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_admin_log; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_admin_log (
    id integer NOT NULL,
    action_time timestamp with time zone NOT NULL,
    object_id text,
    object_repr character varying(200) NOT NULL,
    action_flag smallint NOT NULL,
    change_message text NOT NULL,
    content_type_id integer,
    user_id bigint NOT NULL,
    CONSTRAINT django_admin_log_action_flag_check CHECK ((action_flag >= 0))
);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.django_admin_log ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_admin_log_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_content_type; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_content_type (
    id integer NOT NULL,
    app_label character varying(100) NOT NULL,
    model character varying(100) NOT NULL
);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.django_content_type ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_content_type_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_migrations; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_migrations (
    id bigint NOT NULL,
    app character varying(255) NOT NULL,
    name character varying(255) NOT NULL,
    applied timestamp with time zone NOT NULL
);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE; Schema: public; Owner: -
--

ALTER TABLE public.django_migrations ALTER COLUMN id ADD GENERATED BY DEFAULT AS IDENTITY (
    SEQUENCE NAME public.django_migrations_id_seq
    START WITH 1
    INCREMENT BY 1
    NO MINVALUE
    NO MAXVALUE
    CACHE 1
);


--
-- Name: django_session; Type: TABLE; Schema: public; Owner: -
--

CREATE TABLE public.django_session (
    session_key character varying(40) NOT NULL,
    session_data text NOT NULL,
    expire_date timestamp with time zone NOT NULL
);


--
-- Name: vw_active_listings; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.vw_active_listings AS
 SELECT c."VIN" AS vin,
    m.name AS make,
    md.name AS model,
    c.price,
    c.year,
    c.status,
    c.created_at
   FROM ((public.core_car c
     JOIN public.core_make m ON ((m.id = c.make_id)))
     JOIN public.core_model md ON ((md.id = c.model_id)))
  WHERE ((c.status)::text = 'available'::text);


--
-- Name: vw_sales_by_make_month; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.vw_sales_by_make_month AS
 SELECT m.name AS make,
    date_trunc('month'::text, t.transaction_date) AS month,
    count(*) AS deals,
    sum(t.amount) AS revenue
   FROM (((public.core_transaction t
     JOIN public.core_order o ON ((o.id = t.order_id)))
     JOIN public.core_car c ON (((c."VIN")::text = (o.car_id)::text)))
     JOIN public.core_make m ON ((m.id = c.make_id)))
  WHERE ((t.status)::text = 'completed'::text)
  GROUP BY m.name, (date_trunc('month'::text, t.transaction_date));


--
-- Name: vw_user_activity; Type: VIEW; Schema: public; Owner: -
--

CREATE VIEW public.vw_user_activity AS
 SELECT u.id AS user_id,
    u.username,
    count(DISTINCT o.id) AS orders_cnt,
    count(DISTINCT t.id) AS tx_cnt
   FROM ((public.core_user u
     LEFT JOIN public.core_order o ON ((o.buyer_id = u.id)))
     LEFT JOIN public.core_transaction t ON (((t.order_id = o.id) AND ((t.status)::text = 'completed'::text))))
  GROUP BY u.id, u.username;


--
-- Data for Name: auth_group; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_group (id, name) FROM stdin;
\.


--
-- Data for Name: auth_group_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_group_permissions (id, group_id, permission_id) FROM stdin;
\.


--
-- Data for Name: auth_permission; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.auth_permission (id, name, content_type_id, codename) FROM stdin;
1	Can add log entry	1	add_logentry
2	Can change log entry	1	change_logentry
3	Can delete log entry	1	delete_logentry
4	Can view log entry	1	view_logentry
5	Can add permission	2	add_permission
6	Can change permission	2	change_permission
7	Can delete permission	2	delete_permission
8	Can view permission	2	view_permission
9	Can add group	3	add_group
10	Can change group	3	change_group
11	Can delete group	3	delete_group
12	Can view group	3	view_group
13	Can add content type	4	add_contenttype
14	Can change content type	4	change_contenttype
15	Can delete content type	4	delete_contenttype
16	Can view content type	4	view_contenttype
17	Can add session	5	add_session
18	Can change session	5	change_session
19	Can delete session	5	delete_session
20	Can view session	5	view_session
21	Can add make	6	add_make
22	Can change make	6	change_make
23	Can delete make	6	delete_make
24	Can view make	6	view_make
25	Can add role	7	add_role
26	Can change role	7	change_role
27	Can delete role	7	delete_role
28	Can view role	7	view_role
29	Can add user	8	add_user
30	Can change user	8	change_user
31	Can delete user	8	delete_user
32	Can view user	8	view_user
33	Can add audit log	9	add_auditlog
34	Can change audit log	9	change_auditlog
35	Can delete audit log	9	delete_auditlog
36	Can view audit log	9	view_auditlog
37	Can add car	10	add_car
38	Can change car	10	change_car
39	Can delete car	10	delete_car
40	Can view car	10	view_car
41	Can add car image	11	add_carimage
42	Can change car image	11	change_carimage
43	Can delete car image	11	delete_carimage
44	Can view car image	11	view_carimage
45	Can add model	12	add_model
46	Can change model	12	change_model
47	Can delete model	12	delete_model
48	Can view model	12	view_model
49	Can add order	13	add_order
50	Can change order	13	change_order
51	Can delete order	13	delete_order
52	Can view order	13	view_order
53	Can add transaction	14	add_transaction
54	Can change transaction	14	change_transaction
55	Can delete transaction	14	delete_transaction
56	Can view transaction	14	view_transaction
57	Can add user role	15	add_userrole
58	Can change user role	15	change_userrole
59	Can delete user role	15	delete_userrole
60	Can view user role	15	view_userrole
61	Can add review	16	add_review
62	Can change review	16	change_review
63	Can delete review	16	delete_review
64	Can view review	16	view_review
65	Can add Token	17	add_token
66	Can change Token	17	change_token
67	Can delete Token	17	delete_token
68	Can view Token	17	view_token
69	Can add Token	18	add_tokenproxy
70	Can change Token	18	change_tokenproxy
71	Can delete Token	18	delete_tokenproxy
72	Can view Token	18	view_tokenproxy
73	Can add user profile	19	add_userprofile
74	Can change user profile	19	change_userprofile
75	Can delete user profile	19	delete_userprofile
76	Can view user profile	19	view_userprofile
77	Can add user settings	20	add_usersettings
78	Can change user settings	20	change_usersettings
79	Can delete user settings	20	delete_usersettings
80	Can view user settings	20	view_usersettings
81	Can add backup file	21	add_backupfile
82	Can change backup file	21	change_backupfile
83	Can delete backup file	21	delete_backupfile
84	Can view backup file	21	view_backupfile
85	Can add Настройки бэкапов	22	add_backupconfig
86	Can change Настройки бэкапов	22	change_backupconfig
87	Can delete Настройки бэкапов	22	delete_backupconfig
88	Can view Настройки бэкапов	22	view_backupconfig
\.


--
-- Data for Name: authtoken_token; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.authtoken_token (key, created, user_id) FROM stdin;
a9c6efc4352be525c5370a3bdccf5740d12575a7	2025-09-17 20:46:18.884506+03	37
9723a7119b5ee10caa48b114b41841d8a1ac95c0	2025-09-18 14:13:00.208015+03	21
f0db1b72bd7988fa4747d075237b18c2d5eaa080	2025-09-22 18:57:10.342644+03	22
922a6be6f8688dff9c30acddb71dba7442acd3f1	2025-09-22 18:57:58.117279+03	13
6b9a2abde4bf4e5d08d68c2232374fe0aac40970	2025-09-22 21:12:49.495174+03	38
a00e2c459bee1abbe0c8e8b06e6630ff65b9c5b5	2025-09-22 22:09:43.149022+03	18
44eb7f45f879cb1cb3f68e5d9ef4008f14ad5609	2025-09-24 12:03:09.107943+03	39
adb127b6f5013ac83c57c79e554537cb43defd98	2025-09-24 12:03:33.500947+03	40
a7c578621e901087b591637abcf3c63990c9e3de	2025-09-24 21:39:08.867608+03	41
a3c4330011e532a3e3ddf8e8cb3482226529ca9c	2025-09-24 21:42:42.62304+03	42
5724fe94c72d97c820db033bd4310845d0909f1a	2025-09-24 22:01:00.675554+03	23
\.


--
-- Data for Name: core_auditlog; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.core_auditlog (id, action, table_name, record_id, old_data, new_data, action_time, user_id, actor_label) FROM stdin;
1	CREATE	Role	4	\N	{"id": 4, "name": "LOSE"}	2025-09-12 14:17:26.390937+03	\N	\N
2	CREATE	User	6	\N	{"id": 6, "email": "userNEW@example.com", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$s58lGOn3RvBJw4NTMhFx1M$DGlBq3qSuaaX/8P7Z1vmNrle/whzx/PL9Go9Xd5v0S0=", "username": "gmakzeBDPB6M84", "is_active": true, "last_name": "Чистотин", "first_name": "Михаил", "last_login": null, "date_joined": "2025-09-12T11:21:01.360835+00:00", "is_superuser": false, "user_permissions": []}	2025-09-12 14:21:02.556411+03	\N	\N
3	CREATE	User	9	\N	{"id": 9, "email": "user@example.com", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$yq2cnAKATPoh2vtgV0TbnU$WlArMJ7W/cd9dX/Ehez9DkIiUESxzzB88VUCcJCVd2M=", "username": "CRtywv9nrMhWdkIZTboiCva9lVjEFE123Gzq0hoHWch7cK7psGNMRyHclqX3B_EMqBGPg58jBMS_kDNLuj47iue8oV", "is_active": true, "last_name": "Дщыук", "first_name": "фывфыв", "last_login": null, "date_joined": "2025-09-12T11:42:23.609754+00:00", "is_superuser": false, "user_permissions": []}	2025-09-12 14:42:24.38003+03	\N	\N
4	DELETE	User	4	{"id": 4, "email": "user123@example.com", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$t3JtSzjylTGOzrXNwtySBT$12QDvOfMfz8rRWsge5QbVhVdIBVFtqfuZbZ3SRg5Js4=", "username": "ABBA3ABBA", "is_active": true, "last_name": "Losd", "first_name": "Okkd", "last_login": null, "date_joined": "2025-09-12T11:16:58.572478+00:00", "is_superuser": false, "user_permissions": []}	\N	2025-09-12 14:50:18.971914+03	\N	\N
5	UPDATE	User	2	{"id": 2, "email": "u3@example.com", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$n0mS4eWgqcSYGLwVg3lrd6$RqN21Qb4Rg88Iy3hBjdbrMDeks31SLzj9qeFG6TKV2g=", "username": "jdfhksdjn", "is_active": true, "last_name": "LOser", "first_name": "LOser", "last_login": null, "date_joined": "2025-09-12T11:04:10.153506+00:00", "is_superuser": false, "user_permissions": []}	{"id": 2, "email": "u3@example.com", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$n0mS4eWgqcSYGLwVg3lrd6$RqN21Qb4Rg88Iy3hBjdbrMDeks31SLzj9qeFG6TKV2g=", "username": "jdfhksdjn123123", "is_active": true, "last_name": "LOser", "first_name": "LOser", "last_login": null, "date_joined": "2025-09-12T11:04:10.153506+00:00", "is_superuser": false, "user_permissions": []}	2025-09-12 14:53:01.152219+03	\N	\N
6	DELETE	Review	1	{"id": 1, "author": 1, "rating": 5, "target": 2, "comment": "123"}	\N	2025-09-12 14:53:20.25465+03	\N	\N
7	DELETE	User	2	{"id": 2, "email": "u3@example.com", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$n0mS4eWgqcSYGLwVg3lrd6$RqN21Qb4Rg88Iy3hBjdbrMDeks31SLzj9qeFG6TKV2g=", "username": "jdfhksdjn123123", "is_active": true, "last_name": "LOser", "first_name": "LOser", "last_login": null, "date_joined": "2025-09-12T11:04:10.153506+00:00", "is_superuser": false, "user_permissions": []}	\N	2025-09-12 14:53:20.265135+03	\N	\N
8	CREATE	User	10	\N	{"id": 10, "email": "user@example.com", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$bhdvUISyvEOsVNXPuFSr9C$8htcchU7zQ4eNjj3pMwZL5ZcaDVoCN+jqTrgLr6eU3A=", "username": "FrontCheck", "is_active": true, "last_name": "Yeap", "first_name": "Loser", "last_login": null, "date_joined": "2025-09-12T12:57:40.875148+00:00", "is_superuser": false, "user_permissions": []}	2025-09-12 15:57:41.663818+03	\N	\N
9	DELETE	User	10	{"id": 10, "email": "user@example.com", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$bhdvUISyvEOsVNXPuFSr9C$8htcchU7zQ4eNjj3pMwZL5ZcaDVoCN+jqTrgLr6eU3A=", "username": "FrontCheck", "is_active": true, "last_name": "Yeap", "first_name": "Loser", "last_login": null, "date_joined": "2025-09-12T12:57:40.875148+00:00", "is_superuser": false, "user_permissions": []}	\N	2025-09-12 16:05:12.302003+03	\N	\N
10	CREATE	User	11	\N	{"id": 11, "email": "user@example.com", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$3BRTw6oTIseXo9oJwNeYxx$jkHiapXFwr89d+mRs5i57cEgWxflicquhdO2R9h2WWc=", "username": "FrontCheck", "is_active": true, "last_name": "Yeap", "first_name": "Loser", "last_login": null, "date_joined": "2025-09-12T13:05:31.661223+00:00", "is_superuser": false, "user_permissions": []}	2025-09-12 16:05:32.52834+03	\N	\N
11	DELETE	User	11	{"id": 11, "email": "user@example.com", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$3BRTw6oTIseXo9oJwNeYxx$jkHiapXFwr89d+mRs5i57cEgWxflicquhdO2R9h2WWc=", "username": "FrontCheck", "is_active": true, "last_name": "Yeap", "first_name": "Loser", "last_login": null, "date_joined": "2025-09-12T13:05:31.661223+00:00", "is_superuser": false, "user_permissions": []}	\N	2025-09-12 16:05:49.7957+03	\N	\N
12	CREATE	User	12	\N	{"id": 12, "email": "user@example.com", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$3xzzTLaUh8INGCqULuAgIM$Y4wQUWKwmrRF59D9SLo3ILYof1GKTZbB5i8z+mOyQxs=", "username": "FrontCheck", "is_active": true, "last_name": "Yeap", "first_name": "Loser", "last_login": null, "date_joined": "2025-09-12T13:11:55.720684+00:00", "is_superuser": false, "user_permissions": []}	2025-09-12 16:11:56.949196+03	\N	\N
13	CREATE	User	13	\N	{"id": 13, "email": "aedgy.master@mail.ru", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$zKeOYlkQpxN9uEXDTBMLqk$qW7+kFPI5zuOjHhVC3ewCpJiuuaxqAXGDiCzg0XDSdg=", "username": "NewUser", "is_active": true, "last_name": "Чистотин", "first_name": "Михаил", "last_login": null, "date_joined": "2025-09-12T13:25:31.885224+00:00", "is_superuser": false, "user_permissions": []}	2025-09-12 16:25:32.628092+03	\N	\N
14	CREATE	User	14	\N	{"id": 14, "email": "aedgy.master@mail.ru", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$FuTHs0akImNwopn0RTvPMT$jWzADuxawt0gCPi4HJaf1IoqfBTxbVDyDtHdzMpDWqg=", "username": "NewUserAfterRework", "is_active": true, "last_name": "Чистотин", "first_name": "Михаил", "last_login": null, "date_joined": "2025-09-14T10:24:26.243824+00:00", "is_superuser": false, "user_permissions": []}	2025-09-14 13:24:26.951276+03	\N	\N
15	CREATE	User	15	\N	{"id": 15, "email": "aedgy.mastersd@mail.ru", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$0GiAh5ctupOTvMfqXEitXD$O3dFd5lyiQq2vGlaHL/tMp8KxNWAAMPVHiorj9RoYwc=", "username": "NewUserAfterRework2", "is_active": true, "last_name": "123", "first_name": "123", "last_login": null, "date_joined": "2025-09-14T10:38:19.122543+00:00", "is_superuser": false, "user_permissions": []}	2025-09-14 13:38:20.070952+03	\N	\N
16	CREATE	User	16	\N	{"id": 16, "email": "aedgy.mastersd123123@mail.ru", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$i01xV2zQMiii7c1m77dVYu$ruUXToPGCdY7cQMaR0KaSBXkf7/nH7Knz79Ho4CFK0s=", "username": "NewUserAfterRework23", "is_active": true, "last_name": "123321", "first_name": "123321", "last_login": null, "date_joined": "2025-09-14T10:50:13.279934+00:00", "is_superuser": false, "user_permissions": []}	2025-09-14 13:50:13.973603+03	\N	\N
17	CREATE	UserRole	2	\N	{"id": 2, "role": 3, "user": 16}	2025-09-14 13:50:13.981991+03	\N	\N
18	CREATE	User	17	\N	{"id": 17, "email": "user@example.com", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$XhAhyBXhFwyoUKfl7psXDS$0GmZhtDRCzt3yj3x9bgnDWOE0daKD7RT4bVMxcRkWxQ=", "username": "NewUserTest", "is_active": true, "last_name": "NewUserTest", "first_name": "NewUserTest", "last_login": null, "date_joined": "2025-09-14T12:25:16.174865+00:00", "is_superuser": false, "user_permissions": []}	2025-09-14 15:25:16.877683+03	\N	\N
19	CREATE	UserRole	3	\N	{"id": 3, "role": 3, "user": 17}	2025-09-14 15:25:16.887738+03	\N	\N
20	CREATE	UserRole	4	\N	{"id": 4, "role": 4, "user": 12}	2025-09-14 15:40:21.245959+03	\N	\N
21	CREATE	UserRole	5	\N	{"id": 5, "role": 2, "user": 17}	2025-09-14 15:40:29.403195+03	\N	\N
22	CREATE	UserRole	6	\N	{"id": 6, "role": 2, "user": 14}	2025-09-14 15:45:49.819944+03	\N	\N
23	CREATE	UserRole	7	\N	{"id": 7, "role": 2, "user": 17}	2025-09-14 16:50:55.703088+03	\N	\N
24	CREATE	UserRole	8	\N	{"id": 8, "role": 2, "user": 17}	2025-09-14 16:50:57.076325+03	\N	\N
25	CREATE	UserRole	9	\N	{"id": 9, "role": 2, "user": 17}	2025-09-14 16:50:57.836934+03	\N	\N
26	CREATE	UserRole	10	\N	{"id": 10, "role": 1, "user": 1}	2025-09-14 17:05:06.118423+03	\N	\N
27	CREATE	UserRole	11	\N	{"id": 11, "role": 1, "user": 1}	2025-09-14 17:05:11.113053+03	\N	\N
28	CREATE	User	18	\N	{"id": 18, "email": "My@mail.ru", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$9QZJzKkY9fPttRRb53Inwk$7qMtIu194lUb/e4rOzINAmA/1IBLT6SLOAGV4g+d+kM=", "username": "My", "is_active": true, "last_name": "3123123123", "first_name": "12312312", "last_login": null, "date_joined": "2025-09-14T14:29:40.881177+00:00", "is_superuser": false, "user_permissions": []}	2025-09-14 17:29:41.541707+03	\N	\N
29	CREATE	UserRole	12	\N	{"id": 12, "role": 3, "user": 18}	2025-09-14 17:29:41.550063+03	\N	\N
30	CREATE	UserRole	13	\N	{"id": 13, "role": 1, "user": 18}	2025-09-14 17:32:12.897626+03	\N	\N
31	CREATE	UserRole	14	\N	{"id": 14, "role": 2, "user": 18}	2025-09-14 17:38:05.085133+03	\N	незнакомец
32	CREATE	UserRole	15	\N	{"id": 15, "role": 1, "user": 1}	2025-09-14 17:38:42.235481+03	\N	незнакомец
33	CREATE	UserRole	16	\N	{"id": 16, "role": 1, "user": 1}	2025-09-14 17:39:46.304905+03	\N	незнакомец
34	CREATE	UserRole	17	\N	{"id": 17, "role": 1, "user": 1}	2025-09-14 17:48:40.893143+03	\N	незнакомец
35	CREATE	UserRole	18	\N	{"id": 18, "role": 1, "user": 1}	2025-09-14 17:52:33.094012+03	1	admin:123
36	DELETE	UserRole	18	{"id": 18, "role": 1, "user": 1}	\N	2025-09-14 17:58:56.102082+03	1	admin:123
37	DELETE	UserRole	17	{"id": 17, "role": 1, "user": 1}	\N	2025-09-14 17:58:56.105379+03	1	admin:123
38	DELETE	UserRole	16	{"id": 16, "role": 1, "user": 1}	\N	2025-09-14 17:58:56.106994+03	1	admin:123
39	DELETE	UserRole	15	{"id": 15, "role": 1, "user": 1}	\N	2025-09-14 17:58:56.108836+03	1	admin:123
40	DELETE	UserRole	11	{"id": 11, "role": 1, "user": 1}	\N	2025-09-14 17:58:56.110405+03	1	admin:123
41	DELETE	UserRole	10	{"id": 10, "role": 1, "user": 1}	\N	2025-09-14 17:58:56.111873+03	1	admin:123
42	DELETE	UserRole	1	{"id": 1, "role": 1, "user": 1}	\N	2025-09-14 17:58:56.113324+03	1	admin:123
43	CREATE	UserRole	19	\N	{"id": 19, "role": 1, "user": 1}	2025-09-14 17:58:56.117524+03	1	admin:123
44	DELETE	UserRole	19	{"id": 19, "role": 1, "user": 1}	\N	2025-09-14 18:03:29.423481+03	1	admin:123
45	CREATE	UserRole	20	\N	{"id": 20, "role": 1, "user": 1}	2025-09-14 18:03:29.429515+03	1	admin:123
46	DELETE	UserRole	20	{"id": 20, "role": 1, "user": 1}	\N	2025-09-14 18:27:25.147547+03	1	admin:123
47	CREATE	UserRole	21	\N	{"id": 21, "role": 1, "user": 1}	2025-09-14 18:27:25.158013+03	1	admin:123
48	DELETE	UserRole	21	{"id": 21, "role": 1, "user": 1}	\N	2025-09-14 18:33:41.964956+03	1	admin:123
49	CREATE	UserRole	22	\N	{"id": 22, "role": 1, "user": 1}	2025-09-14 18:33:41.972898+03	1	admin:123
50	CREATE	User	19	\N	{"id": 19, "email": "aedgy.ds@mail.ru", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$ztQrg5Aa4JM4L3FL3u0h18$4KOr6poszlS8Q7qPsRwC5UFklEIxe5Wt/H7bUchtLSI=", "username": "IaNovii", "is_active": true, "last_name": "IaNovii213", "first_name": "IaNovii123", "last_login": null, "date_joined": "2025-09-14T16:27:18.679353+00:00", "is_superuser": false, "user_permissions": []}	2025-09-14 19:27:19.332163+03	\N	незнакомец
51	CREATE	UserRole	23	\N	{"id": 23, "role": 3, "user": 19}	2025-09-14 19:27:19.34169+03	\N	незнакомец
52	UPDATE	User	19	{"id": 19, "email": "aedgy.ds@mail.ru", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$ztQrg5Aa4JM4L3FL3u0h18$4KOr6poszlS8Q7qPsRwC5UFklEIxe5Wt/H7bUchtLSI=", "username": "IaNovii", "is_active": true, "last_name": "IaNovii213", "first_name": "IaNovii123", "last_login": null, "date_joined": "2025-09-14T16:27:18.679353+00:00", "is_superuser": false, "user_permissions": []}	{"id": 19, "email": "aedgy.ds@mail.ru", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$ztQrg5Aa4JM4L3FL3u0h18$4KOr6poszlS8Q7qPsRwC5UFklEIxe5Wt/H7bUchtLSI=", "username": "IaNovii2", "is_active": true, "last_name": "IaNovii213", "first_name": "IaNovii123", "last_login": null, "date_joined": "2025-09-14T16:27:18.679353+00:00", "is_superuser": false, "user_permissions": []}	2025-09-14 19:36:35.246057+03	\N	незнакомец
53	UPDATE	User	19	{"id": 19, "email": "aedgy.ds@mail.ru", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$ztQrg5Aa4JM4L3FL3u0h18$4KOr6poszlS8Q7qPsRwC5UFklEIxe5Wt/H7bUchtLSI=", "username": "IaNovii2", "is_active": true, "last_name": "IaNovii213", "first_name": "IaNovii123", "last_login": null, "date_joined": "2025-09-14T16:27:18.679353+00:00", "is_superuser": false, "user_permissions": []}	{"id": 19, "email": "aedgy.ds@mail.ru", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$ztQrg5Aa4JM4L3FL3u0h18$4KOr6poszlS8Q7qPsRwC5UFklEIxe5Wt/H7bUchtLSI=", "username": "IaNovii212312312312333333333333IaNovii212312312312333333333333IaNovii212312312312333333333333IaNovii212312312312333333333333IaNovii2123123123123333333", "is_active": true, "last_name": "IaNovii213", "first_name": "IaNovii123", "last_login": null, "date_joined": "2025-09-14T16:27:18.679353+00:00", "is_superuser": false, "user_permissions": []}	2025-09-14 19:37:15.555901+03	\N	незнакомец
54	UPDATE	User	19	{"id": 19, "email": "aedgy.ds@mail.ru", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$ztQrg5Aa4JM4L3FL3u0h18$4KOr6poszlS8Q7qPsRwC5UFklEIxe5Wt/H7bUchtLSI=", "username": "IaNovii212312312312333333333333IaNovii212312312312333333333333IaNovii212312312312333333333333IaNovii212312312312333333333333IaNovii2123123123123333333", "is_active": true, "last_name": "IaNovii213", "first_name": "IaNovii123", "last_login": null, "date_joined": "2025-09-14T16:27:18.679353+00:00", "is_superuser": false, "user_permissions": []}	{"id": 19, "email": "aedgy.ds@mail.ru", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$ztQrg5Aa4JM4L3FL3u0h18$4KOr6poszlS8Q7qPsRwC5UFklEIxe5Wt/H7bUchtLSI=", "username": "IaNovii212312312312333333333333IaNovii212312312312333333333333IaNovii212312312312333333333333IaNovii212312312312333333333333IaNovii2123123123123333333", "is_active": true, "last_name": "цукуцуцкуцкцукцук", "first_name": "укцкуцкуцуцкцук", "last_login": null, "date_joined": "2025-09-14T16:27:18.679353+00:00", "is_superuser": false, "user_permissions": []}	2025-09-14 19:43:18.426743+03	\N	незнакомец
55	UPDATE	User	19	{"id": 19, "email": "aedgy.ds@mail.ru", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$ztQrg5Aa4JM4L3FL3u0h18$4KOr6poszlS8Q7qPsRwC5UFklEIxe5Wt/H7bUchtLSI=", "username": "IaNovii212312312312333333333333IaNovii212312312312333333333333IaNovii212312312312333333333333IaNovii212312312312333333333333IaNovii2123123123123333333", "is_active": true, "last_name": "цукуцуцкуцкцукцук", "first_name": "укцкуцкуцуцкцук", "last_login": null, "date_joined": "2025-09-14T16:27:18.679353+00:00", "is_superuser": false, "user_permissions": []}	{"id": 19, "email": "aedgy.ds@mail.ru", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$ztQrg5Aa4JM4L3FL3u0h18$4KOr6poszlS8Q7qPsRwC5UFklEIxe5Wt/H7bUchtLSI=", "username": "123123123", "is_active": true, "last_name": "цукуцуцкуцкцукцук", "first_name": "укцкуцкуцуцкцук", "last_login": null, "date_joined": "2025-09-14T16:27:18.679353+00:00", "is_superuser": false, "user_permissions": []}	2025-09-14 19:43:40.522029+03	\N	незнакомец
56	CREATE	User	20	\N	{"id": 20, "email": "aedgy.master@mail.ruuuu", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$VdbYERirvoqz7JGpSrOXEA$FjgKxiFUfMVTgyh/syCD/BwfDaApdmfUIKDzjE2Pj6U=", "username": "IaNew", "is_active": true, "last_name": "awerawer", "first_name": "werawer", "last_login": null, "date_joined": "2025-09-14T16:49:35.331213+00:00", "is_superuser": false, "user_permissions": []}	2025-09-14 19:49:35.987856+03	\N	незнакомец
57	CREATE	UserRole	24	\N	{"id": 24, "role": 3, "user": 20}	2025-09-14 19:49:35.995222+03	\N	незнакомец
58	UPDATE	User	20	{"id": 20, "email": "aedgy.master@mail.ruuuu", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$VdbYERirvoqz7JGpSrOXEA$FjgKxiFUfMVTgyh/syCD/BwfDaApdmfUIKDzjE2Pj6U=", "username": "IaNew", "is_active": true, "last_name": "awerawer", "first_name": "werawer", "last_login": null, "date_joined": "2025-09-14T16:49:35.331213+00:00", "is_superuser": false, "user_permissions": []}	{"id": 20, "email": "aedgy.master@mail.ruuuu", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$VdbYERirvoqz7JGpSrOXEA$FjgKxiFUfMVTgyh/syCD/BwfDaApdmfUIKDzjE2Pj6U=", "username": "IaNew123", "is_active": true, "last_name": "awerawer", "first_name": "werawer", "last_login": null, "date_joined": "2025-09-14T16:49:35.331213+00:00", "is_superuser": false, "user_permissions": []}	2025-09-14 19:53:07.07639+03	\N	незнакомец
59	UPDATE	User	20	{"id": 20, "email": "aedgy.master@mail.ruuuu", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$VdbYERirvoqz7JGpSrOXEA$FjgKxiFUfMVTgyh/syCD/BwfDaApdmfUIKDzjE2Pj6U=", "username": "IaNew123", "is_active": true, "last_name": "awerawer", "first_name": "werawer", "last_login": null, "date_joined": "2025-09-14T16:49:35.331213+00:00", "is_superuser": false, "user_permissions": []}	{"id": 20, "email": "aedgy.master@mail.ruuuu", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$VdbYERirvoqz7JGpSrOXEA$FjgKxiFUfMVTgyh/syCD/BwfDaApdmfUIKDzjE2Pj6U=", "username": "IaNew123321", "is_active": true, "last_name": "awerawer", "first_name": "werawer", "last_login": null, "date_joined": "2025-09-14T16:49:35.331213+00:00", "is_superuser": false, "user_permissions": []}	2025-09-14 19:53:17.778225+03	\N	незнакомец
60	UPDATE	User	20	{"id": 20, "email": "aedgy.master@mail.ruuuu", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$VdbYERirvoqz7JGpSrOXEA$FjgKxiFUfMVTgyh/syCD/BwfDaApdmfUIKDzjE2Pj6U=", "username": "IaNew123321", "is_active": true, "last_name": "awerawer", "first_name": "werawer", "last_login": null, "date_joined": "2025-09-14T16:49:35.331213+00:00", "is_superuser": false, "user_permissions": []}	{"id": 20, "email": "aedgy.master@mail.ruuuu", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$VdbYERirvoqz7JGpSrOXEA$FjgKxiFUfMVTgyh/syCD/BwfDaApdmfUIKDzjE2Pj6U=", "username": "IaNew123321", "is_active": true, "last_name": "awerawer", "first_name": "werawer2", "last_login": null, "date_joined": "2025-09-14T16:49:35.331213+00:00", "is_superuser": false, "user_permissions": []}	2025-09-14 19:53:27.166505+03	\N	незнакомец
61	UPDATE	User	20	{"id": 20, "email": "aedgy.master@mail.ruuuu", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$VdbYERirvoqz7JGpSrOXEA$FjgKxiFUfMVTgyh/syCD/BwfDaApdmfUIKDzjE2Pj6U=", "username": "IaNew123321", "is_active": true, "last_name": "awerawer", "first_name": "werawer2", "last_login": null, "date_joined": "2025-09-14T16:49:35.331213+00:00", "is_superuser": false, "user_permissions": []}	{"id": 20, "email": "aedgy.master@mail.ruuuu", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$VdbYERirvoqz7JGpSrOXEA$FjgKxiFUfMVTgyh/syCD/BwfDaApdmfUIKDzjE2Pj6U=", "username": "IaNew123321", "is_active": true, "last_name": "awerawer2", "first_name": "werawer2", "last_login": null, "date_joined": "2025-09-14T16:49:35.331213+00:00", "is_superuser": false, "user_permissions": []}	2025-09-14 19:53:35.45698+03	\N	незнакомец
62	UPDATE	User	20	{"id": 20, "email": "aedgy.master@mail.ruuuu", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$VdbYERirvoqz7JGpSrOXEA$FjgKxiFUfMVTgyh/syCD/BwfDaApdmfUIKDzjE2Pj6U=", "username": "IaNew123321", "is_active": true, "last_name": "awerawer2", "first_name": "werawer2", "last_login": null, "date_joined": "2025-09-14T16:49:35.331213+00:00", "is_superuser": false, "user_permissions": []}	{"id": 20, "email": "aedgy.master@mail.ru", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$VdbYERirvoqz7JGpSrOXEA$FjgKxiFUfMVTgyh/syCD/BwfDaApdmfUIKDzjE2Pj6U=", "username": "IaNew123321", "is_active": true, "last_name": "awerawer2", "first_name": "werawer2", "last_login": null, "date_joined": "2025-09-14T16:49:35.331213+00:00", "is_superuser": false, "user_permissions": []}	2025-09-14 19:53:46.802956+03	\N	незнакомец
63	UPDATE	User	20	{"id": 20, "email": "aedgy.master@mail.ru", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$VdbYERirvoqz7JGpSrOXEA$FjgKxiFUfMVTgyh/syCD/BwfDaApdmfUIKDzjE2Pj6U=", "username": "IaNew123321", "is_active": true, "last_name": "awerawer2", "first_name": "werawer2", "last_login": null, "date_joined": "2025-09-14T16:49:35.331213+00:00", "is_superuser": false, "user_permissions": []}	{"id": 20, "email": "aedgy.master@mail.ru", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$VdbYERirvoqz7JGpSrOXEA$FjgKxiFUfMVTgyh/syCD/BwfDaApdmfUIKDzjE2Pj6U=", "username": "IaNew123321", "is_active": true, "last_name": "awerawer2", "first_name": "werawer2123213", "last_login": null, "date_joined": "2025-09-14T16:49:35.331213+00:00", "is_superuser": false, "user_permissions": []}	2025-09-14 20:11:51.017178+03	20	user:IaNew123321
64	CREATE	Make	1	\N	{"id": 1, "name": "Toyota"}	2025-09-14 20:36:14.271991+03	20	user:IaNew123321
65	CREATE	Model	1	\N	{"id": 1, "make": 1, "name": "Corolla"}	2025-09-14 20:36:14.541772+03	20	user:IaNew123321
66	CREATE	Car	ОООООООООО1234566	\N	{"VIN": "ОООООООООО1234566", "make": 1, "year": 1990, "model": 1, "price": 523000.0, "seller": 20, "status": "available", "description": "Ну норм"}	2025-09-14 20:37:52.826331+03	20	user:IaNew123321
67	CREATE	Car	JHMCM56557C404453	\N	{"VIN": "JHMCM56557C404453", "make": 1, "year": 1990, "model": 1, "price": 555000.0, "seller": 20, "status": "available", "description": "12312313"}	2025-09-14 20:58:10.212209+03	20	user:IaNew123321
68	CREATE	Car	JHMCM56557C404452	\N	{"VIN": "JHMCM56557C404452", "make": 1, "year": 1990, "model": 1, "price": 555000.0, "seller": 20, "status": "available", "description": "12312312123"}	2025-09-14 21:02:57.95191+03	20	user:IaNew123321
69	CREATE	CarImage	2	\N	{"id": 2, "car": "JHMCM56557C404452", "image": "car_images/loser_YY2DCM2.png"}	2025-09-14 21:02:58.057625+03	20	user:IaNew123321
70	CREATE	CarImage	3	\N	{"id": 3, "car": "JHMCM56557C404452", "image": "car_images/Снимок_экрана_2025-09-14_141941.png"}	2025-09-14 21:02:58.067266+03	20	user:IaNew123321
71	CREATE	Car	JHMCM56557C404353	\N	{"VIN": "JHMCM56557C404353", "make": 1, "year": 2020, "model": 1, "price": 5555555.0, "seller": 20, "status": "available", "description": "21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр"}	2025-09-14 21:17:19.484587+03	20	user:IaNew123321
72	CREATE	CarImage	4	\N	{"id": 4, "car": "JHMCM56557C404353", "image": "car_images/606506.jpg"}	2025-09-14 21:17:19.598096+03	20	user:IaNew123321
73	CREATE	CarImage	5	\N	{"id": 5, "car": "JHMCM56557C404353", "image": "car_images/653302.jpg"}	2025-09-14 21:17:19.606283+03	20	user:IaNew123321
74	CREATE	CarImage	6	\N	{"id": 6, "car": "JHMCM56557C404353", "image": "car_images/1655380035_18-phonoteka-org-p-oboi-furri-19.jpg"}	2025-09-14 21:17:19.613397+03	20	user:IaNew123321
75	CREATE	CarImage	7	\N	{"id": 7, "car": "JHMCM56557C404353", "image": "car_images/Cameron_in_main_menu.jpg"}	2025-09-14 21:17:19.620606+03	20	user:IaNew123321
76	CREATE	CarImage	8	\N	{"id": 8, "car": "JHMCM56557C404353", "image": "car_images/og_og_15886766072427680.jpg"}	2025-09-14 21:17:19.628801+03	20	user:IaNew123321
77	DELETE	UserRole	22	{"id": 22, "role": 1, "user": 1}	\N	2025-09-14 21:50:20.414856+03	1	admin:123
78	CREATE	UserRole	25	\N	{"id": 25, "role": 1, "user": 1}	2025-09-14 21:50:20.421682+03	1	admin:123
79	UPDATE	User	20	{"id": 20, "email": "aedgy.master@mail.ru", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$VdbYERirvoqz7JGpSrOXEA$FjgKxiFUfMVTgyh/syCD/BwfDaApdmfUIKDzjE2Pj6U=", "username": "IaNew123321", "is_active": true, "last_name": "awerawer2", "first_name": "werawer2123213", "last_login": null, "date_joined": "2025-09-14T16:49:35.331213+00:00", "is_superuser": false, "user_permissions": []}	{"id": 20, "email": "aedgy.master@mail.ru", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$VdbYERirvoqz7JGpSrOXEA$FjgKxiFUfMVTgyh/syCD/BwfDaApdmfUIKDzjE2Pj6U=", "username": "IaNew1233213", "is_active": true, "last_name": "awerawer2", "first_name": "werawer2123213", "last_login": null, "date_joined": "2025-09-14T16:49:35.331213+00:00", "is_superuser": false, "user_permissions": []}	2025-09-14 21:52:07.844597+03	20	user:IaNew1233213
80	UPDATE	User	20	{"id": 20, "email": "aedgy.master@mail.ru", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$VdbYERirvoqz7JGpSrOXEA$FjgKxiFUfMVTgyh/syCD/BwfDaApdmfUIKDzjE2Pj6U=", "username": "IaNew1233213", "is_active": true, "last_name": "awerawer2", "first_name": "werawer2123213", "last_login": null, "date_joined": "2025-09-14T16:49:35.331213+00:00", "is_superuser": false, "user_permissions": []}	{"id": 20, "email": "aedgy.master@mail.ru", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$VdbYERirvoqz7JGpSrOXEA$FjgKxiFUfMVTgyh/syCD/BwfDaApdmfUIKDzjE2Pj6U=", "username": "IaNew123321", "is_active": true, "last_name": "awerawer2", "first_name": "werawer2123213", "last_login": null, "date_joined": "2025-09-14T16:49:35.331213+00:00", "is_superuser": false, "user_permissions": []}	2025-09-14 21:52:25.61207+03	20	user:IaNew123321
81	CREATE	Make	2	\N	{"id": 2, "name": "Toyota2"}	2025-09-14 22:00:03.94892+03	20	user:IaNew123321
82	CREATE	Model	2	\N	{"id": 2, "make": 2, "name": "Corolla2"}	2025-09-14 22:00:04.11114+03	20	user:IaNew123321
125	DELETE	Transaction	2	{"id": 2, "order": 1, "amount": 555000.0, "status": "completed"}	\N	2025-09-15 10:20:41.417649+03	20	user:IaNew123321
126	DELETE	Order	1	{"id": 1, "car": "JHMCV56557C404453", "buyer": 21, "status": "paid", "total_amount": 555000.0}	\N	2025-09-15 10:20:41.422382+03	20	user:IaNew123321
127	DELETE	Car	JHMCV56557C404453	{"VIN": "JHMCV56557C404453", "make": 2, "year": 1990, "model": 2, "price": 555000.0, "seller": 20, "status": "sold", "description": "Ну норм такая\\r\\n- вот\\r\\n- о\\r\\n- -\\r\\n- - \\r\\n- -\\r\\n\\r\\n- -\\r\\n-\\r\\n-\\r\\n-\\r\\n-\\r\\n- \\r\\n\\r\\n-- \\r\\n- \\r\\n-"}	\N	2025-09-15 10:20:41.426615+03	20	user:IaNew123321
191	DELETE	UserRole	24	{"id": 24, "role": 3, "user": 20}	\N	2025-09-17 11:25:31.711027+03	\N	незнакомец
83	CREATE	Car	JHMCM16557C404453	\N	{"VIN": "JHMCM16557C404453", "make": 2, "year": 2020, "model": 2, "price": 555555.0, "seller": 20, "status": "available", "description": "ykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiv"}	2025-09-14 22:00:04.225126+03	20	user:IaNew123321
84	CREATE	CarImage	9	\N	{"id": 9, "car": "JHMCM16557C404453", "image": "car_images/1655380035_18-phonoteka-org-p-oboi-furri-19_1jaMWCq.jpg"}	2025-09-14 22:00:04.402666+03	20	user:IaNew123321
85	DELETE	UserRole	25	{"id": 25, "role": 1, "user": 1}	\N	2025-09-14 22:43:40.477977+03	1	admin:123
86	CREATE	UserRole	26	\N	{"id": 26, "role": 1, "user": 1}	2025-09-14 22:43:40.486893+03	1	admin:123
87	CREATE	User	21	\N	{"id": 21, "email": "NewUserKsta@mail.ru", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$B1ui9Sg6JePADSRYtI8Rda$yaUwyQOokOsH1v0K12UPJK0E/kP2Oj6FPhQAX/+jIWo=", "username": "NewUserKsta", "is_active": true, "last_name": "123", "first_name": "123", "last_login": null, "date_joined": "2025-09-14T19:46:30.160396+00:00", "is_superuser": false, "user_permissions": []}	2025-09-14 22:46:30.858721+03	\N	незнакомец
88	CREATE	UserRole	27	\N	{"id": 27, "role": 3, "user": 21}	2025-09-14 22:46:30.866565+03	\N	незнакомец
89	DELETE	Car	ОООООООООО1234567	{"VIN": "ОООООООООО1234567", "make": 1, "year": 1990, "model": 1, "price": 523000.0, "seller": 20, "status": "available", "description": "Ну норм"}	\N	2025-09-14 22:58:13.153337+03	20	user:IaNew123321
90	DELETE	Car	ОООООООООО1234566	{"VIN": "ОООООООООО1234566", "make": 1, "year": 1990, "model": 1, "price": 523000.0, "seller": 20, "status": "available", "description": "Ну норм"}	\N	2025-09-14 22:58:14.945425+03	20	user:IaNew123321
91	DELETE	CarImage	1	{"id": 1, "car": "JHMCM56557C404453", "image": "car_images/loser.png"}	\N	2025-09-14 22:58:16.461144+03	20	user:IaNew123321
92	DELETE	Car	JHMCM56557C404453	{"VIN": "JHMCM56557C404453", "make": 1, "year": 1990, "model": 1, "price": 555000.0, "seller": 20, "status": "available", "description": "12312313"}	\N	2025-09-14 22:58:16.4648+03	20	user:IaNew123321
93	DELETE	CarImage	3	{"id": 3, "car": "JHMCM56557C404452", "image": "car_images/Снимок_экрана_2025-09-14_141941.png"}	\N	2025-09-14 22:58:17.996645+03	20	user:IaNew123321
94	DELETE	CarImage	2	{"id": 2, "car": "JHMCM56557C404452", "image": "car_images/loser_YY2DCM2.png"}	\N	2025-09-14 22:58:18.001094+03	20	user:IaNew123321
95	DELETE	Car	JHMCM56557C404452	{"VIN": "JHMCM56557C404452", "make": 1, "year": 1990, "model": 1, "price": 555000.0, "seller": 20, "status": "available", "description": "12312312123"}	\N	2025-09-14 22:58:18.003376+03	20	user:IaNew123321
96	DELETE	CarImage	8	{"id": 8, "car": "JHMCM56557C404353", "image": "car_images/og_og_15886766072427680.jpg"}	\N	2025-09-14 22:58:19.485539+03	20	user:IaNew123321
97	DELETE	CarImage	7	{"id": 7, "car": "JHMCM56557C404353", "image": "car_images/Cameron_in_main_menu.jpg"}	\N	2025-09-14 22:58:19.488522+03	20	user:IaNew123321
98	DELETE	CarImage	6	{"id": 6, "car": "JHMCM56557C404353", "image": "car_images/1655380035_18-phonoteka-org-p-oboi-furri-19.jpg"}	\N	2025-09-14 22:58:19.490182+03	20	user:IaNew123321
99	DELETE	CarImage	5	{"id": 5, "car": "JHMCM56557C404353", "image": "car_images/653302.jpg"}	\N	2025-09-14 22:58:19.49264+03	20	user:IaNew123321
100	DELETE	CarImage	4	{"id": 4, "car": "JHMCM56557C404353", "image": "car_images/606506.jpg"}	\N	2025-09-14 22:58:19.494092+03	20	user:IaNew123321
101	DELETE	Car	JHMCM56557C404353	{"VIN": "JHMCM56557C404353", "make": 1, "year": 2020, "model": 1, "price": 5555555.0, "seller": 20, "status": "available", "description": "21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр21.цудларыдклшваОтфгыклыврояалфуащшкглвыеряаовШЫОЖЩУЫшкнпвиомафушоашыквпеиматяофшуыгакв мтыфоугшкватфоушщкаывтфуошкрвтошфквырфоушкывшр"}	\N	2025-09-14 22:58:19.496209+03	20	user:IaNew123321
102	DELETE	CarImage	9	{"id": 9, "car": "JHMCM16557C404453", "image": "car_images/1655380035_18-phonoteka-org-p-oboi-furri-19_1jaMWCq.jpg"}	\N	2025-09-14 22:58:21.190279+03	20	user:IaNew123321
128	DELETE	UserRole	29	{"id": 29, "role": 1, "user": 1}	\N	2025-09-15 10:50:11.679787+03	1	admin:123
129	CREATE	UserRole	30	\N	{"id": 30, "role": 1, "user": 1}	2025-09-15 10:50:11.729135+03	1	admin:123
130	DELETE	CarImage	12	{"id": 12, "car": "JHMCM56557C404453", "image": "car_images/1655380035_18-phonoteka-org-p-oboi-furri-19_YyiIeIh.jpg"}	\N	2025-09-15 11:08:12.414153+03	21	user:NewUserKsta
131	DELETE	Transaction	1	{"id": 1, "order": 2, "amount": 1000000.0, "status": "completed"}	\N	2025-09-15 11:08:12.417668+03	21	user:NewUserKsta
132	DELETE	Order	2	{"id": 2, "car": "JHMCM56557C404453", "buyer": 20, "status": "paid", "total_amount": 1000000.0}	\N	2025-09-15 11:08:12.419648+03	21	user:NewUserKsta
157	CREATE	Order	6	\N	{"id": 6, "car": "JHMFM56557C404453", "buyer": 20, "status": "pending", "total_amount": 100000000.0}	2025-09-15 13:26:40.067121+03	20	user:IaNew123321
103	DELETE	Car	JHMCM16557C404453	{"VIN": "JHMCM16557C404453", "make": 2, "year": 2020, "model": 2, "price": 555555.0, "seller": 20, "status": "available", "description": "ykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiykjhgfdsrwgtyjkmhgfyujiv"}	\N	2025-09-14 22:58:21.195394+03	20	user:IaNew123321
104	DELETE	UserRole	26	{"id": 26, "role": 1, "user": 1}	\N	2025-09-15 08:40:55.440556+03	1	admin:123
105	CREATE	UserRole	28	\N	{"id": 28, "role": 1, "user": 1}	2025-09-15 08:40:55.452255+03	1	admin:123
106	CREATE	Car	JHMCV56557C404453	\N	{"VIN": "JHMCV56557C404453", "make": 2, "year": 1990, "model": 2, "price": 555000.0, "seller": 20, "status": "available", "description": "Ну норм такая\\r\\n- вот\\r\\n- о\\r\\n- -\\r\\n- - \\r\\n- -\\r\\n\\r\\n- -\\r\\n-\\r\\n-\\r\\n-\\r\\n-\\r\\n- \\r\\n\\r\\n-- \\r\\n- \\r\\n-"}	2025-09-15 08:46:05.636764+03	20	user:IaNew123321
107	CREATE	CarImage	10	\N	{"id": 10, "car": "JHMCV56557C404453", "image": "car_images/653302_T4gYTqb.jpg"}	2025-09-15 08:46:05.852455+03	20	user:IaNew123321
108	CREATE	CarImage	11	\N	{"id": 11, "car": "JHMCV56557C404453", "image": "car_images/1655380035_18-phonoteka-org-p-oboi-furri-19_FHQ1fgg.jpg"}	2025-09-15 08:46:05.871035+03	20	user:IaNew123321
109	UPDATE	Car	JHMCV56557C404453	{"VIN": "JHMCV56557C404453", "make": 2, "year": 1990, "model": 2, "price": 555000.0, "seller": 20, "status": "available", "description": "Ну норм такая\\r\\n- вот\\r\\n- о\\r\\n- -\\r\\n- - \\r\\n- -\\r\\n\\r\\n- -\\r\\n-\\r\\n-\\r\\n-\\r\\n-\\r\\n- \\r\\n\\r\\n-- \\r\\n- \\r\\n-"}	{"VIN": "JHMCV56557C404453", "make": 2, "year": 1990, "model": 2, "price": 555000.0, "seller": 20, "status": "reserved", "description": "Ну норм такая\\r\\n- вот\\r\\n- о\\r\\n- -\\r\\n- - \\r\\n- -\\r\\n\\r\\n- -\\r\\n-\\r\\n-\\r\\n-\\r\\n-\\r\\n- \\r\\n\\r\\n-- \\r\\n- \\r\\n-"}	2025-09-15 09:41:23.475112+03	21	user:NewUserKsta
110	CREATE	Order	1	\N	{"id": 1, "car": "JHMCV56557C404453", "buyer": 21, "status": "pending", "total_amount": 555000.0}	2025-09-15 09:41:23.491095+03	21	user:NewUserKsta
111	CREATE	Car	JHMCM56557C404453	\N	{"VIN": "JHMCM56557C404453", "make": 2, "year": 1890, "model": 2, "price": 1000000.0, "seller": 21, "status": "available", "description": "Вот так вот 💚"}	2025-09-15 10:00:30.992509+03	21	user:NewUserKsta
112	CREATE	CarImage	12	\N	{"id": 12, "car": "JHMCM56557C404453", "image": "car_images/1655380035_18-phonoteka-org-p-oboi-furri-19_YyiIeIh.jpg"}	2025-09-15 10:00:31.391143+03	21	user:NewUserKsta
113	UPDATE	Car	JHMCM56557C404453	{"VIN": "JHMCM56557C404453", "make": 2, "year": 1890, "model": 2, "price": 1000000.0, "seller": 21, "status": "available", "description": "Вот так вот 💚"}	{"VIN": "JHMCM56557C404453", "make": 2, "year": 1890, "model": 2, "price": 1000000.0, "seller": 21, "status": "reserved", "description": "Вот так вот 💚"}	2025-09-15 10:09:50.147602+03	20	user:IaNew123321
114	CREATE	Order	2	\N	{"id": 2, "car": "JHMCM56557C404453", "buyer": 20, "status": "pending", "total_amount": 1000000.0}	2025-09-15 10:09:50.15745+03	20	user:IaNew123321
115	DELETE	UserRole	28	{"id": 28, "role": 1, "user": 1}	\N	2025-09-15 10:13:44.557301+03	1	admin:123
116	CREATE	UserRole	29	\N	{"id": 29, "role": 1, "user": 1}	2025-09-15 10:13:44.609108+03	1	admin:123
117	UPDATE	Car	JHMCM56557C404453	{"VIN": "JHMCM56557C404453", "make": 2, "year": 1890, "model": 2, "price": 1000000.0, "seller": 21, "status": "reserved", "description": "Вот так вот 💚"}	{"VIN": "JHMCM56557C404453", "make": 2, "year": 1890, "model": 2, "price": 1000000.0, "seller": 21, "status": "sold", "description": "Вот так вот 💚"}	2025-09-15 10:19:11.417472+03	20	user:IaNew123321
118	UPDATE	Order	2	{"id": 2, "car": "JHMCM56557C404453", "buyer": 20, "status": "pending", "total_amount": 1000000.0}	{"id": 2, "car": "JHMCM56557C404453", "buyer": 20, "status": "paid", "total_amount": 1000000.0}	2025-09-15 10:19:11.475024+03	20	user:IaNew123321
119	CREATE	Transaction	1	\N	{"id": 1, "order": 2, "amount": 1000000.0, "status": "completed"}	2025-09-15 10:19:11.486148+03	20	user:IaNew123321
120	UPDATE	Car	JHMCV56557C404453	{"VIN": "JHMCV56557C404453", "make": 2, "year": 1990, "model": 2, "price": 555000.0, "seller": 20, "status": "reserved", "description": "Ну норм такая\\r\\n- вот\\r\\n- о\\r\\n- -\\r\\n- - \\r\\n- -\\r\\n\\r\\n- -\\r\\n-\\r\\n-\\r\\n-\\r\\n-\\r\\n- \\r\\n\\r\\n-- \\r\\n- \\r\\n-"}	{"VIN": "JHMCV56557C404453", "make": 2, "year": 1990, "model": 2, "price": 555000.0, "seller": 20, "status": "sold", "description": "Ну норм такая\\r\\n- вот\\r\\n- о\\r\\n- -\\r\\n- - \\r\\n- -\\r\\n\\r\\n- -\\r\\n-\\r\\n-\\r\\n-\\r\\n-\\r\\n- \\r\\n\\r\\n-- \\r\\n- \\r\\n-"}	2025-09-15 10:20:04.80402+03	20	user:IaNew123321
121	UPDATE	Order	1	{"id": 1, "car": "JHMCV56557C404453", "buyer": 21, "status": "pending", "total_amount": 555000.0}	{"id": 1, "car": "JHMCV56557C404453", "buyer": 21, "status": "paid", "total_amount": 555000.0}	2025-09-15 10:20:04.813857+03	20	user:IaNew123321
122	CREATE	Transaction	2	\N	{"id": 2, "order": 1, "amount": 555000.0, "status": "completed"}	2025-09-15 10:20:04.81742+03	20	user:IaNew123321
123	DELETE	CarImage	11	{"id": 11, "car": "JHMCV56557C404453", "image": "car_images/1655380035_18-phonoteka-org-p-oboi-furri-19_FHQ1fgg.jpg"}	\N	2025-09-15 10:20:41.409138+03	20	user:IaNew123321
124	DELETE	CarImage	10	{"id": 10, "car": "JHMCV56557C404453", "image": "car_images/653302_T4gYTqb.jpg"}	\N	2025-09-15 10:20:41.414323+03	20	user:IaNew123321
133	DELETE	Car	JHMCM56557C404453	{"VIN": "JHMCM56557C404453", "make": 2, "year": 1890, "model": 2, "price": 1000000.0, "seller": 21, "status": "sold", "description": "Вот так вот 💚"}	\N	2025-09-15 11:08:12.421557+03	21	user:NewUserKsta
134	CREATE	Car	JHMFM56557C404453	\N	{"VIN": "JHMFM56557C404453", "make": 1, "year": 1990, "model": 1, "price": 100000000.0, "seller": 21, "status": "available", "description": "1312321312"}	2025-09-15 11:13:10.647303+03	21	user:NewUserKsta
135	CREATE	CarImage	13	\N	{"id": 13, "car": "JHMFM56557C404453", "image": "car_images/1655380035_18-phonoteka-org-p-oboi-furri-19_perqYSt.jpg"}	2025-09-15 11:13:10.750125+03	21	user:NewUserKsta
136	CREATE	CarImage	14	\N	{"id": 14, "car": "JHMFM56557C404453", "image": "car_images/Cameron_in_main_menu_bg9LHpq.jpg"}	2025-09-15 11:13:10.758668+03	21	user:NewUserKsta
137	CREATE	CarImage	15	\N	{"id": 15, "car": "JHMFM56557C404453", "image": "car_images/og_og_15886766072427680_AWJXLTl.jpg"}	2025-09-15 11:13:10.76594+03	21	user:NewUserKsta
138	DELETE	User	5	{"id": 5, "email": "userNEW@example.com", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$H3TLxBdvAEzv8DGCct1eYx$yuk3MawBwIqB3XttSAG66lsCC9T0WdaQbSJE3enycIk=", "username": "gmakzeBDPB6M8", "is_active": true, "last_name": "Чистотин", "first_name": "Михаил", "last_login": null, "date_joined": "2025-09-12T11:18:36.258294+00:00", "is_superuser": false, "user_permissions": []}	\N	2025-09-15 11:16:26.333902+03	1	admin:123
139	UPDATE	Car	JHMFM56557C404453	{"VIN": "JHMFM56557C404453", "make": 1, "year": 1990, "model": 1, "price": 100000000.0, "seller": 21, "status": "available", "description": "1312321312"}	{"VIN": "JHMFM56557C404453", "make": 1, "year": 1990, "model": 1, "price": 100000000.0, "seller": 21, "status": "reserved", "description": "1312321312"}	2025-09-15 11:21:44.776506+03	20	user:IaNew123321
140	CREATE	Order	3	\N	{"id": 3, "car": "JHMFM56557C404453", "buyer": 20, "status": "pending", "total_amount": 100000000.0}	2025-09-15 11:21:44.782631+03	20	user:IaNew123321
141	DELETE	UserRole	30	{"id": 30, "role": 1, "user": 1}	\N	2025-09-15 11:36:56.424764+03	1	admin:123
142	CREATE	UserRole	31	\N	{"id": 31, "role": 1, "user": 1}	2025-09-15 11:36:56.431618+03	1	admin:123
143	CREATE	Car	JHMCM57557C404453	\N	{"VIN": "JHMCM57557C404453", "make": 1, "year": 1990, "model": 1, "price": 1000000.0, "seller": 20, "status": "available", "description": "Лол"}	2025-09-15 12:13:42.142324+03	20	user:IaNew123321
144	CREATE	CarImage	16	\N	{"id": 16, "car": "JHMCM57557C404453", "image": "car_images/Cameron_in_main_menu_qDqdPQ9.jpg"}	2025-09-15 12:13:42.371436+03	20	user:IaNew123321
145	CREATE	CarImage	17	\N	{"id": 17, "car": "JHMCM57557C404453", "image": "car_images/og_og_15886766072427680_7pj94ci.jpg"}	2025-09-15 12:13:42.384903+03	20	user:IaNew123321
146	UPDATE	Car	JHMFM56557C404453	{"VIN": "JHMFM56557C404453", "make": 1, "year": 1990, "model": 1, "price": 100000000.0, "seller": 21, "status": "reserved", "description": "1312321312"}	{"VIN": "JHMFM56557C404453", "make": 1, "year": 1990, "model": 1, "price": 100000000.0, "seller": 21, "status": "available", "description": "1312321312"}	2025-09-15 12:49:54.610717+03	20	user:IaNew123321
147	UPDATE	Order	3	{"id": 3, "car": "JHMFM56557C404453", "buyer": 20, "status": "pending", "total_amount": 100000000.0}	{"id": 3, "car": "JHMFM56557C404453", "buyer": 20, "status": "cancelled", "total_amount": 100000000.0}	2025-09-15 12:49:54.632168+03	20	user:IaNew123321
148	UPDATE	Car	JHMFM56557C404453	{"VIN": "JHMFM56557C404453", "make": 1, "year": 1990, "model": 1, "price": 100000000.0, "seller": 21, "status": "available", "description": "1312321312"}	{"VIN": "JHMFM56557C404453", "make": 1, "year": 1990, "model": 1, "price": 100000000.0, "seller": 21, "status": "reserved", "description": "1312321312"}	2025-09-15 13:10:20.949526+03	20	user:IaNew123321
149	CREATE	Order	4	\N	{"id": 4, "car": "JHMFM56557C404453", "buyer": 20, "status": "pending", "total_amount": 100000000.0}	2025-09-15 13:10:20.958223+03	20	user:IaNew123321
150	UPDATE	Car	JHMFM56557C404453	{"VIN": "JHMFM56557C404453", "make": 1, "year": 1990, "model": 1, "price": 100000000.0, "seller": 21, "status": "reserved", "description": "1312321312"}	{"VIN": "JHMFM56557C404453", "make": 1, "year": 1990, "model": 1, "price": 100000000.0, "seller": 21, "status": "available", "description": "1312321312"}	2025-09-15 13:11:33.246928+03	21	user:NewUserKsta
151	UPDATE	Order	4	{"id": 4, "car": "JHMFM56557C404453", "buyer": 20, "status": "pending", "total_amount": 100000000.0}	{"id": 4, "car": "JHMFM56557C404453", "buyer": 20, "status": "cancelled", "total_amount": 100000000.0}	2025-09-15 13:11:33.250881+03	21	user:NewUserKsta
152	UPDATE	Car	JHMCM57557C404453	{"VIN": "JHMCM57557C404453", "make": 1, "year": 1990, "model": 1, "price": 1000000.0, "seller": 20, "status": "available", "description": "Лол"}	{"VIN": "JHMCM57557C404453", "make": 1, "year": 1990, "model": 1, "price": 1000000.0, "seller": 20, "status": "reserved", "description": "Лол"}	2025-09-15 13:17:22.822252+03	21	user:NewUserKsta
153	CREATE	Order	5	\N	{"id": 5, "car": "JHMCM57557C404453", "buyer": 21, "status": "pending", "total_amount": 1000000.0}	2025-09-15 13:17:22.828459+03	21	user:NewUserKsta
154	UPDATE	Car	JHMCM57557C404453	{"VIN": "JHMCM57557C404453", "make": 1, "year": 1990, "model": 1, "price": 1000000.0, "seller": 20, "status": "reserved", "description": "Лол"}	{"VIN": "JHMCM57557C404453", "make": 1, "year": 1990, "model": 1, "price": 1000000.0, "seller": 20, "status": "available", "description": "Лол"}	2025-09-15 13:18:39.601957+03	20	user:IaNew123321
155	UPDATE	Order	5	{"id": 5, "car": "JHMCM57557C404453", "buyer": 21, "status": "pending", "total_amount": 1000000.0}	{"id": 5, "car": "JHMCM57557C404453", "buyer": 21, "status": "cancelled", "total_amount": 1000000.0}	2025-09-15 13:18:39.610851+03	20	user:IaNew123321
156	UPDATE	Car	JHMFM56557C404453	{"VIN": "JHMFM56557C404453", "make": 1, "year": 1990, "model": 1, "price": 100000000.0, "seller": 21, "status": "available", "description": "1312321312"}	{"VIN": "JHMFM56557C404453", "make": 1, "year": 1990, "model": 1, "price": 100000000.0, "seller": 21, "status": "reserved", "description": "1312321312"}	2025-09-15 13:26:40.059314+03	20	user:IaNew123321
158	UPDATE	Car	JHMFM56557C404453	{"VIN": "JHMFM56557C404453", "make": 1, "year": 1990, "model": 1, "price": 100000000.0, "seller": 21, "status": "reserved", "description": "1312321312"}	{"VIN": "JHMFM56557C404453", "make": 1, "year": 1990, "model": 1, "price": 100000000.0, "seller": 21, "status": "available", "description": "1312321312"}	2025-09-15 13:27:25.180098+03	21	user:NewUserKsta
159	UPDATE	Order	6	{"id": 6, "car": "JHMFM56557C404453", "buyer": 20, "status": "pending", "total_amount": 100000000.0}	{"id": 6, "car": "JHMFM56557C404453", "buyer": 20, "status": "cancelled", "total_amount": 100000000.0}	2025-09-15 13:27:25.185226+03	21	user:NewUserKsta
160	UPDATE	Car	JHMFM56557C404453	{"VIN": "JHMFM56557C404453", "make": 1, "year": 1990, "model": 1, "price": 100000000.0, "seller": 21, "status": "available", "description": "1312321312"}	{"VIN": "JHMFM56557C404453", "make": 1, "year": 1991, "model": 1, "price": 2000000.0, "seller": 21, "status": "available", "description": "1312321312"}	2025-09-15 13:44:58.016167+03	21	user:NewUserKsta
161	CREATE	CarImage	18	\N	{"id": 18, "car": "JHMFM56557C404453", "image": "car_images/Cameron_in_main_menu_hycJYuz.jpg"}	2025-09-15 13:44:58.244869+03	21	user:NewUserKsta
162	UPDATE	Car	JHMFM56557C404453	{"VIN": "JHMFM56557C404453", "make": 1, "year": 1991, "model": 1, "price": 2000000.0, "seller": 21, "status": "available", "description": "1312321312"}	{"VIN": "JHMFM56557C404453", "make": 1, "year": 1991, "model": 1, "price": 2000000.0, "seller": 21, "status": "unavailable", "description": "1312321312"}	2025-09-15 13:45:50.970778+03	21	user:NewUserKsta
163	DELETE	UserRole	31	{"id": 31, "role": 1, "user": 1}	\N	2025-09-16 14:08:58.164855+03	1	admin:123
164	CREATE	UserRole	32	\N	{"id": 32, "role": 1, "user": 1}	2025-09-16 14:08:58.18939+03	1	admin:123
165	CREATE	Review	2	\N	{"id": 2, "author": 21, "rating": 3, "target": 20, "comment": "JHGVBJGHV"}	2025-09-16 14:27:08.3288+03	21	user:NewUserKsta
166	UPDATE	Review	2	{"id": 2, "author": 21, "rating": 3, "target": 20, "comment": "JHGVBJGHV"}	{"id": 2, "author": 21, "rating": 1, "target": 20, "comment": "новый отзыв"}	2025-09-16 15:10:02.364472+03	21	user:NewUserKsta
167	DELETE	Review	2	{"id": 2, "author": 21, "rating": 1, "target": 20, "comment": "новый отзыв"}	\N	2025-09-16 15:10:07.615828+03	21	user:NewUserKsta
168	CREATE	User	22	\N	{"id": 22, "email": "aedgy.master123@mail.ruuuu", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$nCejtm2a4WpOsgQwcYB61K$XflvFk8LOTCngv2c3MW2JtZAMtwhb8Tzw075kCsEmt4=", "username": "Loser123", "is_active": true, "last_name": "Loser123", "first_name": "Loser123", "last_login": null, "date_joined": "2025-09-17T07:44:52.213136+00:00", "is_superuser": false, "user_permissions": []}	2025-09-17 10:44:52.929254+03	\N	незнакомец
169	CREATE	UserRole	33	\N	{"id": 33, "role": 3, "user": 22}	2025-09-17 10:44:52.945617+03	\N	незнакомец
170	DELETE	UserRole	33	{"id": 33, "role": 3, "user": 22}	\N	2025-09-17 10:47:34.311134+03	1	admin:123
171	CREATE	UserRole	34	\N	{"id": 34, "role": 2, "user": 22}	2025-09-17 10:47:34.319767+03	1	admin:123
172	DELETE	Order	6	{"id": 6, "car": "JHMFM56557C404453", "buyer": 20, "status": "cancelled", "total_amount": 100000000.0}	\N	2025-09-17 11:25:31.660856+03	\N	незнакомец
173	DELETE	Order	5	{"id": 5, "car": "JHMCM57557C404453", "buyer": 21, "status": "cancelled", "total_amount": 1000000.0}	\N	2025-09-17 11:25:31.665821+03	\N	незнакомец
174	DELETE	Order	4	{"id": 4, "car": "JHMFM56557C404453", "buyer": 20, "status": "cancelled", "total_amount": 100000000.0}	\N	2025-09-17 11:25:31.667481+03	\N	незнакомец
175	DELETE	Order	3	{"id": 3, "car": "JHMFM56557C404453", "buyer": 20, "status": "cancelled", "total_amount": 100000000.0}	\N	2025-09-17 11:25:31.668267+03	\N	незнакомец
176	DELETE	CarImage	18	{"id": 18, "car": "JHMFM56557C404453", "image": "car_images/Cameron_in_main_menu_hycJYuz.jpg"}	\N	2025-09-17 11:25:31.684836+03	\N	незнакомец
177	DELETE	CarImage	17	{"id": 17, "car": "JHMCM57557C404453", "image": "car_images/og_og_15886766072427680_7pj94ci.jpg"}	\N	2025-09-17 11:25:31.686067+03	\N	незнакомец
178	DELETE	CarImage	16	{"id": 16, "car": "JHMCM57557C404453", "image": "car_images/Cameron_in_main_menu_qDqdPQ9.jpg"}	\N	2025-09-17 11:25:31.687047+03	\N	незнакомец
179	DELETE	CarImage	15	{"id": 15, "car": "JHMFM56557C404453", "image": "car_images/og_og_15886766072427680_AWJXLTl.jpg"}	\N	2025-09-17 11:25:31.687822+03	\N	незнакомец
180	DELETE	CarImage	14	{"id": 14, "car": "JHMFM56557C404453", "image": "car_images/Cameron_in_main_menu_bg9LHpq.jpg"}	\N	2025-09-17 11:25:31.688445+03	\N	незнакомец
181	DELETE	CarImage	13	{"id": 13, "car": "JHMFM56557C404453", "image": "car_images/1655380035_18-phonoteka-org-p-oboi-furri-19_perqYSt.jpg"}	\N	2025-09-17 11:25:31.68896+03	\N	незнакомец
182	DELETE	Car	JHMFM56557C404453	{"VIN": "JHMFM56557C404453", "make": 1, "year": 1991, "model": 1, "price": 2000000.0, "seller": 21, "status": "unavailable", "description": "1312321312"}	\N	2025-09-17 11:25:31.690253+03	\N	незнакомец
183	DELETE	Car	JHMCM57557C404453	{"VIN": "JHMCM57557C404453", "make": 1, "year": 1990, "model": 1, "price": 1000000.0, "seller": 20, "status": "available", "description": "Лол"}	\N	2025-09-17 11:25:31.691302+03	\N	незнакомец
184	DELETE	Model	2	{"id": 2, "make": 2, "name": "Corolla2"}	\N	2025-09-17 11:25:31.697212+03	\N	незнакомец
185	DELETE	Model	1	{"id": 1, "make": 1, "name": "Corolla"}	\N	2025-09-17 11:25:31.697859+03	\N	незнакомец
186	DELETE	Make	2	{"id": 2, "name": "Toyota2"}	\N	2025-09-17 11:25:31.705439+03	\N	незнакомец
187	DELETE	Make	1	{"id": 1, "name": "Toyota"}	\N	2025-09-17 11:25:31.706032+03	\N	незнакомец
188	DELETE	UserRole	34	{"id": 34, "role": 2, "user": 22}	\N	2025-09-17 11:25:31.70967+03	\N	незнакомец
189	DELETE	UserRole	32	{"id": 32, "role": 1, "user": 1}	\N	2025-09-17 11:25:31.710187+03	\N	незнакомец
190	DELETE	UserRole	27	{"id": 27, "role": 3, "user": 21}	\N	2025-09-17 11:25:31.710642+03	\N	незнакомец
192	DELETE	UserRole	23	{"id": 23, "role": 3, "user": 19}	\N	2025-09-17 11:25:31.7116+03	\N	незнакомец
193	DELETE	UserRole	14	{"id": 14, "role": 2, "user": 18}	\N	2025-09-17 11:25:31.7124+03	\N	незнакомец
194	DELETE	UserRole	13	{"id": 13, "role": 1, "user": 18}	\N	2025-09-17 11:25:31.71281+03	\N	незнакомец
195	DELETE	UserRole	12	{"id": 12, "role": 3, "user": 18}	\N	2025-09-17 11:25:31.713183+03	\N	незнакомец
196	DELETE	UserRole	9	{"id": 9, "role": 2, "user": 17}	\N	2025-09-17 11:25:31.713687+03	\N	незнакомец
197	DELETE	UserRole	8	{"id": 8, "role": 2, "user": 17}	\N	2025-09-17 11:25:31.714213+03	\N	незнакомец
198	DELETE	UserRole	7	{"id": 7, "role": 2, "user": 17}	\N	2025-09-17 11:25:31.714715+03	\N	незнакомец
199	DELETE	UserRole	6	{"id": 6, "role": 2, "user": 14}	\N	2025-09-17 11:25:31.715308+03	\N	незнакомец
200	DELETE	UserRole	5	{"id": 5, "role": 2, "user": 17}	\N	2025-09-17 11:25:31.716631+03	\N	незнакомец
201	DELETE	UserRole	4	{"id": 4, "role": 4, "user": 12}	\N	2025-09-17 11:25:31.717556+03	\N	незнакомец
202	DELETE	UserRole	3	{"id": 3, "role": 3, "user": 17}	\N	2025-09-17 11:25:31.718447+03	\N	незнакомец
203	DELETE	UserRole	2	{"id": 2, "role": 3, "user": 16}	\N	2025-09-17 11:25:31.719043+03	\N	незнакомец
204	CREATE	User	23	\N	{"id": 23, "email": "admin@example.com", "groups": [], "is_staff": true, "password": "", "username": "admin", "is_active": true, "last_name": "User", "first_name": "Admin", "last_login": null, "date_joined": "2025-09-17T08:25:31.725898+00:00", "is_superuser": true, "user_permissions": []}	2025-09-17 11:25:31.740169+03	\N	незнакомец
205	CREATE	UserRole	35	\N	{"id": 35, "role": 1, "user": 23}	2025-09-17 11:25:31.742858+03	\N	незнакомец
206	UPDATE	User	23	{"id": 23, "email": "admin@example.com", "groups": [], "is_staff": true, "password": "", "username": "admin", "is_active": true, "last_name": "User", "first_name": "Admin", "last_login": null, "date_joined": "2025-09-17T08:25:31.725898+00:00", "is_superuser": true, "user_permissions": []}	{"id": 23, "email": "admin@example.com", "groups": [], "is_staff": true, "password": "pbkdf2_sha256$1000000$BSoLJZrBXNsOyB9FrDEvHH$3tsggpIv6kN0t1Y9FI6qcj99z26IlQhGUpmtCS9jXpI=", "username": "admin", "is_active": true, "last_name": "User", "first_name": "Admin", "last_login": null, "date_joined": "2025-09-17T08:25:31.725898+00:00", "is_superuser": true, "user_permissions": []}	2025-09-17 11:25:32.520732+03	\N	незнакомец
207	CREATE	User	24	\N	{"id": 24, "email": "alice@example.com", "groups": [], "is_staff": false, "password": "", "username": "alice", "is_active": true, "last_name": "Ivanova", "first_name": "Alice", "last_login": null, "date_joined": "2025-09-17T08:25:32.544444+00:00", "is_superuser": false, "user_permissions": []}	2025-09-17 11:25:32.546735+03	\N	незнакомец
208	UPDATE	User	24	{"id": 24, "email": "alice@example.com", "groups": [], "is_staff": false, "password": "", "username": "alice", "is_active": true, "last_name": "Ivanova", "first_name": "Alice", "last_login": null, "date_joined": "2025-09-17T08:25:32.544444+00:00", "is_superuser": false, "user_permissions": []}	{"id": 24, "email": "alice@example.com", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$5eKnMqSVjOeaUgprGKkjyX$632+bQN8/U4UceptJ7oGi6sh28qAQ7c6H6B/dQwFA/I=", "username": "alice", "is_active": true, "last_name": "Ivanova", "first_name": "Alice", "last_login": null, "date_joined": "2025-09-17T08:25:32.544444+00:00", "is_superuser": false, "user_permissions": []}	2025-09-17 11:25:33.208208+03	\N	незнакомец
209	CREATE	User	25	\N	{"id": 25, "email": "bob@example.com", "groups": [], "is_staff": false, "password": "", "username": "bob", "is_active": true, "last_name": "Petrov", "first_name": "Bob", "last_login": null, "date_joined": "2025-09-17T08:25:33.209625+00:00", "is_superuser": false, "user_permissions": []}	2025-09-17 11:25:33.212364+03	\N	незнакомец
210	UPDATE	User	25	{"id": 25, "email": "bob@example.com", "groups": [], "is_staff": false, "password": "", "username": "bob", "is_active": true, "last_name": "Petrov", "first_name": "Bob", "last_login": null, "date_joined": "2025-09-17T08:25:33.209625+00:00", "is_superuser": false, "user_permissions": []}	{"id": 25, "email": "bob@example.com", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$WZ6xryiWQhCjtwNrhS6w00$DaZs1A3uAo+rw7StlAI3YqbsbxOHTCU8JWq/M6tjl1U=", "username": "bob", "is_active": true, "last_name": "Petrov", "first_name": "Bob", "last_login": null, "date_joined": "2025-09-17T08:25:33.209625+00:00", "is_superuser": false, "user_permissions": []}	2025-09-17 11:25:33.80739+03	\N	незнакомец
211	CREATE	User	26	\N	{"id": 26, "email": "carol@example.com", "groups": [], "is_staff": false, "password": "", "username": "carol", "is_active": true, "last_name": "Sidorova", "first_name": "Carol", "last_login": null, "date_joined": "2025-09-17T08:25:33.808664+00:00", "is_superuser": false, "user_permissions": []}	2025-09-17 11:25:33.810984+03	\N	незнакомец
212	UPDATE	User	26	{"id": 26, "email": "carol@example.com", "groups": [], "is_staff": false, "password": "", "username": "carol", "is_active": true, "last_name": "Sidorova", "first_name": "Carol", "last_login": null, "date_joined": "2025-09-17T08:25:33.808664+00:00", "is_superuser": false, "user_permissions": []}	{"id": 26, "email": "carol@example.com", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$UCRtHOuy0hDHr26rfnFwiA$vlm08l8St8Q7NRQYy+pWkfEwc+RhL6BBAHcK+C/S4+s=", "username": "carol", "is_active": true, "last_name": "Sidorova", "first_name": "Carol", "last_login": null, "date_joined": "2025-09-17T08:25:33.808664+00:00", "is_superuser": false, "user_permissions": []}	2025-09-17 11:25:34.436201+03	\N	незнакомец
213	CREATE	User	27	\N	{"id": 27, "email": "dave@example.com", "groups": [], "is_staff": false, "password": "", "username": "dave", "is_active": true, "last_name": "Smirnov", "first_name": "Dave", "last_login": null, "date_joined": "2025-09-17T08:25:34.437713+00:00", "is_superuser": false, "user_permissions": []}	2025-09-17 11:25:34.440162+03	\N	незнакомец
227	CREATE	UserRole	36	\N	{"id": 36, "role": 3, "user": 24}	2025-09-17 11:25:38.689301+03	\N	незнакомец
228	CREATE	UserRole	37	\N	{"id": 37, "role": 3, "user": 25}	2025-09-17 11:25:38.691244+03	\N	незнакомец
229	CREATE	UserRole	38	\N	{"id": 38, "role": 3, "user": 26}	2025-09-17 11:25:38.693173+03	\N	незнакомец
230	CREATE	UserRole	39	\N	{"id": 39, "role": 3, "user": 27}	2025-09-17 11:25:38.695157+03	\N	незнакомец
214	UPDATE	User	27	{"id": 27, "email": "dave@example.com", "groups": [], "is_staff": false, "password": "", "username": "dave", "is_active": true, "last_name": "Smirnov", "first_name": "Dave", "last_login": null, "date_joined": "2025-09-17T08:25:34.437713+00:00", "is_superuser": false, "user_permissions": []}	{"id": 27, "email": "dave@example.com", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$UGJpUX7NW4pPJ5HhMWEEOu$iNK/nghIyaNQAaJLErdv7m49VCKxm7sH/aUYnnEAUDw=", "username": "dave", "is_active": true, "last_name": "Smirnov", "first_name": "Dave", "last_login": null, "date_joined": "2025-09-17T08:25:34.437713+00:00", "is_superuser": false, "user_permissions": []}	2025-09-17 11:25:35.047928+03	\N	незнакомец
215	CREATE	User	28	\N	{"id": 28, "email": "erin@example.com", "groups": [], "is_staff": false, "password": "", "username": "erin", "is_active": true, "last_name": "Volkova", "first_name": "Erin", "last_login": null, "date_joined": "2025-09-17T08:25:35.049881+00:00", "is_superuser": false, "user_permissions": []}	2025-09-17 11:25:35.052421+03	\N	незнакомец
216	UPDATE	User	28	{"id": 28, "email": "erin@example.com", "groups": [], "is_staff": false, "password": "", "username": "erin", "is_active": true, "last_name": "Volkova", "first_name": "Erin", "last_login": null, "date_joined": "2025-09-17T08:25:35.049881+00:00", "is_superuser": false, "user_permissions": []}	{"id": 28, "email": "erin@example.com", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$GXFfyu3URLYZEjIhcAyzEp$nuC4EsQq4aCrPTdj0GRWb/wUEuz5Tf5Ys6Mzj/2WsLw=", "username": "erin", "is_active": true, "last_name": "Volkova", "first_name": "Erin", "last_login": null, "date_joined": "2025-09-17T08:25:35.049881+00:00", "is_superuser": false, "user_permissions": []}	2025-09-17 11:25:35.670607+03	\N	незнакомец
217	CREATE	User	29	\N	{"id": 29, "email": "mike@example.com", "groups": [], "is_staff": false, "password": "", "username": "mike", "is_active": true, "last_name": "Orlov", "first_name": "Mikhail", "last_login": null, "date_joined": "2025-09-17T08:25:35.671940+00:00", "is_superuser": false, "user_permissions": []}	2025-09-17 11:25:35.674282+03	\N	незнакомец
218	UPDATE	User	29	{"id": 29, "email": "mike@example.com", "groups": [], "is_staff": false, "password": "", "username": "mike", "is_active": true, "last_name": "Orlov", "first_name": "Mikhail", "last_login": null, "date_joined": "2025-09-17T08:25:35.671940+00:00", "is_superuser": false, "user_permissions": []}	{"id": 29, "email": "mike@example.com", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$cpKsOY8q1zpq4EeGLCBKzD$74BUyS1zosLCjEtmWIPCRFZo5VcPAYd4sND9gF9cCIs=", "username": "mike", "is_active": true, "last_name": "Orlov", "first_name": "Mikhail", "last_login": null, "date_joined": "2025-09-17T08:25:35.671940+00:00", "is_superuser": false, "user_permissions": []}	2025-09-17 11:25:36.269833+03	\N	незнакомец
219	CREATE	User	30	\N	{"id": 30, "email": "nina@example.com", "groups": [], "is_staff": false, "password": "", "username": "nina", "is_active": true, "last_name": "Kuznetsova", "first_name": "Nina", "last_login": null, "date_joined": "2025-09-17T08:25:36.271102+00:00", "is_superuser": false, "user_permissions": []}	2025-09-17 11:25:36.273631+03	\N	незнакомец
220	UPDATE	User	30	{"id": 30, "email": "nina@example.com", "groups": [], "is_staff": false, "password": "", "username": "nina", "is_active": true, "last_name": "Kuznetsova", "first_name": "Nina", "last_login": null, "date_joined": "2025-09-17T08:25:36.271102+00:00", "is_superuser": false, "user_permissions": []}	{"id": 30, "email": "nina@example.com", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$HmXvyZKCmmKNr3qNs5wNzj$VXlDurZSrjlmqh5o8fyxNIxqrPNyZb4YoAyCfqRHMHM=", "username": "nina", "is_active": true, "last_name": "Kuznetsova", "first_name": "Nina", "last_login": null, "date_joined": "2025-09-17T08:25:36.271102+00:00", "is_superuser": false, "user_permissions": []}	2025-09-17 11:25:36.869002+03	\N	незнакомец
221	CREATE	User	31	\N	{"id": 31, "email": "oleg@example.com", "groups": [], "is_staff": false, "password": "", "username": "oleg", "is_active": true, "last_name": "Karpov", "first_name": "Oleg", "last_login": null, "date_joined": "2025-09-17T08:25:36.870276+00:00", "is_superuser": false, "user_permissions": []}	2025-09-17 11:25:36.873927+03	\N	незнакомец
222	UPDATE	User	31	{"id": 31, "email": "oleg@example.com", "groups": [], "is_staff": false, "password": "", "username": "oleg", "is_active": true, "last_name": "Karpov", "first_name": "Oleg", "last_login": null, "date_joined": "2025-09-17T08:25:36.870276+00:00", "is_superuser": false, "user_permissions": []}	{"id": 31, "email": "oleg@example.com", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$cB1FRwVtjafWiYYd8OjC5k$KAlpfPW5bKa4BcFNwZnQAtdT4gDnh/5mUhUp/g7d1J4=", "username": "oleg", "is_active": true, "last_name": "Karpov", "first_name": "Oleg", "last_login": null, "date_joined": "2025-09-17T08:25:36.870276+00:00", "is_superuser": false, "user_permissions": []}	2025-09-17 11:25:37.477819+03	\N	незнакомец
223	CREATE	User	32	\N	{"id": 32, "email": "pavel@example.com", "groups": [], "is_staff": false, "password": "", "username": "pavel", "is_active": true, "last_name": "Denisov", "first_name": "Pavel", "last_login": null, "date_joined": "2025-09-17T08:25:37.479962+00:00", "is_superuser": false, "user_permissions": []}	2025-09-17 11:25:37.483476+03	\N	незнакомец
224	UPDATE	User	32	{"id": 32, "email": "pavel@example.com", "groups": [], "is_staff": false, "password": "", "username": "pavel", "is_active": true, "last_name": "Denisov", "first_name": "Pavel", "last_login": null, "date_joined": "2025-09-17T08:25:37.479962+00:00", "is_superuser": false, "user_permissions": []}	{"id": 32, "email": "pavel@example.com", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$L2vsAzCcgGU2GMfgzNkT2F$kioaBQjeaX5m/OYQEw7giVQ3HI2+nDHlpT3aksCDZSQ=", "username": "pavel", "is_active": true, "last_name": "Denisov", "first_name": "Pavel", "last_login": null, "date_joined": "2025-09-17T08:25:37.479962+00:00", "is_superuser": false, "user_permissions": []}	2025-09-17 11:25:38.087233+03	\N	незнакомец
225	CREATE	User	33	\N	{"id": 33, "email": "rita@example.com", "groups": [], "is_staff": false, "password": "", "username": "rita", "is_active": true, "last_name": "Sorokina", "first_name": "Rita", "last_login": null, "date_joined": "2025-09-17T08:25:38.088494+00:00", "is_superuser": false, "user_permissions": []}	2025-09-17 11:25:38.0908+03	\N	незнакомец
226	UPDATE	User	33	{"id": 33, "email": "rita@example.com", "groups": [], "is_staff": false, "password": "", "username": "rita", "is_active": true, "last_name": "Sorokina", "first_name": "Rita", "last_login": null, "date_joined": "2025-09-17T08:25:38.088494+00:00", "is_superuser": false, "user_permissions": []}	{"id": 33, "email": "rita@example.com", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$FXAXyNT1aawPEbCZ9bPDHt$yG+2VRlekWLvBeFHyzdYow4XhDz3w8t7fTrFC8fXuHw=", "username": "rita", "is_active": true, "last_name": "Sorokina", "first_name": "Rita", "last_login": null, "date_joined": "2025-09-17T08:25:38.088494+00:00", "is_superuser": false, "user_permissions": []}	2025-09-17 11:25:38.687367+03	\N	незнакомец
231	CREATE	UserRole	40	\N	{"id": 40, "role": 3, "user": 28}	2025-09-17 11:25:38.697332+03	\N	незнакомец
232	CREATE	UserRole	41	\N	{"id": 41, "role": 3, "user": 29}	2025-09-17 11:25:38.699532+03	\N	незнакомец
233	CREATE	UserRole	42	\N	{"id": 42, "role": 3, "user": 30}	2025-09-17 11:25:38.701394+03	\N	незнакомец
234	CREATE	UserRole	43	\N	{"id": 43, "role": 3, "user": 31}	2025-09-17 11:25:38.703655+03	\N	незнакомец
235	CREATE	UserRole	44	\N	{"id": 44, "role": 3, "user": 32}	2025-09-17 11:25:38.705907+03	\N	незнакомец
236	CREATE	UserRole	45	\N	{"id": 45, "role": 3, "user": 33}	2025-09-17 11:25:38.707832+03	\N	незнакомец
237	CREATE	UserRole	46	\N	{"id": 46, "role": 2, "user": 24}	2025-09-17 11:25:38.709724+03	\N	незнакомец
238	CREATE	Make	3	\N	{"id": 3, "name": "Toyota"}	2025-09-17 11:25:38.728095+03	\N	незнакомец
239	CREATE	Model	3	\N	{"id": 3, "make": 3, "name": "Camry"}	2025-09-17 11:25:38.73234+03	\N	незнакомец
240	CREATE	Model	4	\N	{"id": 4, "make": 3, "name": "Corolla"}	2025-09-17 11:25:38.734615+03	\N	незнакомец
241	CREATE	Model	5	\N	{"id": 5, "make": 3, "name": "RAV4"}	2025-09-17 11:25:38.736714+03	\N	незнакомец
242	CREATE	Make	4	\N	{"id": 4, "name": "BMW"}	2025-09-17 11:25:38.738508+03	\N	незнакомец
243	CREATE	Model	6	\N	{"id": 6, "make": 4, "name": "3 Series"}	2025-09-17 11:25:38.740403+03	\N	незнакомец
244	CREATE	Model	7	\N	{"id": 7, "make": 4, "name": "5 Series"}	2025-09-17 11:25:38.742304+03	\N	незнакомец
245	CREATE	Model	8	\N	{"id": 8, "make": 4, "name": "X3"}	2025-09-17 11:25:38.744206+03	\N	незнакомец
246	CREATE	Make	5	\N	{"id": 5, "name": "Audi"}	2025-09-17 11:25:38.745951+03	\N	незнакомец
247	CREATE	Model	9	\N	{"id": 9, "make": 5, "name": "A4"}	2025-09-17 11:25:38.748144+03	\N	незнакомец
248	CREATE	Model	10	\N	{"id": 10, "make": 5, "name": "A6"}	2025-09-17 11:25:38.750747+03	\N	незнакомец
249	CREATE	Model	11	\N	{"id": 11, "make": 5, "name": "Q5"}	2025-09-17 11:25:38.752714+03	\N	незнакомец
250	CREATE	Make	6	\N	{"id": 6, "name": "Mercedes-Benz"}	2025-09-17 11:25:38.754514+03	\N	незнакомец
251	CREATE	Model	12	\N	{"id": 12, "make": 6, "name": "C-Class"}	2025-09-17 11:25:38.75643+03	\N	незнакомец
252	CREATE	Model	13	\N	{"id": 13, "make": 6, "name": "E-Class"}	2025-09-17 11:25:38.758319+03	\N	незнакомец
253	CREATE	Model	14	\N	{"id": 14, "make": 6, "name": "GLC"}	2025-09-17 11:25:38.760199+03	\N	незнакомец
254	CREATE	Make	7	\N	{"id": 7, "name": "Kia"}	2025-09-17 11:25:38.76195+03	\N	незнакомец
255	CREATE	Model	15	\N	{"id": 15, "make": 7, "name": "Rio"}	2025-09-17 11:25:38.76398+03	\N	незнакомец
256	CREATE	Model	16	\N	{"id": 16, "make": 7, "name": "Sportage"}	2025-09-17 11:25:38.766999+03	\N	незнакомец
257	CREATE	Make	8	\N	{"id": 8, "name": "Hyundai"}	2025-09-17 11:25:38.768889+03	\N	незнакомец
258	CREATE	Model	17	\N	{"id": 17, "make": 8, "name": "Solaris"}	2025-09-17 11:25:38.770835+03	\N	незнакомец
259	CREATE	Model	18	\N	{"id": 18, "make": 8, "name": "Tucson"}	2025-09-17 11:25:38.7727+03	\N	незнакомец
260	CREATE	Make	9	\N	{"id": 9, "name": "Volkswagen"}	2025-09-17 11:25:38.774559+03	\N	незнакомец
261	CREATE	Model	19	\N	{"id": 19, "make": 9, "name": "Polo"}	2025-09-17 11:25:38.776386+03	\N	незнакомец
262	CREATE	Model	20	\N	{"id": 20, "make": 9, "name": "Tiguan"}	2025-09-17 11:25:38.778275+03	\N	незнакомец
263	CREATE	Make	10	\N	{"id": 10, "name": "LADA"}	2025-09-17 11:25:38.780017+03	\N	незнакомец
264	CREATE	Model	21	\N	{"id": 21, "make": 10, "name": "Vesta"}	2025-09-17 11:25:38.782572+03	\N	незнакомец
265	CREATE	Model	22	\N	{"id": 22, "make": 10, "name": "Granta"}	2025-09-17 11:25:38.784518+03	\N	незнакомец
266	CREATE	Car	DEMO201500000XXXX	\N	{"VIN": "DEMO201500000XXXX", "make": 4, "year": 2015, "model": 6, "price": 1336213, "seller": 26, "status": "available", "description": "BMW 3 Series, 2015 г.в. Тестовое объявление."}	2025-09-17 11:25:38.791359+03	\N	незнакомец
267	CREATE	Car	DEMO201300001XXXX	\N	{"VIN": "DEMO201300001XXXX", "make": 4, "year": 2013, "model": 8, "price": 2876705, "seller": 28, "status": "available", "description": "BMW X3, 2013 г.в. Тестовое объявление."}	2025-09-17 11:25:38.793601+03	\N	незнакомец
268	CREATE	Car	DEMO201500002XXXX	\N	{"VIN": "DEMO201500002XXXX", "make": 3, "year": 2015, "model": 3, "price": 1375850, "seller": 24, "status": "available", "description": "Toyota Camry, 2015 г.в. Тестовое объявление."}	2025-09-17 11:25:38.795722+03	\N	незнакомец
269	CREATE	Car	DEMO202300003XXXX	\N	{"VIN": "DEMO202300003XXXX", "make": 3, "year": 2023, "model": 5, "price": 3125812, "seller": 25, "status": "available", "description": "Toyota RAV4, 2023 г.в. Тестовое объявление."}	2025-09-17 11:25:38.799042+03	\N	незнакомец
270	CREATE	Car	DEMO202100004XXXX	\N	{"VIN": "DEMO202100004XXXX", "make": 9, "year": 2021, "model": 19, "price": 1566816, "seller": 27, "status": "available", "description": "Volkswagen Polo, 2021 г.в. Тестовое объявление."}	2025-09-17 11:25:38.802444+03	\N	незнакомец
271	CREATE	Car	DEMO201700005XXXX	\N	{"VIN": "DEMO201700005XXXX", "make": 5, "year": 2017, "model": 11, "price": 1565476, "seller": 27, "status": "available", "description": "Audi Q5, 2017 г.в. Тестовое объявление."}	2025-09-17 11:25:38.805571+03	\N	незнакомец
272	CREATE	Car	DEMO201300006XXXX	\N	{"VIN": "DEMO201300006XXXX", "make": 6, "year": 2013, "model": 13, "price": 1993530, "seller": 24, "status": "available", "description": "Mercedes-Benz E-Class, 2013 г.в. Тестовое объявление."}	2025-09-17 11:25:38.809498+03	\N	незнакомец
353	CREATE	Transaction	6	\N	{"id": 6, "order": 19, "amount": 1063361, "status": "completed"}	2025-09-17 11:25:39.01303+03	\N	незнакомец
273	CREATE	Car	DEMO201600007XXXX	\N	{"VIN": "DEMO201600007XXXX", "make": 8, "year": 2016, "model": 18, "price": 582244, "seller": 28, "status": "available", "description": "Hyundai Tucson, 2016 г.в. Тестовое объявление."}	2025-09-17 11:25:38.81318+03	\N	незнакомец
274	CREATE	Car	DEMO202000008XXXX	\N	{"VIN": "DEMO202000008XXXX", "make": 4, "year": 2020, "model": 7, "price": 1629678, "seller": 24, "status": "available", "description": "BMW 5 Series, 2020 г.в. Тестовое объявление."}	2025-09-17 11:25:38.817517+03	\N	незнакомец
275	CREATE	Car	DEMO201200009XXXX	\N	{"VIN": "DEMO201200009XXXX", "make": 8, "year": 2012, "model": 17, "price": 3173539, "seller": 24, "status": "available", "description": "Hyundai Solaris, 2012 г.в. Тестовое объявление."}	2025-09-17 11:25:38.819851+03	\N	незнакомец
276	CREATE	Car	DEMO201300010XXXX	\N	{"VIN": "DEMO201300010XXXX", "make": 7, "year": 2013, "model": 15, "price": 1994364, "seller": 25, "status": "available", "description": "Kia Rio, 2013 г.в. Тестовое объявление."}	2025-09-17 11:25:38.82185+03	\N	незнакомец
277	CREATE	Car	DEMO201700011XXXX	\N	{"VIN": "DEMO201700011XXXX", "make": 10, "year": 2017, "model": 22, "price": 1890113, "seller": 25, "status": "available", "description": "LADA Granta, 2017 г.в. Тестовое объявление."}	2025-09-17 11:25:38.824076+03	\N	незнакомец
278	CREATE	Car	DEMO202200012XXXX	\N	{"VIN": "DEMO202200012XXXX", "make": 7, "year": 2022, "model": 15, "price": 1117807, "seller": 28, "status": "available", "description": "Kia Rio, 2022 г.в. Тестовое объявление."}	2025-09-17 11:25:38.8261+03	\N	незнакомец
279	CREATE	Car	DEMO201800013XXXX	\N	{"VIN": "DEMO201800013XXXX", "make": 6, "year": 2018, "model": 12, "price": 1532243, "seller": 27, "status": "available", "description": "Mercedes-Benz C-Class, 2018 г.в. Тестовое объявление."}	2025-09-17 11:25:38.828506+03	\N	незнакомец
280	CREATE	Car	DEMO201200014XXXX	\N	{"VIN": "DEMO201200014XXXX", "make": 6, "year": 2012, "model": 14, "price": 1360697, "seller": 26, "status": "available", "description": "Mercedes-Benz GLC, 2012 г.в. Тестовое объявление."}	2025-09-17 11:25:38.830638+03	\N	незнакомец
281	CREATE	Car	DEMO201300015XXXX	\N	{"VIN": "DEMO201300015XXXX", "make": 8, "year": 2013, "model": 18, "price": 1284926, "seller": 26, "status": "available", "description": "Hyundai Tucson, 2013 г.в. Тестовое объявление."}	2025-09-17 11:25:38.833733+03	\N	незнакомец
282	CREATE	Car	DEMO201800016XXXX	\N	{"VIN": "DEMO201800016XXXX", "make": 8, "year": 2018, "model": 17, "price": 3096316, "seller": 27, "status": "available", "description": "Hyundai Solaris, 2018 г.в. Тестовое объявление."}	2025-09-17 11:25:38.83596+03	\N	незнакомец
283	CREATE	Car	DEMO201500017XXXX	\N	{"VIN": "DEMO201500017XXXX", "make": 5, "year": 2015, "model": 10, "price": 2754548, "seller": 25, "status": "available", "description": "Audi A6, 2015 г.в. Тестовое объявление."}	2025-09-17 11:25:38.838011+03	\N	незнакомец
284	CREATE	Car	DEMO201800018XXXX	\N	{"VIN": "DEMO201800018XXXX", "make": 7, "year": 2018, "model": 16, "price": 1918323, "seller": 28, "status": "available", "description": "Kia Sportage, 2018 г.в. Тестовое объявление."}	2025-09-17 11:25:38.840005+03	\N	незнакомец
285	CREATE	Car	DEMO201300019XXXX	\N	{"VIN": "DEMO201300019XXXX", "make": 5, "year": 2013, "model": 11, "price": 597620, "seller": 27, "status": "available", "description": "Audi Q5, 2013 г.в. Тестовое объявление."}	2025-09-17 11:25:38.842359+03	\N	незнакомец
286	CREATE	Car	DEMO202200020XXXX	\N	{"VIN": "DEMO202200020XXXX", "make": 5, "year": 2022, "model": 11, "price": 2170667, "seller": 25, "status": "available", "description": "Audi Q5, 2022 г.в. Тестовое объявление."}	2025-09-17 11:25:38.844876+03	\N	незнакомец
287	CREATE	Car	DEMO202100021XXXX	\N	{"VIN": "DEMO202100021XXXX", "make": 4, "year": 2021, "model": 7, "price": 2363143, "seller": 27, "status": "available", "description": "BMW 5 Series, 2021 г.в. Тестовое объявление."}	2025-09-17 11:25:38.846912+03	\N	незнакомец
288	CREATE	Car	DEMO202200022XXXX	\N	{"VIN": "DEMO202200022XXXX", "make": 7, "year": 2022, "model": 15, "price": 2652216, "seller": 24, "status": "available", "description": "Kia Rio, 2022 г.в. Тестовое объявление."}	2025-09-17 11:25:38.849338+03	\N	незнакомец
289	CREATE	Car	DEMO201800023XXXX	\N	{"VIN": "DEMO201800023XXXX", "make": 8, "year": 2018, "model": 17, "price": 1063361, "seller": 26, "status": "available", "description": "Hyundai Solaris, 2018 г.в. Тестовое объявление."}	2025-09-17 11:25:38.852939+03	\N	незнакомец
290	CREATE	Car	DEMO202000024XXXX	\N	{"VIN": "DEMO202000024XXXX", "make": 3, "year": 2020, "model": 5, "price": 1149320, "seller": 26, "status": "available", "description": "Toyota RAV4, 2020 г.в. Тестовое объявление."}	2025-09-17 11:25:38.855159+03	\N	незнакомец
291	CREATE	Car	DEMO202200025XXXX	\N	{"VIN": "DEMO202200025XXXX", "make": 4, "year": 2022, "model": 8, "price": 2529292, "seller": 26, "status": "available", "description": "BMW X3, 2022 г.в. Тестовое объявление."}	2025-09-17 11:25:38.857254+03	\N	незнакомец
292	CREATE	Car	DEMO201400026XXXX	\N	{"VIN": "DEMO201400026XXXX", "make": 6, "year": 2014, "model": 12, "price": 2662319, "seller": 26, "status": "available", "description": "Mercedes-Benz C-Class, 2014 г.в. Тестовое объявление."}	2025-09-17 11:25:38.860147+03	\N	незнакомец
293	CREATE	Car	DEMO201900027XXXX	\N	{"VIN": "DEMO201900027XXXX", "make": 3, "year": 2019, "model": 5, "price": 481691, "seller": 26, "status": "available", "description": "Toyota RAV4, 2019 г.в. Тестовое объявление."}	2025-09-17 11:25:38.862195+03	\N	незнакомец
294	CREATE	Car	DEMO201200028XXXX	\N	{"VIN": "DEMO201200028XXXX", "make": 8, "year": 2012, "model": 18, "price": 1410288, "seller": 25, "status": "available", "description": "Hyundai Tucson, 2012 г.в. Тестовое объявление."}	2025-09-17 11:25:38.864578+03	\N	незнакомец
395	CREATE	UserRole	47	\N	{"id": 47, "role": 1, "user": 34}	2025-09-17 11:27:31.072228+03	\N	незнакомец
295	CREATE	Car	DEMO201300029XXXX	\N	{"VIN": "DEMO201300029XXXX", "make": 4, "year": 2013, "model": 6, "price": 2634331, "seller": 27, "status": "available", "description": "BMW 3 Series, 2013 г.в. Тестовое объявление."}	2025-09-17 11:25:38.866671+03	\N	незнакомец
296	CREATE	Car	DEMO202000030XXXX	\N	{"VIN": "DEMO202000030XXXX", "make": 5, "year": 2020, "model": 11, "price": 1092592, "seller": 27, "status": "available", "description": "Audi Q5, 2020 г.в. Тестовое объявление."}	2025-09-17 11:25:38.868678+03	\N	незнакомец
297	CREATE	Car	DEMO202300031XXXX	\N	{"VIN": "DEMO202300031XXXX", "make": 9, "year": 2023, "model": 19, "price": 3293514, "seller": 28, "status": "available", "description": "Volkswagen Polo, 2023 г.в. Тестовое объявление."}	2025-09-17 11:25:38.870668+03	\N	незнакомец
298	CREATE	Car	DEMO201900032XXXX	\N	{"VIN": "DEMO201900032XXXX", "make": 7, "year": 2019, "model": 16, "price": 2570870, "seller": 26, "status": "available", "description": "Kia Sportage, 2019 г.в. Тестовое объявление."}	2025-09-17 11:25:38.872669+03	\N	незнакомец
299	CREATE	Car	DEMO201300033XXXX	\N	{"VIN": "DEMO201300033XXXX", "make": 4, "year": 2013, "model": 6, "price": 1818033, "seller": 25, "status": "available", "description": "BMW 3 Series, 2013 г.в. Тестовое объявление."}	2025-09-17 11:25:38.876042+03	\N	незнакомец
300	CREATE	Car	DEMO201200034XXXX	\N	{"VIN": "DEMO201200034XXXX", "make": 6, "year": 2012, "model": 14, "price": 697766, "seller": 25, "status": "available", "description": "Mercedes-Benz GLC, 2012 г.в. Тестовое объявление."}	2025-09-17 11:25:38.878585+03	\N	незнакомец
301	CREATE	Car	DEMO201200035XXXX	\N	{"VIN": "DEMO201200035XXXX", "make": 3, "year": 2012, "model": 3, "price": 1785917, "seller": 24, "status": "available", "description": "Toyota Camry, 2012 г.в. Тестовое объявление."}	2025-09-17 11:25:38.880923+03	\N	незнакомец
302	CREATE	Car	DEMO201500036XXXX	\N	{"VIN": "DEMO201500036XXXX", "make": 6, "year": 2015, "model": 13, "price": 2661711, "seller": 27, "status": "available", "description": "Mercedes-Benz E-Class, 2015 г.в. Тестовое объявление."}	2025-09-17 11:25:38.883056+03	\N	незнакомец
303	CREATE	Car	DEMO201800037XXXX	\N	{"VIN": "DEMO201800037XXXX", "make": 10, "year": 2018, "model": 21, "price": 1198637, "seller": 27, "status": "available", "description": "LADA Vesta, 2018 г.в. Тестовое объявление."}	2025-09-17 11:25:38.885083+03	\N	незнакомец
304	CREATE	Car	DEMO201700038XXXX	\N	{"VIN": "DEMO201700038XXXX", "make": 4, "year": 2017, "model": 8, "price": 2176617, "seller": 27, "status": "available", "description": "BMW X3, 2017 г.в. Тестовое объявление."}	2025-09-17 11:25:38.887084+03	\N	незнакомец
305	CREATE	Car	DEMO201200039XXXX	\N	{"VIN": "DEMO201200039XXXX", "make": 10, "year": 2012, "model": 21, "price": 2088716, "seller": 24, "status": "available", "description": "LADA Vesta, 2012 г.в. Тестовое объявление."}	2025-09-17 11:25:38.889243+03	\N	незнакомец
306	UPDATE	Car	DEMO201300001XXXX	{"VIN": "DEMO201300001XXXX", "make": 4, "year": 2013, "model": 8, "price": 2876705.0, "seller": 28, "status": "available", "description": "BMW X3, 2013 г.в. Тестовое объявление."}	{"VIN": "DEMO201300001XXXX", "make": 4, "year": 2013, "model": 8, "price": 2876705, "seller": 28, "status": "reserved", "description": "BMW X3, 2013 г.в. Тестовое объявление."}	2025-09-17 11:25:38.893179+03	\N	незнакомец
307	CREATE	Order	7	\N	{"id": 7, "car": "DEMO201300001XXXX", "buyer": 30, "status": "pending", "total_amount": 2876705}	2025-09-17 11:25:38.896415+03	\N	незнакомец
308	UPDATE	Car	DEMO201300001XXXX	{"VIN": "DEMO201300001XXXX", "make": 4, "year": 2013, "model": 8, "price": 2876705.0, "seller": 28, "status": "reserved", "description": "BMW X3, 2013 г.в. Тестовое объявление."}	{"VIN": "DEMO201300001XXXX", "make": 4, "year": 2013, "model": 8, "price": 2876705.0, "seller": 28, "status": "sold", "description": "BMW X3, 2013 г.в. Тестовое объявление."}	2025-09-17 11:25:38.902791+03	\N	незнакомец
309	UPDATE	Order	7	{"id": 7, "car": "DEMO201300001XXXX", "buyer": 30, "status": "pending", "total_amount": 2876705.0}	{"id": 7, "car": "DEMO201300001XXXX", "buyer": 30, "status": "paid", "total_amount": 2876705.0}	2025-09-17 11:25:38.907656+03	\N	незнакомец
310	CREATE	Transaction	3	\N	{"id": 3, "order": 7, "amount": 2876705, "status": "completed"}	2025-09-17 11:25:38.910387+03	\N	незнакомец
311	UPDATE	Car	DEMO201500002XXXX	{"VIN": "DEMO201500002XXXX", "make": 3, "year": 2015, "model": 3, "price": 1375850.0, "seller": 24, "status": "available", "description": "Toyota Camry, 2015 г.в. Тестовое объявление."}	{"VIN": "DEMO201500002XXXX", "make": 3, "year": 2015, "model": 3, "price": 1375850, "seller": 24, "status": "reserved", "description": "Toyota Camry, 2015 г.в. Тестовое объявление."}	2025-09-17 11:25:38.913085+03	\N	незнакомец
312	CREATE	Order	8	\N	{"id": 8, "car": "DEMO201500002XXXX", "buyer": 30, "status": "pending", "total_amount": 1375850}	2025-09-17 11:25:38.914376+03	\N	незнакомец
313	UPDATE	Car	DEMO202100004XXXX	{"VIN": "DEMO202100004XXXX", "make": 9, "year": 2021, "model": 19, "price": 1566816.0, "seller": 27, "status": "available", "description": "Volkswagen Polo, 2021 г.в. Тестовое объявление."}	{"VIN": "DEMO202100004XXXX", "make": 9, "year": 2021, "model": 19, "price": 1566816, "seller": 27, "status": "reserved", "description": "Volkswagen Polo, 2021 г.в. Тестовое объявление."}	2025-09-17 11:25:38.91807+03	\N	незнакомец
314	CREATE	Order	9	\N	{"id": 9, "car": "DEMO202100004XXXX", "buyer": 33, "status": "pending", "total_amount": 1566816}	2025-09-17 11:25:38.919044+03	\N	незнакомец
352	UPDATE	Order	19	{"id": 19, "car": "DEMO201800023XXXX", "buyer": 33, "status": "pending", "total_amount": 1063361.0}	{"id": 19, "car": "DEMO201800023XXXX", "buyer": 33, "status": "paid", "total_amount": 1063361.0}	2025-09-17 11:25:39.011521+03	\N	незнакомец
396	CREATE	UserRole	48	\N	{"id": 48, "role": 2, "user": 22}	2025-09-17 11:29:32.641282+03	34	admin:321
315	UPDATE	Car	DEMO202100004XXXX	{"VIN": "DEMO202100004XXXX", "make": 9, "year": 2021, "model": 19, "price": 1566816.0, "seller": 27, "status": "reserved", "description": "Volkswagen Polo, 2021 г.в. Тестовое объявление."}	{"VIN": "DEMO202100004XXXX", "make": 9, "year": 2021, "model": 19, "price": 1566816, "seller": 27, "status": "available", "description": "Volkswagen Polo, 2021 г.в. Тестовое объявление."}	2025-09-17 11:25:38.921993+03	\N	незнакомец
316	UPDATE	Order	9	{"id": 9, "car": "DEMO202100004XXXX", "buyer": 33, "status": "pending", "total_amount": 1566816.0}	{"id": 9, "car": "DEMO202100004XXXX", "buyer": 33, "status": "cancelled", "total_amount": 1566816}	2025-09-17 11:25:38.923719+03	\N	незнакомец
317	UPDATE	Car	DEMO201300010XXXX	{"VIN": "DEMO201300010XXXX", "make": 7, "year": 2013, "model": 15, "price": 1994364.0, "seller": 25, "status": "available", "description": "Kia Rio, 2013 г.в. Тестовое объявление."}	{"VIN": "DEMO201300010XXXX", "make": 7, "year": 2013, "model": 15, "price": 1994364, "seller": 25, "status": "reserved", "description": "Kia Rio, 2013 г.в. Тестовое объявление."}	2025-09-17 11:25:38.926199+03	\N	незнакомец
318	CREATE	Order	10	\N	{"id": 10, "car": "DEMO201300010XXXX", "buyer": 32, "status": "pending", "total_amount": 1994364}	2025-09-17 11:25:38.927164+03	\N	незнакомец
319	UPDATE	Car	DEMO201700011XXXX	{"VIN": "DEMO201700011XXXX", "make": 10, "year": 2017, "model": 22, "price": 1890113.0, "seller": 25, "status": "available", "description": "LADA Granta, 2017 г.в. Тестовое объявление."}	{"VIN": "DEMO201700011XXXX", "make": 10, "year": 2017, "model": 22, "price": 1890113, "seller": 25, "status": "reserved", "description": "LADA Granta, 2017 г.в. Тестовое объявление."}	2025-09-17 11:25:38.930982+03	\N	незнакомец
320	CREATE	Order	11	\N	{"id": 11, "car": "DEMO201700011XXXX", "buyer": 29, "status": "pending", "total_amount": 1890113}	2025-09-17 11:25:38.931969+03	\N	незнакомец
321	UPDATE	Car	DEMO201800013XXXX	{"VIN": "DEMO201800013XXXX", "make": 6, "year": 2018, "model": 12, "price": 1532243.0, "seller": 27, "status": "available", "description": "Mercedes-Benz C-Class, 2018 г.в. Тестовое объявление."}	{"VIN": "DEMO201800013XXXX", "make": 6, "year": 2018, "model": 12, "price": 1532243, "seller": 27, "status": "reserved", "description": "Mercedes-Benz C-Class, 2018 г.в. Тестовое объявление."}	2025-09-17 11:25:38.935961+03	\N	незнакомец
322	CREATE	Order	12	\N	{"id": 12, "car": "DEMO201800013XXXX", "buyer": 32, "status": "pending", "total_amount": 1532243}	2025-09-17 11:25:38.937068+03	\N	незнакомец
323	UPDATE	Car	DEMO201800016XXXX	{"VIN": "DEMO201800016XXXX", "make": 8, "year": 2018, "model": 17, "price": 3096316.0, "seller": 27, "status": "available", "description": "Hyundai Solaris, 2018 г.в. Тестовое объявление."}	{"VIN": "DEMO201800016XXXX", "make": 8, "year": 2018, "model": 17, "price": 3096316, "seller": 27, "status": "reserved", "description": "Hyundai Solaris, 2018 г.в. Тестовое объявление."}	2025-09-17 11:25:38.940672+03	\N	незнакомец
324	CREATE	Order	13	\N	{"id": 13, "car": "DEMO201800016XXXX", "buyer": 32, "status": "pending", "total_amount": 3096316}	2025-09-17 11:25:38.94164+03	\N	незнакомец
325	UPDATE	Car	DEMO201800016XXXX	{"VIN": "DEMO201800016XXXX", "make": 8, "year": 2018, "model": 17, "price": 3096316.0, "seller": 27, "status": "reserved", "description": "Hyundai Solaris, 2018 г.в. Тестовое объявление."}	{"VIN": "DEMO201800016XXXX", "make": 8, "year": 2018, "model": 17, "price": 3096316, "seller": 27, "status": "available", "description": "Hyundai Solaris, 2018 г.в. Тестовое объявление."}	2025-09-17 11:25:38.944397+03	\N	незнакомец
326	UPDATE	Order	13	{"id": 13, "car": "DEMO201800016XXXX", "buyer": 32, "status": "pending", "total_amount": 3096316.0}	{"id": 13, "car": "DEMO201800016XXXX", "buyer": 32, "status": "cancelled", "total_amount": 3096316}	2025-09-17 11:25:38.946003+03	\N	незнакомец
327	UPDATE	Car	DEMO201500017XXXX	{"VIN": "DEMO201500017XXXX", "make": 5, "year": 2015, "model": 10, "price": 2754548.0, "seller": 25, "status": "available", "description": "Audi A6, 2015 г.в. Тестовое объявление."}	{"VIN": "DEMO201500017XXXX", "make": 5, "year": 2015, "model": 10, "price": 2754548, "seller": 25, "status": "reserved", "description": "Audi A6, 2015 г.в. Тестовое объявление."}	2025-09-17 11:25:38.948825+03	\N	незнакомец
328	CREATE	Order	14	\N	{"id": 14, "car": "DEMO201500017XXXX", "buyer": 29, "status": "pending", "total_amount": 2754548}	2025-09-17 11:25:38.949804+03	\N	незнакомец
329	UPDATE	Car	DEMO201500017XXXX	{"VIN": "DEMO201500017XXXX", "make": 5, "year": 2015, "model": 10, "price": 2754548.0, "seller": 25, "status": "reserved", "description": "Audi A6, 2015 г.в. Тестовое объявление."}	{"VIN": "DEMO201500017XXXX", "make": 5, "year": 2015, "model": 10, "price": 2754548.0, "seller": 25, "status": "sold", "description": "Audi A6, 2015 г.в. Тестовое объявление."}	2025-09-17 11:25:38.954978+03	\N	незнакомец
330	UPDATE	Order	14	{"id": 14, "car": "DEMO201500017XXXX", "buyer": 29, "status": "pending", "total_amount": 2754548.0}	{"id": 14, "car": "DEMO201500017XXXX", "buyer": 29, "status": "paid", "total_amount": 2754548.0}	2025-09-17 11:25:38.959041+03	\N	незнакомец
331	CREATE	Transaction	4	\N	{"id": 4, "order": 14, "amount": 2754548, "status": "completed"}	2025-09-17 11:25:38.959982+03	\N	незнакомец
332	UPDATE	Car	DEMO201800018XXXX	{"VIN": "DEMO201800018XXXX", "make": 7, "year": 2018, "model": 16, "price": 1918323.0, "seller": 28, "status": "available", "description": "Kia Sportage, 2018 г.в. Тестовое объявление."}	{"VIN": "DEMO201800018XXXX", "make": 7, "year": 2018, "model": 16, "price": 1918323, "seller": 28, "status": "reserved", "description": "Kia Sportage, 2018 г.в. Тестовое объявление."}	2025-09-17 11:25:38.962581+03	\N	незнакомец
333	CREATE	Order	15	\N	{"id": 15, "car": "DEMO201800018XXXX", "buyer": 31, "status": "pending", "total_amount": 1918323}	2025-09-17 11:25:38.9636+03	\N	незнакомец
334	UPDATE	Car	DEMO201800018XXXX	{"VIN": "DEMO201800018XXXX", "make": 7, "year": 2018, "model": 16, "price": 1918323.0, "seller": 28, "status": "reserved", "description": "Kia Sportage, 2018 г.в. Тестовое объявление."}	{"VIN": "DEMO201800018XXXX", "make": 7, "year": 2018, "model": 16, "price": 1918323, "seller": 28, "status": "available", "description": "Kia Sportage, 2018 г.в. Тестовое объявление."}	2025-09-17 11:25:38.966835+03	\N	незнакомец
335	UPDATE	Order	15	{"id": 15, "car": "DEMO201800018XXXX", "buyer": 31, "status": "pending", "total_amount": 1918323.0}	{"id": 15, "car": "DEMO201800018XXXX", "buyer": 31, "status": "cancelled", "total_amount": 1918323}	2025-09-17 11:25:38.969297+03	\N	незнакомец
336	UPDATE	Car	DEMO201300019XXXX	{"VIN": "DEMO201300019XXXX", "make": 5, "year": 2013, "model": 11, "price": 597620.0, "seller": 27, "status": "available", "description": "Audi Q5, 2013 г.в. Тестовое объявление."}	{"VIN": "DEMO201300019XXXX", "make": 5, "year": 2013, "model": 11, "price": 597620, "seller": 27, "status": "reserved", "description": "Audi Q5, 2013 г.в. Тестовое объявление."}	2025-09-17 11:25:38.971843+03	\N	незнакомец
337	CREATE	Order	16	\N	{"id": 16, "car": "DEMO201300019XXXX", "buyer": 33, "status": "pending", "total_amount": 597620}	2025-09-17 11:25:38.972805+03	\N	незнакомец
338	UPDATE	Car	DEMO201300019XXXX	{"VIN": "DEMO201300019XXXX", "make": 5, "year": 2013, "model": 11, "price": 597620.0, "seller": 27, "status": "reserved", "description": "Audi Q5, 2013 г.в. Тестовое объявление."}	{"VIN": "DEMO201300019XXXX", "make": 5, "year": 2013, "model": 11, "price": 597620, "seller": 27, "status": "available", "description": "Audi Q5, 2013 г.в. Тестовое объявление."}	2025-09-17 11:25:38.975557+03	\N	незнакомец
339	UPDATE	Order	16	{"id": 16, "car": "DEMO201300019XXXX", "buyer": 33, "status": "pending", "total_amount": 597620.0}	{"id": 16, "car": "DEMO201300019XXXX", "buyer": 33, "status": "cancelled", "total_amount": 597620}	2025-09-17 11:25:38.977148+03	\N	незнакомец
340	UPDATE	Car	DEMO202200020XXXX	{"VIN": "DEMO202200020XXXX", "make": 5, "year": 2022, "model": 11, "price": 2170667.0, "seller": 25, "status": "available", "description": "Audi Q5, 2022 г.в. Тестовое объявление."}	{"VIN": "DEMO202200020XXXX", "make": 5, "year": 2022, "model": 11, "price": 2170667, "seller": 25, "status": "reserved", "description": "Audi Q5, 2022 г.в. Тестовое объявление."}	2025-09-17 11:25:38.979687+03	\N	незнакомец
341	CREATE	Order	17	\N	{"id": 17, "car": "DEMO202200020XXXX", "buyer": 30, "status": "pending", "total_amount": 2170667}	2025-09-17 11:25:38.981001+03	\N	незнакомец
342	UPDATE	Car	DEMO202200020XXXX	{"VIN": "DEMO202200020XXXX", "make": 5, "year": 2022, "model": 11, "price": 2170667.0, "seller": 25, "status": "reserved", "description": "Audi Q5, 2022 г.в. Тестовое объявление."}	{"VIN": "DEMO202200020XXXX", "make": 5, "year": 2022, "model": 11, "price": 2170667.0, "seller": 25, "status": "sold", "description": "Audi Q5, 2022 г.в. Тестовое объявление."}	2025-09-17 11:25:38.985457+03	\N	незнакомец
343	UPDATE	Order	17	{"id": 17, "car": "DEMO202200020XXXX", "buyer": 30, "status": "pending", "total_amount": 2170667.0}	{"id": 17, "car": "DEMO202200020XXXX", "buyer": 30, "status": "paid", "total_amount": 2170667.0}	2025-09-17 11:25:38.989532+03	\N	незнакомец
344	CREATE	Transaction	5	\N	{"id": 5, "order": 17, "amount": 2170667, "status": "completed"}	2025-09-17 11:25:38.990481+03	\N	незнакомец
345	UPDATE	Car	DEMO202100021XXXX	{"VIN": "DEMO202100021XXXX", "make": 4, "year": 2021, "model": 7, "price": 2363143.0, "seller": 27, "status": "available", "description": "BMW 5 Series, 2021 г.в. Тестовое объявление."}	{"VIN": "DEMO202100021XXXX", "make": 4, "year": 2021, "model": 7, "price": 2363143, "seller": 27, "status": "reserved", "description": "BMW 5 Series, 2021 г.в. Тестовое объявление."}	2025-09-17 11:25:38.993083+03	\N	незнакомец
346	CREATE	Order	18	\N	{"id": 18, "car": "DEMO202100021XXXX", "buyer": 30, "status": "pending", "total_amount": 2363143}	2025-09-17 11:25:38.994062+03	\N	незнакомец
347	UPDATE	Car	DEMO202100021XXXX	{"VIN": "DEMO202100021XXXX", "make": 4, "year": 2021, "model": 7, "price": 2363143.0, "seller": 27, "status": "reserved", "description": "BMW 5 Series, 2021 г.в. Тестовое объявление."}	{"VIN": "DEMO202100021XXXX", "make": 4, "year": 2021, "model": 7, "price": 2363143, "seller": 27, "status": "available", "description": "BMW 5 Series, 2021 г.в. Тестовое объявление."}	2025-09-17 11:25:38.996834+03	\N	незнакомец
348	UPDATE	Order	18	{"id": 18, "car": "DEMO202100021XXXX", "buyer": 30, "status": "pending", "total_amount": 2363143.0}	{"id": 18, "car": "DEMO202100021XXXX", "buyer": 30, "status": "cancelled", "total_amount": 2363143}	2025-09-17 11:25:38.999532+03	\N	незнакомец
349	UPDATE	Car	DEMO201800023XXXX	{"VIN": "DEMO201800023XXXX", "make": 8, "year": 2018, "model": 17, "price": 1063361.0, "seller": 26, "status": "available", "description": "Hyundai Solaris, 2018 г.в. Тестовое объявление."}	{"VIN": "DEMO201800023XXXX", "make": 8, "year": 2018, "model": 17, "price": 1063361, "seller": 26, "status": "reserved", "description": "Hyundai Solaris, 2018 г.в. Тестовое объявление."}	2025-09-17 11:25:39.002261+03	\N	незнакомец
350	CREATE	Order	19	\N	{"id": 19, "car": "DEMO201800023XXXX", "buyer": 33, "status": "pending", "total_amount": 1063361}	2025-09-17 11:25:39.003238+03	\N	незнакомец
351	UPDATE	Car	DEMO201800023XXXX	{"VIN": "DEMO201800023XXXX", "make": 8, "year": 2018, "model": 17, "price": 1063361.0, "seller": 26, "status": "reserved", "description": "Hyundai Solaris, 2018 г.в. Тестовое объявление."}	{"VIN": "DEMO201800023XXXX", "make": 8, "year": 2018, "model": 17, "price": 1063361.0, "seller": 26, "status": "sold", "description": "Hyundai Solaris, 2018 г.в. Тестовое объявление."}	2025-09-17 11:25:39.007161+03	\N	незнакомец
354	UPDATE	Car	DEMO202000024XXXX	{"VIN": "DEMO202000024XXXX", "make": 3, "year": 2020, "model": 5, "price": 1149320.0, "seller": 26, "status": "available", "description": "Toyota RAV4, 2020 г.в. Тестовое объявление."}	{"VIN": "DEMO202000024XXXX", "make": 3, "year": 2020, "model": 5, "price": 1149320, "seller": 26, "status": "reserved", "description": "Toyota RAV4, 2020 г.в. Тестовое объявление."}	2025-09-17 11:25:39.016666+03	\N	незнакомец
355	CREATE	Order	20	\N	{"id": 20, "car": "DEMO202000024XXXX", "buyer": 33, "status": "pending", "total_amount": 1149320}	2025-09-17 11:25:39.018052+03	\N	незнакомец
356	UPDATE	Car	DEMO202000024XXXX	{"VIN": "DEMO202000024XXXX", "make": 3, "year": 2020, "model": 5, "price": 1149320.0, "seller": 26, "status": "reserved", "description": "Toyota RAV4, 2020 г.в. Тестовое объявление."}	{"VIN": "DEMO202000024XXXX", "make": 3, "year": 2020, "model": 5, "price": 1149320.0, "seller": 26, "status": "sold", "description": "Toyota RAV4, 2020 г.в. Тестовое объявление."}	2025-09-17 11:25:39.022655+03	\N	незнакомец
357	UPDATE	Order	20	{"id": 20, "car": "DEMO202000024XXXX", "buyer": 33, "status": "pending", "total_amount": 1149320.0}	{"id": 20, "car": "DEMO202000024XXXX", "buyer": 33, "status": "paid", "total_amount": 1149320.0}	2025-09-17 11:25:39.026704+03	\N	незнакомец
358	CREATE	Transaction	7	\N	{"id": 7, "order": 20, "amount": 1149320, "status": "completed"}	2025-09-17 11:25:39.02766+03	\N	незнакомец
359	UPDATE	Car	DEMO201400026XXXX	{"VIN": "DEMO201400026XXXX", "make": 6, "year": 2014, "model": 12, "price": 2662319.0, "seller": 26, "status": "available", "description": "Mercedes-Benz C-Class, 2014 г.в. Тестовое объявление."}	{"VIN": "DEMO201400026XXXX", "make": 6, "year": 2014, "model": 12, "price": 2662319, "seller": 26, "status": "reserved", "description": "Mercedes-Benz C-Class, 2014 г.в. Тестовое объявление."}	2025-09-17 11:25:39.031414+03	\N	незнакомец
360	CREATE	Order	21	\N	{"id": 21, "car": "DEMO201400026XXXX", "buyer": 31, "status": "pending", "total_amount": 2662319}	2025-09-17 11:25:39.032542+03	\N	незнакомец
361	UPDATE	Car	DEMO201900027XXXX	{"VIN": "DEMO201900027XXXX", "make": 3, "year": 2019, "model": 5, "price": 481691.0, "seller": 26, "status": "available", "description": "Toyota RAV4, 2019 г.в. Тестовое объявление."}	{"VIN": "DEMO201900027XXXX", "make": 3, "year": 2019, "model": 5, "price": 481691, "seller": 26, "status": "reserved", "description": "Toyota RAV4, 2019 г.в. Тестовое объявление."}	2025-09-17 11:25:39.036128+03	\N	незнакомец
362	CREATE	Order	22	\N	{"id": 22, "car": "DEMO201900027XXXX", "buyer": 31, "status": "pending", "total_amount": 481691}	2025-09-17 11:25:39.037101+03	\N	незнакомец
363	UPDATE	Car	DEMO201300029XXXX	{"VIN": "DEMO201300029XXXX", "make": 4, "year": 2013, "model": 6, "price": 2634331.0, "seller": 27, "status": "available", "description": "BMW 3 Series, 2013 г.в. Тестовое объявление."}	{"VIN": "DEMO201300029XXXX", "make": 4, "year": 2013, "model": 6, "price": 2634331, "seller": 27, "status": "reserved", "description": "BMW 3 Series, 2013 г.в. Тестовое объявление."}	2025-09-17 11:25:39.040603+03	\N	незнакомец
364	CREATE	Order	23	\N	{"id": 23, "car": "DEMO201300029XXXX", "buyer": 32, "status": "pending", "total_amount": 2634331}	2025-09-17 11:25:39.041584+03	\N	незнакомец
365	UPDATE	Car	DEMO201300029XXXX	{"VIN": "DEMO201300029XXXX", "make": 4, "year": 2013, "model": 6, "price": 2634331.0, "seller": 27, "status": "reserved", "description": "BMW 3 Series, 2013 г.в. Тестовое объявление."}	{"VIN": "DEMO201300029XXXX", "make": 4, "year": 2013, "model": 6, "price": 2634331.0, "seller": 27, "status": "sold", "description": "BMW 3 Series, 2013 г.в. Тестовое объявление."}	2025-09-17 11:25:39.046102+03	\N	незнакомец
366	UPDATE	Order	23	{"id": 23, "car": "DEMO201300029XXXX", "buyer": 32, "status": "pending", "total_amount": 2634331.0}	{"id": 23, "car": "DEMO201300029XXXX", "buyer": 32, "status": "paid", "total_amount": 2634331.0}	2025-09-17 11:25:39.05049+03	\N	незнакомец
367	CREATE	Transaction	8	\N	{"id": 8, "order": 23, "amount": 2634331, "status": "completed"}	2025-09-17 11:25:39.051413+03	\N	незнакомец
368	UPDATE	Car	DEMO202300031XXXX	{"VIN": "DEMO202300031XXXX", "make": 9, "year": 2023, "model": 19, "price": 3293514.0, "seller": 28, "status": "available", "description": "Volkswagen Polo, 2023 г.в. Тестовое объявление."}	{"VIN": "DEMO202300031XXXX", "make": 9, "year": 2023, "model": 19, "price": 3293514, "seller": 28, "status": "reserved", "description": "Volkswagen Polo, 2023 г.в. Тестовое объявление."}	2025-09-17 11:25:39.053874+03	\N	незнакомец
369	CREATE	Order	24	\N	{"id": 24, "car": "DEMO202300031XXXX", "buyer": 30, "status": "pending", "total_amount": 3293514}	2025-09-17 11:25:39.054857+03	\N	незнакомец
370	UPDATE	Car	DEMO201200035XXXX	{"VIN": "DEMO201200035XXXX", "make": 3, "year": 2012, "model": 3, "price": 1785917.0, "seller": 24, "status": "available", "description": "Toyota Camry, 2012 г.в. Тестовое объявление."}	{"VIN": "DEMO201200035XXXX", "make": 3, "year": 2012, "model": 3, "price": 1785917, "seller": 24, "status": "reserved", "description": "Toyota Camry, 2012 г.в. Тестовое объявление."}	2025-09-17 11:25:39.058422+03	\N	незнакомец
371	CREATE	Order	25	\N	{"id": 25, "car": "DEMO201200035XXXX", "buyer": 30, "status": "pending", "total_amount": 1785917}	2025-09-17 11:25:39.059392+03	\N	незнакомец
372	UPDATE	Car	DEMO201200035XXXX	{"VIN": "DEMO201200035XXXX", "make": 3, "year": 2012, "model": 3, "price": 1785917.0, "seller": 24, "status": "reserved", "description": "Toyota Camry, 2012 г.в. Тестовое объявление."}	{"VIN": "DEMO201200035XXXX", "make": 3, "year": 2012, "model": 3, "price": 1785917.0, "seller": 24, "status": "sold", "description": "Toyota Camry, 2012 г.в. Тестовое объявление."}	2025-09-17 11:25:39.063875+03	\N	незнакомец
498	DELETE	UserRole	56	{"id": 56, "role": 3, "user": 38}	\N	2025-09-23 12:41:20.246316+03	37	admin:2
373	UPDATE	Order	25	{"id": 25, "car": "DEMO201200035XXXX", "buyer": 30, "status": "pending", "total_amount": 1785917.0}	{"id": 25, "car": "DEMO201200035XXXX", "buyer": 30, "status": "paid", "total_amount": 1785917.0}	2025-09-17 11:25:39.068174+03	\N	незнакомец
374	CREATE	Transaction	9	\N	{"id": 9, "order": 25, "amount": 1785917, "status": "completed"}	2025-09-17 11:25:39.069267+03	\N	незнакомец
375	UPDATE	Car	DEMO201800037XXXX	{"VIN": "DEMO201800037XXXX", "make": 10, "year": 2018, "model": 21, "price": 1198637.0, "seller": 27, "status": "available", "description": "LADA Vesta, 2018 г.в. Тестовое объявление."}	{"VIN": "DEMO201800037XXXX", "make": 10, "year": 2018, "model": 21, "price": 1198637, "seller": 27, "status": "reserved", "description": "LADA Vesta, 2018 г.в. Тестовое объявление."}	2025-09-17 11:25:39.071753+03	\N	незнакомец
376	CREATE	Order	26	\N	{"id": 26, "car": "DEMO201800037XXXX", "buyer": 33, "status": "pending", "total_amount": 1198637}	2025-09-17 11:25:39.072773+03	\N	незнакомец
377	UPDATE	Car	DEMO201800037XXXX	{"VIN": "DEMO201800037XXXX", "make": 10, "year": 2018, "model": 21, "price": 1198637.0, "seller": 27, "status": "reserved", "description": "LADA Vesta, 2018 г.в. Тестовое объявление."}	{"VIN": "DEMO201800037XXXX", "make": 10, "year": 2018, "model": 21, "price": 1198637.0, "seller": 27, "status": "sold", "description": "LADA Vesta, 2018 г.в. Тестовое объявление."}	2025-09-17 11:25:39.078531+03	\N	незнакомец
378	UPDATE	Order	26	{"id": 26, "car": "DEMO201800037XXXX", "buyer": 33, "status": "pending", "total_amount": 1198637.0}	{"id": 26, "car": "DEMO201800037XXXX", "buyer": 33, "status": "paid", "total_amount": 1198637.0}	2025-09-17 11:25:39.083036+03	\N	незнакомец
379	CREATE	Transaction	10	\N	{"id": 10, "order": 26, "amount": 1198637, "status": "completed"}	2025-09-17 11:25:39.083996+03	\N	незнакомец
380	UPDATE	Car	DEMO201700038XXXX	{"VIN": "DEMO201700038XXXX", "make": 4, "year": 2017, "model": 8, "price": 2176617.0, "seller": 27, "status": "available", "description": "BMW X3, 2017 г.в. Тестовое объявление."}	{"VIN": "DEMO201700038XXXX", "make": 4, "year": 2017, "model": 8, "price": 2176617, "seller": 27, "status": "reserved", "description": "BMW X3, 2017 г.в. Тестовое объявление."}	2025-09-17 11:25:39.086449+03	\N	незнакомец
381	CREATE	Order	27	\N	{"id": 27, "car": "DEMO201700038XXXX", "buyer": 29, "status": "pending", "total_amount": 2176617}	2025-09-17 11:25:39.087435+03	\N	незнакомец
382	UPDATE	Car	DEMO201700038XXXX	{"VIN": "DEMO201700038XXXX", "make": 4, "year": 2017, "model": 8, "price": 2176617.0, "seller": 27, "status": "reserved", "description": "BMW X3, 2017 г.в. Тестовое объявление."}	{"VIN": "DEMO201700038XXXX", "make": 4, "year": 2017, "model": 8, "price": 2176617.0, "seller": 27, "status": "sold", "description": "BMW X3, 2017 г.в. Тестовое объявление."}	2025-09-17 11:25:39.091536+03	\N	незнакомец
383	UPDATE	Order	27	{"id": 27, "car": "DEMO201700038XXXX", "buyer": 29, "status": "pending", "total_amount": 2176617.0}	{"id": 27, "car": "DEMO201700038XXXX", "buyer": 29, "status": "paid", "total_amount": 2176617.0}	2025-09-17 11:25:39.095944+03	\N	незнакомец
384	CREATE	Transaction	11	\N	{"id": 11, "order": 27, "amount": 2176617, "status": "completed"}	2025-09-17 11:25:39.096879+03	\N	незнакомец
385	UPDATE	Car	DEMO201200039XXXX	{"VIN": "DEMO201200039XXXX", "make": 10, "year": 2012, "model": 21, "price": 2088716.0, "seller": 24, "status": "available", "description": "LADA Vesta, 2012 г.в. Тестовое объявление."}	{"VIN": "DEMO201200039XXXX", "make": 10, "year": 2012, "model": 21, "price": 2088716, "seller": 24, "status": "reserved", "description": "LADA Vesta, 2012 г.в. Тестовое объявление."}	2025-09-17 11:25:39.099773+03	\N	незнакомец
386	CREATE	Order	28	\N	{"id": 28, "car": "DEMO201200039XXXX", "buyer": 29, "status": "pending", "total_amount": 2088716}	2025-09-17 11:25:39.10076+03	\N	незнакомец
387	UPDATE	Car	DEMO201200039XXXX	{"VIN": "DEMO201200039XXXX", "make": 10, "year": 2012, "model": 21, "price": 2088716.0, "seller": 24, "status": "reserved", "description": "LADA Vesta, 2012 г.в. Тестовое объявление."}	{"VIN": "DEMO201200039XXXX", "make": 10, "year": 2012, "model": 21, "price": 2088716.0, "seller": 24, "status": "sold", "description": "LADA Vesta, 2012 г.в. Тестовое объявление."}	2025-09-17 11:25:39.104799+03	\N	незнакомец
388	UPDATE	Order	28	{"id": 28, "car": "DEMO201200039XXXX", "buyer": 29, "status": "pending", "total_amount": 2088716.0}	{"id": 28, "car": "DEMO201200039XXXX", "buyer": 29, "status": "paid", "total_amount": 2088716.0}	2025-09-17 11:25:39.110188+03	\N	незнакомец
389	CREATE	Transaction	12	\N	{"id": 12, "order": 28, "amount": 2088716, "status": "completed"}	2025-09-17 11:25:39.11114+03	\N	незнакомец
390	CREATE	Review	3	\N	{"id": 3, "author": 33, "rating": 3, "target": 26, "comment": "Были мелкие недочёты, но в целом ок."}	2025-09-17 11:25:39.116782+03	\N	незнакомец
391	CREATE	Review	4	\N	{"id": 4, "author": 29, "rating": 5, "target": 24, "comment": "Отличная сделка, рекомендую!"}	2025-09-17 11:25:39.119879+03	\N	незнакомец
392	CREATE	Review	5	\N	{"id": 5, "author": 32, "rating": 3, "target": 27, "comment": "Отличная сделка, рекомендую!"}	2025-09-17 11:25:39.12509+03	\N	незнакомец
393	CREATE	Review	6	\N	{"id": 6, "author": 30, "rating": 4, "target": 25, "comment": "Быстро договорились, всё чётко 👍"}	2025-09-17 11:25:39.127851+03	\N	незнакомец
394	CREATE	User	34	\N	{"id": 34, "email": "aedgy.master321@mail.ru", "groups": [], "is_staff": true, "password": "pbkdf2_sha256$1000000$VDSSHLpVqgLYyhMeR3zl1N$YLRcV+jeDAtDFInhiAAtaWg7FQsuKnYxjE0j0pVuXxM=", "username": "321", "is_active": true, "last_name": "", "first_name": "", "last_login": null, "date_joined": "2025-09-17T08:27:30.440944+00:00", "is_superuser": true, "user_permissions": []}	2025-09-17 11:27:31.063644+03	\N	незнакомец
397	CREATE	Car	DEMA201700001XXXX	\N	{"VIN": "DEMA201700001XXXX", "make": 9, "year": 2025, "model": 20, "price": 23000000.0, "seller": 20, "status": "available", "description": "iusdghbsildukfjbdjhzgbdskjgbjdfsgdfg\\r\\nsdfg\\r\\nsdfg\\r\\ndsf\\r\\ngdsf\\r\\ng\\r\\ndsfg\\r\\nsdf\\r\\ngdsfg\\r\\ndsfg\\r\\ndsf\\r\\ngdsf\\r\\ng\\r\\ndsfg\\r\\ndsf\\r\\ng"}	2025-09-17 11:36:04.080354+03	20	user:IaNew123321
398	CREATE	CarImage	19	\N	{"id": 19, "car": "DEMA201700001XXXX", "image": "car_images/653302_jVf2Plq.jpg"}	2025-09-17 11:36:04.264994+03	20	user:IaNew123321
399	CREATE	CarImage	20	\N	{"id": 20, "car": "DEMA201700001XXXX", "image": "car_images/1655380035_18-phonoteka-org-p-oboi-furri-19_X0mwMwy.jpg"}	2025-09-17 11:36:04.2733+03	20	user:IaNew123321
400	CREATE	User	35	\N	{"id": 35, "email": "1@mail.ru", "groups": [], "is_staff": true, "password": "pbkdf2_sha256$1000000$UX6UfGJ9kVYcBI1rM9tfO3$3BF3vMkVTDeHBeN360+9Rhg+z756Ep1EB5bzF0txeFk=", "username": "1", "is_active": true, "last_name": "", "first_name": "", "last_login": null, "date_joined": "2025-09-17T10:57:48.143694+00:00", "is_superuser": true, "user_permissions": []}	2025-09-17 13:57:48.798895+03	\N	незнакомец
401	CREATE	UserRole	49	\N	{"id": 49, "role": 1, "user": 35}	2025-09-17 13:57:48.806695+03	\N	незнакомец
402	CREATE	User	36	\N	{"id": 36, "email": "aedgy.master123321@mail.ru", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$oUA2p68WDR8RMGffadijFH$Z2t3k0TZzgFf3slUZHNs2d4VO3oz8gVZzDjYEYXvgQA=", "username": "Loser123321", "is_active": true, "last_name": "Loser123321", "first_name": "Loser123321", "last_login": null, "date_joined": "2025-09-17T10:58:55.396590+00:00", "is_superuser": false, "user_permissions": []}	2025-09-17 13:58:56.762645+03	\N	незнакомец
403	CREATE	UserRole	50	\N	{"id": 50, "role": 3, "user": 36}	2025-09-17 13:58:56.773311+03	\N	незнакомец
404	CREATE	UserRole	51	\N	{"id": 51, "role": 1, "user": 1}	2025-09-17 14:57:12.81577+03	34	admin:321
405	DELETE	UserRole	51	{"id": 51, "role": 1, "user": 1}	\N	2025-09-17 15:24:08.549804+03	34	admin:321
406	CREATE	UserRole	52	\N	{"id": 52, "role": 1, "user": 1}	2025-09-17 15:24:08.557413+03	34	admin:321
407	INSERT	core_car	JHMCM56557C404453	\N	{"VIN": "JHMCM56557C404453", "year": 1990, "price": 1000000.00, "status": "available", "make_id": 3, "model_id": 3, "seller_id": 21, "created_at": "2025-09-17T14:00:19.677896+00:00", "description": "123"}	2025-09-17 17:00:19.678155+03	\N	\N
408	CREATE	Car	JHMCM56557C404453	\N	{"VIN": "JHMCM56557C404453", "make": 3, "year": 1990, "model": 3, "price": 1000000.0, "seller": 21, "status": "available", "description": "123"}	2025-09-17 17:00:19.712582+03	21	user:NewUserKsta
409	CREATE	CarImage	21	\N	{"id": 21, "car": "JHMCM56557C404453", "image": "car_images/Cameron_in_main_menu_4K5GfnO.jpg"}	2025-09-17 17:00:19.897953+03	21	user:NewUserKsta
410	CREATE	CarImage	22	\N	{"id": 22, "car": "JHMCM56557C404453", "image": "car_images/og_og_15886766072427680_JuQZJKf.jpg"}	2025-09-17 17:00:19.906297+03	21	user:NewUserKsta
411	UPDATE	core_car	JHMCM56557C404453	{"VIN": "JHMCM56557C404453", "year": 1990, "price": 1000000.00, "status": "available", "make_id": 3, "model_id": 3, "seller_id": 21, "created_at": "2025-09-17T14:00:19.677896+00:00", "description": "123"}	{"VIN": "JHMCM56557C404453", "year": 1991, "price": 1000000.00, "status": "available", "make_id": 3, "model_id": 3, "seller_id": 21, "created_at": "2025-09-17T14:00:19.677896+00:00", "description": "123"}	2025-09-17 17:01:58.095914+03	\N	\N
412	UPDATE	Car	JHMCM56557C404453	{"VIN": "JHMCM56557C404453", "make": 3, "year": 1990, "model": 3, "price": 1000000.0, "seller": 21, "status": "available", "description": "123"}	{"VIN": "JHMCM56557C404453", "make": 3, "year": 1991, "model": 3, "price": 1000000.0, "seller": 21, "status": "available", "description": "123"}	2025-09-17 17:01:58.107562+03	21	user:NewUserKsta
413	INSERT	core_order	29	\N	{"id": 29, "car_id": "DEMO201700005XXXX", "status": "pending", "buyer_id": 21, "order_date": "2025-09-17T14:10:56.561018+00:00", "total_amount": 1565476.00}	2025-09-17 17:10:56.561018+03	\N	\N
414	UPDATE	core_car	DEMO201700005XXXX	{"VIN": "DEMO201700005XXXX", "year": 2017, "price": 1565476.00, "status": "available", "make_id": 5, "model_id": 11, "seller_id": 27, "created_at": "2025-08-29T08:25:38.785055+00:00", "description": "Audi Q5, 2017 г.в. Тестовое объявление."}	{"VIN": "DEMO201700005XXXX", "year": 2017, "price": 1565476.00, "status": "reserved", "make_id": 5, "model_id": 11, "seller_id": 27, "created_at": "2025-08-29T08:25:38.785055+00:00", "description": "Audi Q5, 2017 г.в. Тестовое объявление."}	2025-09-17 17:10:56.561018+03	\N	\N
415	INSERT	core_order	30	\N	{"id": 30, "car_id": "DEMO201300006XXXX", "status": "pending", "buyer_id": 21, "order_date": "2025-09-17T14:14:39.776584+00:00", "total_amount": 1993530.00}	2025-09-17 17:14:39.776584+03	\N	\N
416	UPDATE	core_car	DEMO201300006XXXX	{"VIN": "DEMO201300006XXXX", "year": 2013, "price": 1993530.00, "status": "available", "make_id": 6, "model_id": 13, "seller_id": 24, "created_at": "2025-09-05T08:25:38.785055+00:00", "description": "Mercedes-Benz E-Class, 2013 г.в. Тестовое объявление."}	{"VIN": "DEMO201300006XXXX", "year": 2013, "price": 1993530.00, "status": "reserved", "make_id": 6, "model_id": 13, "seller_id": 24, "created_at": "2025-09-05T08:25:38.785055+00:00", "description": "Mercedes-Benz E-Class, 2013 г.в. Тестовое объявление."}	2025-09-17 17:14:39.776584+03	\N	\N
417	INSERT	core_order	31	\N	{"id": 31, "car_id": "DEMA201700001XXXX", "status": "pending", "buyer_id": 21, "order_date": "2025-09-17T14:16:02.856735+00:00", "total_amount": 23000000.00}	2025-09-17 17:16:02.856735+03	\N	\N
418	UPDATE	core_car	DEMA201700001XXXX	{"VIN": "DEMA201700001XXXX", "year": 2025, "price": 23000000.00, "status": "available", "make_id": 9, "model_id": 20, "seller_id": 20, "created_at": "2025-09-17T08:36:04.062721+00:00", "description": "iusdghbsildukfjbdjhzgbdskjgbjdfsgdfg\\r\\nsdfg\\r\\nsdfg\\r\\ndsf\\r\\ngdsf\\r\\ng\\r\\ndsfg\\r\\nsdf\\r\\ngdsfg\\r\\ndsfg\\r\\ndsf\\r\\ngdsf\\r\\ng\\r\\ndsfg\\r\\ndsf\\r\\ng"}	{"VIN": "DEMA201700001XXXX", "year": 2025, "price": 23000000.00, "status": "reserved", "make_id": 9, "model_id": 20, "seller_id": 20, "created_at": "2025-09-17T08:36:04.062721+00:00", "description": "iusdghbsildukfjbdjhzgbdskjgbjdfsgdfg\\r\\nsdfg\\r\\nsdfg\\r\\ndsf\\r\\ngdsf\\r\\ng\\r\\ndsfg\\r\\nsdf\\r\\ngdsfg\\r\\ndsfg\\r\\ndsf\\r\\ngdsf\\r\\ng\\r\\ndsfg\\r\\ndsf\\r\\ng"}	2025-09-17 17:16:02.856735+03	\N	\N
419	INSERT	core_transaction	13	\N	{"id": 13, "amount": 1565476.00, "status": "completed", "order_id": 29, "transaction_date": "2025-09-17T14:29:08.68558+00:00"}	2025-09-17 17:29:08.68558+03	\N	\N
420	UPDATE	core_order	29	{"id": 29, "car_id": "DEMO201700005XXXX", "status": "pending", "buyer_id": 21, "order_date": "2025-09-17T14:10:56.561018+00:00", "total_amount": 1565476.00}	{"id": 29, "car_id": "DEMO201700005XXXX", "status": "paid", "buyer_id": 21, "order_date": "2025-09-17T14:10:56.561018+00:00", "total_amount": 1565476.00}	2025-09-17 17:29:08.68558+03	\N	\N
421	UPDATE	core_car	DEMO201700005XXXX	{"VIN": "DEMO201700005XXXX", "year": 2017, "price": 1565476.00, "status": "reserved", "make_id": 5, "model_id": 11, "seller_id": 27, "created_at": "2025-08-29T08:25:38.785055+00:00", "description": "Audi Q5, 2017 г.в. Тестовое объявление."}	{"VIN": "DEMO201700005XXXX", "year": 2017, "price": 1565476.00, "status": "sold", "make_id": 5, "model_id": 11, "seller_id": 27, "created_at": "2025-08-29T08:25:38.785055+00:00", "description": "Audi Q5, 2017 г.в. Тестовое объявление."}	2025-09-17 17:29:08.68558+03	\N	\N
422	INSERT	core_car	JHMEM56557C404453	\N	{"VIN": "JHMEM56557C404453", "year": 2020, "price": 1000000.00, "status": "available", "make_id": 7, "model_id": 15, "seller_id": 21, "created_at": "2025-09-17T15:03:12.623451+00:00", "description": "fshdjankdnmzv"}	2025-09-17 18:03:12.623674+03	\N	\N
423	CREATE	Car	JHMEM56557C404453	\N	{"VIN": "JHMEM56557C404453", "make": 7, "year": 2020, "model": 15, "price": 1000000.0, "seller": 21, "status": "available", "description": "fshdjankdnmzv"}	2025-09-17 18:03:12.649111+03	21	user:NewUserKsta
424	CREATE	CarImage	23	\N	{"id": 23, "car": "JHMEM56557C404453", "image": "car_images/1655380035_18-phonoteka-org-p-oboi-furri-19_JOPZqS8.jpg"}	2025-09-17 18:03:12.748515+03	21	user:NewUserKsta
425	CREATE	CarImage	24	\N	{"id": 24, "car": "JHMEM56557C404453", "image": "car_images/og_og_15886766072427680_uCvjN1a.jpg"}	2025-09-17 18:03:12.755525+03	21	user:NewUserKsta
426	INSERT	core_order	32	\N	{"id": 32, "car_id": "JHMEM56557C404453", "status": "pending", "buyer_id": 22, "order_date": "2025-09-17T15:04:39.119723+00:00", "total_amount": 1000000.00}	2025-09-17 18:04:39.119723+03	\N	\N
427	UPDATE	core_car	JHMEM56557C404453	{"VIN": "JHMEM56557C404453", "year": 2020, "price": 1000000.00, "status": "available", "make_id": 7, "model_id": 15, "seller_id": 21, "created_at": "2025-09-17T15:03:12.623451+00:00", "description": "fshdjankdnmzv"}	{"VIN": "JHMEM56557C404453", "year": 2020, "price": 1000000.00, "status": "reserved", "make_id": 7, "model_id": 15, "seller_id": 21, "created_at": "2025-09-17T15:03:12.623451+00:00", "description": "fshdjankdnmzv"}	2025-09-17 18:04:39.119723+03	\N	\N
428	INSERT	core_order	33	\N	{"id": 33, "car_id": "JHMCM56557C404453", "status": "pending", "buyer_id": 22, "order_date": "2025-09-17T15:05:01.069628+00:00", "total_amount": 1000000.00}	2025-09-17 18:05:01.069628+03	\N	\N
429	UPDATE	core_car	JHMCM56557C404453	{"VIN": "JHMCM56557C404453", "year": 1991, "price": 1000000.00, "status": "available", "make_id": 3, "model_id": 3, "seller_id": 21, "created_at": "2025-09-17T14:00:19.677896+00:00", "description": "123"}	{"VIN": "JHMCM56557C404453", "year": 1991, "price": 1000000.00, "status": "reserved", "make_id": 3, "model_id": 3, "seller_id": 21, "created_at": "2025-09-17T14:00:19.677896+00:00", "description": "123"}	2025-09-17 18:05:01.069628+03	\N	\N
430	UPDATE	core_car	JHMEM56557C404453	{"VIN": "JHMEM56557C404453", "year": 2020, "price": 1000000.00, "status": "reserved", "make_id": 7, "model_id": 15, "seller_id": 21, "created_at": "2025-09-17T15:03:12.623451+00:00", "description": "fshdjankdnmzv"}	{"VIN": "JHMEM56557C404453", "year": 2020, "price": 1000000.00, "status": "available", "make_id": 7, "model_id": 15, "seller_id": 21, "created_at": "2025-09-17T15:03:12.623451+00:00", "description": "fshdjankdnmzv"}	2025-09-17 18:05:45.685404+03	\N	\N
431	UPDATE	Car	JHMEM56557C404453	{"VIN": "JHMEM56557C404453", "make": 7, "year": 2020, "model": 15, "price": 1000000.0, "seller": 21, "status": "reserved", "description": "fshdjankdnmzv"}	{"VIN": "JHMEM56557C404453", "make": 7, "year": 2020, "model": 15, "price": 1000000.0, "seller": 21, "status": "available", "description": "fshdjankdnmzv"}	2025-09-17 18:05:45.696299+03	21	user:NewUserKsta
432	UPDATE	core_order	32	{"id": 32, "car_id": "JHMEM56557C404453", "status": "pending", "buyer_id": 22, "order_date": "2025-09-17T15:04:39.119723+00:00", "total_amount": 1000000.00}	{"id": 32, "car_id": "JHMEM56557C404453", "status": "cancelled", "buyer_id": 22, "order_date": "2025-09-17T15:04:39.119723+00:00", "total_amount": 1000000.00}	2025-09-17 18:05:45.685404+03	\N	\N
433	UPDATE	Order	32	{"id": 32, "car": "JHMEM56557C404453", "buyer": 22, "status": "pending", "total_amount": 1000000.0}	{"id": 32, "car": "JHMEM56557C404453", "buyer": 22, "status": "cancelled", "total_amount": 1000000.0}	2025-09-17 18:05:45.701506+03	21	user:NewUserKsta
434	UPDATE	core_car	JHMCM56557C404453	{"VIN": "JHMCM56557C404453", "year": 1991, "price": 1000000.00, "status": "reserved", "make_id": 3, "model_id": 3, "seller_id": 21, "created_at": "2025-09-17T14:00:19.677896+00:00", "description": "123"}	{"VIN": "JHMCM56557C404453", "year": 1991, "price": 1000000.00, "status": "available", "make_id": 3, "model_id": 3, "seller_id": 21, "created_at": "2025-09-17T14:00:19.677896+00:00", "description": "123"}	2025-09-17 18:06:13.419893+03	\N	\N
435	UPDATE	Car	JHMCM56557C404453	{"VIN": "JHMCM56557C404453", "make": 3, "year": 1991, "model": 3, "price": 1000000.0, "seller": 21, "status": "reserved", "description": "123"}	{"VIN": "JHMCM56557C404453", "make": 3, "year": 1991, "model": 3, "price": 1000000.0, "seller": 21, "status": "available", "description": "123"}	2025-09-17 18:06:13.430288+03	21	user:NewUserKsta
436	UPDATE	core_order	33	{"id": 33, "car_id": "JHMCM56557C404453", "status": "pending", "buyer_id": 22, "order_date": "2025-09-17T15:05:01.069628+00:00", "total_amount": 1000000.00}	{"id": 33, "car_id": "JHMCM56557C404453", "status": "cancelled", "buyer_id": 22, "order_date": "2025-09-17T15:05:01.069628+00:00", "total_amount": 1000000.00}	2025-09-17 18:06:13.419893+03	\N	\N
437	UPDATE	Order	33	{"id": 33, "car": "JHMCM56557C404453", "buyer": 22, "status": "pending", "total_amount": 1000000.0}	{"id": 33, "car": "JHMCM56557C404453", "buyer": 22, "status": "cancelled", "total_amount": 1000000.0}	2025-09-17 18:06:13.433206+03	21	user:NewUserKsta
438	INSERT	core_order	34	\N	{"id": 34, "car_id": "JHMEM56557C404453", "status": "pending", "buyer_id": 22, "order_date": "2025-09-17T15:16:49.326265+00:00", "total_amount": 1000000.00}	2025-09-17 18:16:49.326265+03	\N	\N
499	CREATE	UserRole	58	\N	{"id": 58, "role": 3, "user": 38}	2025-09-23 12:41:20.256327+03	37	admin:2
439	UPDATE	core_car	JHMEM56557C404453	{"VIN": "JHMEM56557C404453", "year": 2020, "price": 1000000.00, "status": "available", "make_id": 7, "model_id": 15, "seller_id": 21, "created_at": "2025-09-17T15:03:12.623451+00:00", "description": "fshdjankdnmzv"}	{"VIN": "JHMEM56557C404453", "year": 2020, "price": 1000000.00, "status": "reserved", "make_id": 7, "model_id": 15, "seller_id": 21, "created_at": "2025-09-17T15:03:12.623451+00:00", "description": "fshdjankdnmzv"}	2025-09-17 18:16:49.326265+03	\N	\N
440	INSERT	core_order	35	\N	{"id": 35, "car_id": "JHMCM56557C404453", "status": "pending", "buyer_id": 22, "order_date": "2025-09-17T15:16:52.53991+00:00", "total_amount": 1000000.00}	2025-09-17 18:16:52.53991+03	\N	\N
441	UPDATE	core_car	JHMCM56557C404453	{"VIN": "JHMCM56557C404453", "year": 1991, "price": 1000000.00, "status": "available", "make_id": 3, "model_id": 3, "seller_id": 21, "created_at": "2025-09-17T14:00:19.677896+00:00", "description": "123"}	{"VIN": "JHMCM56557C404453", "year": 1991, "price": 1000000.00, "status": "reserved", "make_id": 3, "model_id": 3, "seller_id": 21, "created_at": "2025-09-17T14:00:19.677896+00:00", "description": "123"}	2025-09-17 18:16:52.53991+03	\N	\N
442	UPDATE	core_car	JHMEM56557C404453	{"VIN": "JHMEM56557C404453", "year": 2020, "price": 1000000.00, "status": "reserved", "make_id": 7, "model_id": 15, "seller_id": 21, "created_at": "2025-09-17T15:03:12.623451+00:00", "description": "fshdjankdnmzv"}	{"VIN": "JHMEM56557C404453", "year": 2020, "price": 1000000.00, "status": "available", "make_id": 7, "model_id": 15, "seller_id": 21, "created_at": "2025-09-17T15:03:12.623451+00:00", "description": "fshdjankdnmzv"}	2025-09-17 18:18:00.460782+03	\N	\N
443	UPDATE	Car	JHMEM56557C404453	{"VIN": "JHMEM56557C404453", "make": 7, "year": 2020, "model": 15, "price": 1000000.0, "seller": 21, "status": "reserved", "description": "fshdjankdnmzv"}	{"VIN": "JHMEM56557C404453", "make": 7, "year": 2020, "model": 15, "price": 1000000.0, "seller": 21, "status": "available", "description": "fshdjankdnmzv"}	2025-09-17 18:18:00.476224+03	21	user:NewUserKsta
444	UPDATE	core_order	34	{"id": 34, "car_id": "JHMEM56557C404453", "status": "pending", "buyer_id": 22, "order_date": "2025-09-17T15:16:49.326265+00:00", "total_amount": 1000000.00}	{"id": 34, "car_id": "JHMEM56557C404453", "status": "cancelled", "buyer_id": 22, "order_date": "2025-09-17T15:16:49.326265+00:00", "total_amount": 1000000.00}	2025-09-17 18:18:00.460782+03	\N	\N
445	UPDATE	Order	34	{"id": 34, "car": "JHMEM56557C404453", "buyer": 22, "status": "pending", "total_amount": 1000000.0}	{"id": 34, "car": "JHMEM56557C404453", "buyer": 22, "status": "cancelled", "total_amount": 1000000.0}	2025-09-17 18:18:00.480563+03	21	user:NewUserKsta
446	UPDATE	core_car	JHMCM56557C404453	{"VIN": "JHMCM56557C404453", "year": 1991, "price": 1000000.00, "status": "reserved", "make_id": 3, "model_id": 3, "seller_id": 21, "created_at": "2025-09-17T14:00:19.677896+00:00", "description": "123"}	{"VIN": "JHMCM56557C404453", "year": 1991, "price": 1000000.00, "status": "available", "make_id": 3, "model_id": 3, "seller_id": 21, "created_at": "2025-09-17T14:00:19.677896+00:00", "description": "123"}	2025-09-17 18:19:02.345933+03	\N	\N
447	UPDATE	Car	JHMCM56557C404453	{"VIN": "JHMCM56557C404453", "make": 3, "year": 1991, "model": 3, "price": 1000000.0, "seller": 21, "status": "reserved", "description": "123"}	{"VIN": "JHMCM56557C404453", "make": 3, "year": 1991, "model": 3, "price": 1000000.0, "seller": 21, "status": "available", "description": "123"}	2025-09-17 18:19:02.357119+03	21	user:NewUserKsta
448	UPDATE	core_order	35	{"id": 35, "car_id": "JHMCM56557C404453", "status": "pending", "buyer_id": 22, "order_date": "2025-09-17T15:16:52.53991+00:00", "total_amount": 1000000.00}	{"id": 35, "car_id": "JHMCM56557C404453", "status": "cancelled", "buyer_id": 22, "order_date": "2025-09-17T15:16:52.53991+00:00", "total_amount": 1000000.00}	2025-09-17 18:19:02.345933+03	\N	\N
449	UPDATE	Order	35	{"id": 35, "car": "JHMCM56557C404453", "buyer": 22, "status": "pending", "total_amount": 1000000.0}	{"id": 35, "car": "JHMCM56557C404453", "buyer": 22, "status": "cancelled", "total_amount": 1000000.0}	2025-09-17 18:19:02.362641+03	21	user:NewUserKsta
450	CREATE	Make	11	\N	{"id": 11, "name": "loser"}	2025-09-17 18:23:22.792654+03	21	user:NewUserKsta
451	CREATE	Model	23	\N	{"id": 23, "make": 11, "name": "loser"}	2025-09-17 18:23:22.890071+03	21	user:NewUserKsta
452	INSERT	core_car	JHMFB56557C404453	\N	{"VIN": "JHMFB56557C404453", "year": 2020, "price": 10000000.00, "status": "available", "make_id": 11, "model_id": 23, "seller_id": 21, "created_at": "2025-09-17T15:23:22.982706+00:00", "description": "d\\r\\nd\\r\\nd\\r\\nd\\r\\nd\\r\\nd\\r\\nd\\r\\nd"}	2025-09-17 18:23:22.982906+03	\N	\N
453	CREATE	Car	JHMFB56557C404453	\N	{"VIN": "JHMFB56557C404453", "make": 11, "year": 2020, "model": 23, "price": 10000000.0, "seller": 21, "status": "available", "description": "d\\r\\nd\\r\\nd\\r\\nd\\r\\nd\\r\\nd\\r\\nd\\r\\nd"}	2025-09-17 18:23:22.999688+03	21	user:NewUserKsta
454	CREATE	CarImage	25	\N	{"id": 25, "car": "JHMFB56557C404453", "image": "car_images/606506_OtuCmrn.jpg"}	2025-09-17 18:23:23.114687+03	21	user:NewUserKsta
455	CREATE	CarImage	26	\N	{"id": 26, "car": "JHMFB56557C404453", "image": "car_images/653302_sO7XucX.jpg"}	2025-09-17 18:23:23.126829+03	21	user:NewUserKsta
456	CREATE	CarImage	27	\N	{"id": 27, "car": "JHMFB56557C404453", "image": "car_images/og_og_15886766072427680_Ct7gOAT.jpg"}	2025-09-17 18:23:23.136537+03	21	user:NewUserKsta
457	UPDATE	core_car	DEMO201300006XXXX	{"VIN": "DEMO201300006XXXX", "year": 2013, "price": 1993530.00, "status": "reserved", "make_id": 6, "model_id": 13, "seller_id": 24, "created_at": "2025-09-05T08:25:38.785055+00:00", "description": "Mercedes-Benz E-Class, 2013 г.в. Тестовое объявление."}	{"VIN": "DEMO201300006XXXX", "year": 2013, "price": 2093206.50, "status": "reserved", "make_id": 6, "model_id": 13, "seller_id": 24, "created_at": "2025-09-05T08:25:38.785055+00:00", "description": "Mercedes-Benz E-Class, 2013 г.в. Тестовое объявление."}	2025-09-17 19:03:36.159431+03	\N	\N
495	CREATE	Review	9	\N	{"id": 9, "author": 22, "rating": 3, "target": 28, "comment": ""}	2025-09-22 22:09:24.312704+03	22	user:Loser123
496	DELETE	Review	9	{"id": 9, "author": 22, "rating": 3, "target": 28, "comment": ""}	\N	2025-09-22 22:09:29.330426+03	22	user:Loser123
500	DELETE	UserRole	58	{"id": 58, "role": 3, "user": 38}	\N	2025-09-23 12:41:23.61842+03	37	admin:2
458	UPDATE	core_car	DEMO201200014XXXX	{"VIN": "DEMO201200014XXXX", "year": 2012, "price": 1360697.00, "status": "available", "make_id": 6, "model_id": 14, "seller_id": 26, "created_at": "2025-09-13T08:25:38.785055+00:00", "description": "Mercedes-Benz GLC, 2012 г.в. Тестовое объявление."}	{"VIN": "DEMO201200014XXXX", "year": 2012, "price": 1428731.85, "status": "available", "make_id": 6, "model_id": 14, "seller_id": 26, "created_at": "2025-09-13T08:25:38.785055+00:00", "description": "Mercedes-Benz GLC, 2012 г.в. Тестовое объявление."}	2025-09-17 19:03:36.159431+03	\N	\N
459	UPDATE	core_car	DEMO201200034XXXX	{"VIN": "DEMO201200034XXXX", "year": 2012, "price": 697766.00, "status": "available", "make_id": 6, "model_id": 14, "seller_id": 25, "created_at": "2025-06-19T08:25:38.785055+00:00", "description": "Mercedes-Benz GLC, 2012 г.в. Тестовое объявление."}	{"VIN": "DEMO201200034XXXX", "year": 2012, "price": 732654.30, "status": "available", "make_id": 6, "model_id": 14, "seller_id": 25, "created_at": "2025-06-19T08:25:38.785055+00:00", "description": "Mercedes-Benz GLC, 2012 г.в. Тестовое объявление."}	2025-09-17 19:03:36.159431+03	\N	\N
460	UPDATE	core_car	DEMO201500036XXXX	{"VIN": "DEMO201500036XXXX", "year": 2015, "price": 2661711.00, "status": "available", "make_id": 6, "model_id": 13, "seller_id": 27, "created_at": "2025-09-01T08:25:38.785055+00:00", "description": "Mercedes-Benz E-Class, 2015 г.в. Тестовое объявление."}	{"VIN": "DEMO201500036XXXX", "year": 2015, "price": 2794796.55, "status": "available", "make_id": 6, "model_id": 13, "seller_id": 27, "created_at": "2025-09-01T08:25:38.785055+00:00", "description": "Mercedes-Benz E-Class, 2015 г.в. Тестовое объявление."}	2025-09-17 19:03:36.159431+03	\N	\N
461	UPDATE	core_car	DEMO201800013XXXX	{"VIN": "DEMO201800013XXXX", "year": 2018, "price": 1532243.00, "status": "reserved", "make_id": 6, "model_id": 12, "seller_id": 27, "created_at": "2025-09-17T08:25:38.828029+00:00", "description": "Mercedes-Benz C-Class, 2018 г.в. Тестовое объявление."}	{"VIN": "DEMO201800013XXXX", "year": 2018, "price": 1608855.15, "status": "reserved", "make_id": 6, "model_id": 12, "seller_id": 27, "created_at": "2025-09-17T08:25:38.828029+00:00", "description": "Mercedes-Benz C-Class, 2018 г.в. Тестовое объявление."}	2025-09-17 19:03:36.159431+03	\N	\N
462	UPDATE	core_car	DEMO201400026XXXX	{"VIN": "DEMO201400026XXXX", "year": 2014, "price": 2662319.00, "status": "reserved", "make_id": 6, "model_id": 12, "seller_id": 26, "created_at": "2025-09-17T08:25:38.85966+00:00", "description": "Mercedes-Benz C-Class, 2014 г.в. Тестовое объявление."}	{"VIN": "DEMO201400026XXXX", "year": 2014, "price": 2795434.95, "status": "reserved", "make_id": 6, "model_id": 12, "seller_id": 26, "created_at": "2025-09-17T08:25:38.85966+00:00", "description": "Mercedes-Benz C-Class, 2014 г.в. Тестовое объявление."}	2025-09-17 19:03:36.159431+03	\N	\N
463	UPDATE	core_car	JHMFB56557C404453	{"VIN": "JHMFB56557C404453", "year": 2020, "price": 10000000.00, "status": "available", "make_id": 11, "model_id": 23, "seller_id": 21, "created_at": "2025-09-17T15:23:22.982706+00:00", "description": "d\\r\\nd\\r\\nd\\r\\nd\\r\\nd\\r\\nd\\r\\nd\\r\\nd"}	{"VIN": "JHMFB56557C404453", "year": 2020, "price": 10600000.00, "status": "available", "make_id": 11, "model_id": 23, "seller_id": 21, "created_at": "2025-09-17T15:23:22.982706+00:00", "description": "d\\r\\nd\\r\\nd\\r\\nd\\r\\nd\\r\\nd\\r\\nd\\r\\nd"}	2025-09-17 19:04:49.880323+03	\N	\N
464	UPDATE	User	23	{"id": 23, "email": "admin@example.com", "groups": [], "is_staff": true, "password": "pbkdf2_sha256$1000000$BSoLJZrBXNsOyB9FrDEvHH$3tsggpIv6kN0t1Y9FI6qcj99z26IlQhGUpmtCS9jXpI=", "username": "admin", "is_active": true, "last_name": "User", "first_name": "Admin", "last_login": null, "date_joined": "2025-09-17T08:25:31.725898+00:00", "is_superuser": true, "user_permissions": []}	{"id": 23, "email": "admin@example.com", "groups": [], "is_staff": true, "password": "pbkdf2_sha256$1000000$7ecxmtlYVjg1B3Nr2ZdFIQ$8fO9bUqTKekiiPEy/zTqOL78jllEZgedt/Px7JKczQI=", "username": "admin", "is_active": true, "last_name": "User", "first_name": "Admin", "last_login": null, "date_joined": "2025-09-17T08:25:31.725898+00:00", "is_superuser": true, "user_permissions": []}	2025-09-17 20:32:35.357486+03	\N	незнакомец
465	CREATE	User	37	\N	{"id": 37, "email": "2@mail.ru", "groups": [], "is_staff": true, "password": "pbkdf2_sha256$1000000$BsGyLh4pikwTPEa0P3J2VI$aMn75fXpNnzaRDCOmUkgdQGrlGwoZ7ETmAmnTv0puX4=", "username": "2", "is_active": true, "last_name": "", "first_name": "", "last_login": null, "date_joined": "2025-09-17T17:34:09.321789+00:00", "is_superuser": true, "user_permissions": []}	2025-09-17 20:34:09.974293+03	\N	незнакомец
466	CREATE	UserRole	53	\N	{"id": 53, "role": 1, "user": 37}	2025-09-17 20:34:09.983985+03	\N	незнакомец
467	UPDATE	User	23	{"id": 23, "email": "admin@example.com", "groups": [], "is_staff": true, "password": "pbkdf2_sha256$1000000$7ecxmtlYVjg1B3Nr2ZdFIQ$8fO9bUqTKekiiPEy/zTqOL78jllEZgedt/Px7JKczQI=", "username": "admin", "is_active": true, "last_name": "User", "first_name": "Admin", "last_login": null, "date_joined": "2025-09-17T08:25:31.725898+00:00", "is_superuser": true, "user_permissions": []}	{"id": 23, "email": "admin@example.com", "groups": [], "is_staff": true, "password": "pbkdf2_sha256$1000000$fWfsddRZJh0jiLIwQArT4m$aKOVvVayjodUsdKehTPCNp1U/Nt8jNJ5/0Bt//B//Uw=", "username": "admin", "is_active": true, "last_name": "User", "first_name": "Admin", "last_login": null, "date_joined": "2025-09-17T08:25:31.725898+00:00", "is_superuser": true, "user_permissions": []}	2025-09-17 20:35:44.763018+03	\N	незнакомец
468	DELETE	UserRole	52	{"id": 52, "role": 1, "user": 1}	\N	2025-09-17 22:23:37.128508+03	37	admin:2
469	CREATE	UserRole	54	\N	{"id": 54, "role": 1, "user": 1}	2025-09-17 22:23:37.139301+03	37	admin:2
470	UPDATE	core_car	DEMO202100004XXXX	{"VIN": "DEMO202100004XXXX", "year": 2021, "price": 1566816.00, "status": "available", "make_id": 9, "model_id": 19, "seller_id": 27, "created_at": "2025-09-17T08:25:38.801713+00:00", "description": "Volkswagen Polo, 2021 г.в. Тестовое объявление."}	{"VIN": "DEMO202100004XXXX", "year": 2021, "price": 1629488.64, "status": "available", "make_id": 9, "model_id": 19, "seller_id": 27, "created_at": "2025-09-17T08:25:38.801713+00:00", "description": "Volkswagen Polo, 2021 г.в. Тестовое объявление."}	2025-09-17 22:23:44.383218+03	\N	\N
497	CREATE	UserRole	57	\N	{"id": 57, "role": 1, "user": 3}	2025-09-23 12:41:03.229812+03	37	admin:2
501	CREATE	UserRole	59	\N	{"id": 59, "role": 2, "user": 38}	2025-09-23 12:41:23.664448+03	37	admin:2
471	UPDATE	core_car	DEMO202300031XXXX	{"VIN": "DEMO202300031XXXX", "year": 2023, "price": 3293514.00, "status": "reserved", "make_id": 9, "model_id": 19, "seller_id": 28, "created_at": "2025-09-17T08:25:38.870217+00:00", "description": "Volkswagen Polo, 2023 г.в. Тестовое объявление."}	{"VIN": "DEMO202300031XXXX", "year": 2023, "price": 3425254.56, "status": "reserved", "make_id": 9, "model_id": 19, "seller_id": 28, "created_at": "2025-09-17T08:25:38.870217+00:00", "description": "Volkswagen Polo, 2023 г.в. Тестовое объявление."}	2025-09-17 22:23:44.383218+03	\N	\N
472	UPDATE	core_car	DEMA201700001XXXX	{"VIN": "DEMA201700001XXXX", "year": 2025, "price": 23000000.00, "status": "reserved", "make_id": 9, "model_id": 20, "seller_id": 20, "created_at": "2025-09-17T08:36:04.062721+00:00", "description": "iusdghbsildukfjbdjhzgbdskjgbjdfsgdfg\\r\\nsdfg\\r\\nsdfg\\r\\ndsf\\r\\ngdsf\\r\\ng\\r\\ndsfg\\r\\nsdf\\r\\ngdsfg\\r\\ndsfg\\r\\ndsf\\r\\ngdsf\\r\\ng\\r\\ndsfg\\r\\ndsf\\r\\ng"}	{"VIN": "DEMA201700001XXXX", "year": 2025, "price": 23920000.00, "status": "reserved", "make_id": 9, "model_id": 20, "seller_id": 20, "created_at": "2025-09-17T08:36:04.062721+00:00", "description": "iusdghbsildukfjbdjhzgbdskjgbjdfsgdfg\\r\\nsdfg\\r\\nsdfg\\r\\ndsf\\r\\ngdsf\\r\\ng\\r\\ndsfg\\r\\nsdf\\r\\ngdsfg\\r\\ndsfg\\r\\ndsf\\r\\ngdsf\\r\\ng\\r\\ndsfg\\r\\ndsf\\r\\ng"}	2025-09-17 22:23:44.383218+03	\N	\N
473	CREATE	UserRole	55	\N	{"id": 55, "role": 2, "user": 21}	2025-09-18 14:14:11.213104+03	37	admin:2
474	CREATE	Make	12	\N	{"id": 12, "name": "Toyota2"}	2025-09-22 18:59:16.728744+03	13	user:NewUser
475	CREATE	Model	24	\N	{"id": 24, "make": 12, "name": "Camry2"}	2025-09-22 18:59:16.78923+03	13	user:NewUser
476	INSERT	core_car	WDB1240821F323866	\N	{"VIN": "WDB1240821F323866", "year": 2020, "price": 4000000000.00, "status": "available", "make_id": 12, "model_id": 24, "seller_id": 13, "created_at": "2025-09-22T15:59:23.347911+00:00", "description": "d"}	2025-09-22 18:59:23.348271+03	\N	\N
477	CREATE	Car	WDB1240821F323866	\N	{"VIN": "WDB1240821F323866", "make": 12, "year": 2020, "model": 24, "price": 4000000000.0, "seller": 13, "status": "available", "description": "d"}	2025-09-22 18:59:23.441816+03	13	user:NewUser
478	CREATE	CarImage	28	\N	{"id": 28, "car": "WDB1240821F323866", "image": "car_images/653302_F0fvZbG.jpg"}	2025-09-22 18:59:23.684796+03	13	user:NewUser
479	CREATE	CarImage	29	\N	{"id": 29, "car": "WDB1240821F323866", "image": "car_images/1655380035_18-phonoteka-org-p-oboi-furri-19_sEyDt6R.jpg"}	2025-09-22 18:59:23.697726+03	13	user:NewUser
480	CREATE	User	38	\N	{"id": 38, "email": "NewUserKsta@mail.ru", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$xtdn3ZqSE2BcDZBUaBMEjL$yBhxDaNPgaGLPBHhlj/wUkkU3gsRhQQZVLGFabIZPoE=", "username": "NewUserKsta123", "is_active": true, "last_name": "Чистотин", "first_name": "Михаил", "last_login": null, "date_joined": "2025-09-22T18:12:48.772733+00:00", "is_superuser": false, "user_permissions": []}	2025-09-22 21:12:49.476837+03	\N	незнакомец
481	CREATE	UserRole	56	\N	{"id": 56, "role": 3, "user": 38}	2025-09-22 21:12:49.489248+03	\N	незнакомец
482	INSERT	core_car	JHMWM56557C404453	\N	{"VIN": "JHMWM56557C404453", "year": 2020, "price": 32000.00, "status": "available", "make_id": 12, "model_id": 24, "seller_id": 38, "created_at": "2025-09-22T18:13:41.46073+00:00", "description": "2132313"}	2025-09-22 21:13:41.460894+03	\N	\N
483	CREATE	Car	JHMWM56557C404453	\N	{"VIN": "JHMWM56557C404453", "make": 12, "year": 2020, "model": 24, "price": 32000.0, "seller": 38, "status": "available", "description": "2132313"}	2025-09-22 21:13:41.478267+03	38	user:NewUserKsta123
484	CREATE	CarImage	30	\N	{"id": 30, "car": "JHMWM56557C404453", "image": "car_images/1655380035_18-phonoteka-org-p-oboi-furri-19_AsZvgDc.jpg"}	2025-09-22 21:13:41.545678+03	38	user:NewUserKsta123
485	CREATE	CarImage	31	\N	{"id": 31, "car": "JHMWM56557C404453", "image": "car_images/Cameron_in_main_menu_wcuwaWF.jpg"}	2025-09-22 21:13:41.553759+03	38	user:NewUserKsta123
486	INSERT	core_order	36	\N	{"id": 36, "car_id": "DEMO201200014XXXX", "status": "pending", "buyer_id": 38, "order_date": "2025-09-22T18:13:51.690944+00:00", "total_amount": 1428731.85}	2025-09-22 21:13:51.690944+03	\N	\N
487	UPDATE	core_car	DEMO201200014XXXX	{"VIN": "DEMO201200014XXXX", "year": 2012, "price": 1428731.85, "status": "available", "make_id": 6, "model_id": 14, "seller_id": 26, "created_at": "2025-09-13T08:25:38.785055+00:00", "description": "Mercedes-Benz GLC, 2012 г.в. Тестовое объявление."}	{"VIN": "DEMO201200014XXXX", "year": 2012, "price": 1428731.85, "status": "reserved", "make_id": 6, "model_id": 14, "seller_id": 26, "created_at": "2025-09-13T08:25:38.785055+00:00", "description": "Mercedes-Benz GLC, 2012 г.в. Тестовое объявление."}	2025-09-22 21:13:51.690944+03	\N	\N
488	CREATE	Review	7	\N	{"id": 7, "author": 38, "rating": 1, "target": 21, "comment": "123"}	2025-09-22 21:14:13.663233+03	38	user:NewUserKsta123
489	DELETE	Review	7	{"id": 7, "author": 38, "rating": 1, "target": 21, "comment": "123"}	\N	2025-09-22 21:14:16.43309+03	38	user:NewUserKsta123
490	INSERT	core_transaction	14	\N	{"id": 14, "amount": 1993530.00, "status": "completed", "order_id": 30, "transaction_date": "2025-09-22T18:44:29.928821+00:00"}	2025-09-22 21:44:29.928821+03	\N	\N
491	UPDATE	core_order	30	{"id": 30, "car_id": "DEMO201300006XXXX", "status": "pending", "buyer_id": 21, "order_date": "2025-09-17T14:14:39.776584+00:00", "total_amount": 1993530.00}	{"id": 30, "car_id": "DEMO201300006XXXX", "status": "paid", "buyer_id": 21, "order_date": "2025-09-17T14:14:39.776584+00:00", "total_amount": 1993530.00}	2025-09-22 21:44:29.928821+03	\N	\N
492	UPDATE	core_car	DEMO201300006XXXX	{"VIN": "DEMO201300006XXXX", "year": 2013, "price": 2093206.50, "status": "reserved", "make_id": 6, "model_id": 13, "seller_id": 24, "created_at": "2025-09-05T08:25:38.785055+00:00", "description": "Mercedes-Benz E-Class, 2013 г.в. Тестовое объявление."}	{"VIN": "DEMO201300006XXXX", "year": 2013, "price": 2093206.50, "status": "sold", "make_id": 6, "model_id": 13, "seller_id": 24, "created_at": "2025-09-05T08:25:38.785055+00:00", "description": "Mercedes-Benz E-Class, 2013 г.в. Тестовое объявление."}	2025-09-22 21:44:29.928821+03	\N	\N
493	CREATE	Review	8	\N	{"id": 8, "author": 22, "rating": 3, "target": 28, "comment": "213"}	2025-09-22 22:09:19.017005+03	22	user:Loser123
494	DELETE	Review	8	{"id": 8, "author": 22, "rating": 3, "target": 28, "comment": "213"}	\N	2025-09-22 22:09:21.545866+03	22	user:Loser123
502	CREATE	Review	10	\N	{"id": 10, "author": 22, "rating": 3, "target": 24, "comment": "123"}	2025-09-23 12:53:19.421083+03	22	user:Loser123
503	DELETE	Review	10	{"id": 10, "author": 22, "rating": 3, "target": 24, "comment": "123"}	\N	2025-09-23 12:53:23.035507+03	22	user:Loser123
504	INSERT	core_order	37	\N	{"id": 37, "car_id": "JHMFB56557C404453", "status": "pending", "buyer_id": 22, "order_date": "2025-09-23T09:53:26.884279+00:00", "total_amount": 10600000.00}	2025-09-23 12:53:26.884279+03	\N	\N
505	UPDATE	core_car	JHMFB56557C404453	{"VIN": "JHMFB56557C404453", "year": 2020, "price": 10600000.00, "status": "available", "make_id": 11, "model_id": 23, "seller_id": 21, "created_at": "2025-09-17T15:23:22.982706+00:00", "description": "d\\r\\nd\\r\\nd\\r\\nd\\r\\nd\\r\\nd\\r\\nd\\r\\nd"}	{"VIN": "JHMFB56557C404453", "year": 2020, "price": 10600000.00, "status": "reserved", "make_id": 11, "model_id": 23, "seller_id": 21, "created_at": "2025-09-17T15:23:22.982706+00:00", "description": "d\\r\\nd\\r\\nd\\r\\nd\\r\\nd\\r\\nd\\r\\nd\\r\\nd"}	2025-09-23 12:53:26.884279+03	\N	\N
506	INSERT	core_transaction	15	\N	{"id": 15, "amount": 10600000.00, "status": "completed", "order_id": 37, "transaction_date": "2025-09-23T09:53:38.391367+00:00"}	2025-09-23 12:53:38.391367+03	\N	\N
507	UPDATE	core_order	37	{"id": 37, "car_id": "JHMFB56557C404453", "status": "pending", "buyer_id": 22, "order_date": "2025-09-23T09:53:26.884279+00:00", "total_amount": 10600000.00}	{"id": 37, "car_id": "JHMFB56557C404453", "status": "paid", "buyer_id": 22, "order_date": "2025-09-23T09:53:26.884279+00:00", "total_amount": 10600000.00}	2025-09-23 12:53:38.391367+03	\N	\N
508	UPDATE	core_car	JHMFB56557C404453	{"VIN": "JHMFB56557C404453", "year": 2020, "price": 10600000.00, "status": "reserved", "make_id": 11, "model_id": 23, "seller_id": 21, "created_at": "2025-09-17T15:23:22.982706+00:00", "description": "d\\r\\nd\\r\\nd\\r\\nd\\r\\nd\\r\\nd\\r\\nd\\r\\nd"}	{"VIN": "JHMFB56557C404453", "year": 2020, "price": 10600000.00, "status": "sold", "make_id": 11, "model_id": 23, "seller_id": 21, "created_at": "2025-09-17T15:23:22.982706+00:00", "description": "d\\r\\nd\\r\\nd\\r\\nd\\r\\nd\\r\\nd\\r\\nd\\r\\nd"}	2025-09-23 12:53:38.391367+03	\N	\N
509	CREATE	Review	11	\N	{"id": 11, "author": 22, "rating": 3, "target": 21, "comment": "123"}	2025-09-23 12:53:42.493382+03	22	user:Loser123
510	DELETE	UserRole	57	{"id": 57, "role": 1, "user": 3}	\N	2025-09-23 13:21:21.116915+03	37	admin:2
511	CREATE	UserRole	60	\N	{"id": 60, "role": 1, "user": 3}	2025-09-23 13:21:21.123797+03	37	admin:2
512	DELETE	UserRole	59	{"id": 59, "role": 2, "user": 38}	\N	2025-09-23 13:21:28.113064+03	37	admin:2
513	CREATE	UserRole	61	\N	{"id": 61, "role": 1, "user": 38}	2025-09-23 13:21:28.15823+03	37	admin:2
514	DELETE	UserRole	60	{"id": 60, "role": 1, "user": 3}	\N	2025-09-24 11:54:07.623171+03	37	admin:2
515	CREATE	UserRole	62	\N	{"id": 62, "role": 1, "user": 3}	2025-09-24 11:54:07.632674+03	37	admin:2
516	UPDATE	core_car	WDB1240821F323866	{"VIN": "WDB1240821F323866", "year": 2020, "price": 4000000000.00, "status": "available", "make_id": 12, "model_id": 24, "seller_id": 13, "created_at": "2025-09-22T15:59:23.347911+00:00", "description": "d"}	{"VIN": "WDB1240821F323866", "year": 2021, "price": 4000000000.00, "status": "available", "make_id": 12, "model_id": 24, "seller_id": 13, "created_at": "2025-09-22T15:59:23.347911+00:00", "description": ""}	2025-09-24 11:56:08.934912+03	\N	\N
517	UPDATE	Car	WDB1240821F323866	{"VIN": "WDB1240821F323866", "make": 12, "year": 2020, "model": 24, "price": 4000000000.0, "seller": 13, "status": "available", "description": "d"}	{"VIN": "WDB1240821F323866", "make": 12, "year": 2021, "model": 24, "price": 4000000000.0, "seller": 13, "status": "available", "description": ""}	2025-09-24 11:56:08.958759+03	13	user:NewUser
521	CREATE	Model	25	\N	{"id": 25, "make": 3, "name": "Camry2"}	2025-09-24 11:56:56.913835+03	13	user:NewUser
522	INSERT	core_car	WDB1240821D323866	\N	{"VIN": "WDB1240821D323866", "year": 2020, "price": 123321.00, "status": "available", "make_id": 3, "model_id": 25, "seller_id": 13, "created_at": "2025-09-24T08:57:03.15621+00:00", "description": "123"}	2025-09-24 11:57:03.156325+03	\N	\N
523	CREATE	Car	WDB1240821D323866	\N	{"VIN": "WDB1240821D323866", "make": 3, "year": 2020, "model": 25, "price": 123321.0, "seller": 13, "status": "available", "description": "123"}	2025-09-24 11:57:03.160134+03	13	user:NewUser
524	CREATE	CarImage	32	\N	{"id": 32, "car": "WDB1240821D323866", "image": "car_images/1655380035_18-phonoteka-org-p-oboi-furri-19_51104Dj.jpg"}	2025-09-24 11:57:03.263686+03	13	user:NewUser
525	CREATE	CarImage	33	\N	{"id": 33, "car": "WDB1240821D323866", "image": "car_images/Cameron_in_main_menu_wBCLJjU.jpg"}	2025-09-24 11:57:03.271457+03	13	user:NewUser
529	INSERT	core_order	38	\N	{"id": 38, "car_id": "WDB1240821F323866", "status": "pending", "buyer_id": 13, "order_date": "2025-09-24T08:57:40.838337+00:00", "total_amount": 4000000000.00}	2025-09-24 11:57:40.838337+03	\N	\N
545	CREATE	UserRole	63	\N	{"id": 63, "role": 3, "user": 39}	2025-09-24 12:03:09.105285+03	\N	незнакомец
530	UPDATE	core_car	WDB1240821F323866	{"VIN": "WDB1240821F323866", "year": 2021, "price": 4000000000.00, "status": "available", "make_id": 12, "model_id": 24, "seller_id": 13, "created_at": "2025-09-22T15:59:23.347911+00:00", "description": ""}	{"VIN": "WDB1240821F323866", "year": 2021, "price": 4000000000.00, "status": "reserved", "make_id": 12, "model_id": 24, "seller_id": 13, "created_at": "2025-09-22T15:59:23.347911+00:00", "description": ""}	2025-09-24 11:57:40.838337+03	\N	\N
531	INSERT	core_transaction	16	\N	{"id": 16, "amount": 4000000000.00, "status": "completed", "order_id": 38, "transaction_date": "2025-09-24T08:57:46.713616+00:00"}	2025-09-24 11:57:46.713616+03	\N	\N
532	UPDATE	core_order	38	{"id": 38, "car_id": "WDB1240821F323866", "status": "pending", "buyer_id": 13, "order_date": "2025-09-24T08:57:40.838337+00:00", "total_amount": 4000000000.00}	{"id": 38, "car_id": "WDB1240821F323866", "status": "paid", "buyer_id": 13, "order_date": "2025-09-24T08:57:40.838337+00:00", "total_amount": 4000000000.00}	2025-09-24 11:57:46.713616+03	\N	\N
533	UPDATE	core_car	WDB1240821F323866	{"VIN": "WDB1240821F323866", "year": 2021, "price": 4000000000.00, "status": "reserved", "make_id": 12, "model_id": 24, "seller_id": 13, "created_at": "2025-09-22T15:59:23.347911+00:00", "description": ""}	{"VIN": "WDB1240821F323866", "year": 2021, "price": 4000000000.00, "status": "sold", "make_id": 12, "model_id": 24, "seller_id": 13, "created_at": "2025-09-22T15:59:23.347911+00:00", "description": ""}	2025-09-24 11:57:46.713616+03	\N	\N
534	INSERT	core_order	39	\N	{"id": 39, "car_id": "JHMWM56557C404453", "status": "pending", "buyer_id": 13, "order_date": "2025-09-24T08:58:10.212324+00:00", "total_amount": 32000.00}	2025-09-24 11:58:10.212324+03	\N	\N
535	UPDATE	core_car	JHMWM56557C404453	{"VIN": "JHMWM56557C404453", "year": 2020, "price": 32000.00, "status": "available", "make_id": 12, "model_id": 24, "seller_id": 38, "created_at": "2025-09-22T18:13:41.46073+00:00", "description": "2132313"}	{"VIN": "JHMWM56557C404453", "year": 2020, "price": 32000.00, "status": "reserved", "make_id": 12, "model_id": 24, "seller_id": 38, "created_at": "2025-09-22T18:13:41.46073+00:00", "description": "2132313"}	2025-09-24 11:58:10.212324+03	\N	\N
536	INSERT	core_order	40	\N	{"id": 40, "car_id": "WDB1240821D323866", "status": "pending", "buyer_id": 13, "order_date": "2025-09-24T08:58:35.308793+00:00", "total_amount": 123321.00}	2025-09-24 11:58:35.308793+03	\N	\N
537	UPDATE	core_car	WDB1240821D323866	{"VIN": "WDB1240821D323866", "year": 2020, "price": 123321.00, "status": "available", "make_id": 3, "model_id": 25, "seller_id": 13, "created_at": "2025-09-24T08:57:03.15621+00:00", "description": "123"}	{"VIN": "WDB1240821D323866", "year": 2020, "price": 123321.00, "status": "reserved", "make_id": 3, "model_id": 25, "seller_id": 13, "created_at": "2025-09-24T08:57:03.15621+00:00", "description": "123"}	2025-09-24 11:58:35.308793+03	\N	\N
538	UPDATE	core_car	DEMO202200012XXXX	{"VIN": "DEMO202200012XXXX", "year": 2022, "price": 1117807.00, "status": "available", "make_id": 7, "model_id": 15, "seller_id": 28, "created_at": "2025-07-11T08:25:38.785055+00:00", "description": "Kia Rio, 2022 г.в. Тестовое объявление."}	{"VIN": "DEMO202200012XXXX", "year": 2022, "price": 1151341.21, "status": "available", "make_id": 7, "model_id": 15, "seller_id": 28, "created_at": "2025-07-11T08:25:38.785055+00:00", "description": "Kia Rio, 2022 г.в. Тестовое объявление."}	2025-09-24 12:00:46.703379+03	\N	\N
539	UPDATE	core_car	DEMO202200022XXXX	{"VIN": "DEMO202200022XXXX", "year": 2022, "price": 2652216.00, "status": "available", "make_id": 7, "model_id": 15, "seller_id": 24, "created_at": "2025-08-14T08:25:38.785055+00:00", "description": "Kia Rio, 2022 г.в. Тестовое объявление."}	{"VIN": "DEMO202200022XXXX", "year": 2022, "price": 2731782.48, "status": "available", "make_id": 7, "model_id": 15, "seller_id": 24, "created_at": "2025-08-14T08:25:38.785055+00:00", "description": "Kia Rio, 2022 г.в. Тестовое объявление."}	2025-09-24 12:00:46.703379+03	\N	\N
540	UPDATE	core_car	DEMO201900032XXXX	{"VIN": "DEMO201900032XXXX", "year": 2019, "price": 2570870.00, "status": "available", "make_id": 7, "model_id": 16, "seller_id": 26, "created_at": "2025-07-22T08:25:38.785055+00:00", "description": "Kia Sportage, 2019 г.в. Тестовое объявление."}	{"VIN": "DEMO201900032XXXX", "year": 2019, "price": 2647996.10, "status": "available", "make_id": 7, "model_id": 16, "seller_id": 26, "created_at": "2025-07-22T08:25:38.785055+00:00", "description": "Kia Sportage, 2019 г.в. Тестовое объявление."}	2025-09-24 12:00:46.703379+03	\N	\N
541	UPDATE	core_car	DEMO201300010XXXX	{"VIN": "DEMO201300010XXXX", "year": 2013, "price": 1994364.00, "status": "reserved", "make_id": 7, "model_id": 15, "seller_id": 25, "created_at": "2025-09-17T08:25:38.8214+00:00", "description": "Kia Rio, 2013 г.в. Тестовое объявление."}	{"VIN": "DEMO201300010XXXX", "year": 2013, "price": 2054194.92, "status": "reserved", "make_id": 7, "model_id": 15, "seller_id": 25, "created_at": "2025-09-17T08:25:38.8214+00:00", "description": "Kia Rio, 2013 г.в. Тестовое объявление."}	2025-09-24 12:00:46.703379+03	\N	\N
542	UPDATE	core_car	DEMO201800018XXXX	{"VIN": "DEMO201800018XXXX", "year": 2018, "price": 1918323.00, "status": "available", "make_id": 7, "model_id": 16, "seller_id": 28, "created_at": "2025-09-17T08:25:38.839554+00:00", "description": "Kia Sportage, 2018 г.в. Тестовое объявление."}	{"VIN": "DEMO201800018XXXX", "year": 2018, "price": 1975872.69, "status": "available", "make_id": 7, "model_id": 16, "seller_id": 28, "created_at": "2025-09-17T08:25:38.839554+00:00", "description": "Kia Sportage, 2018 г.в. Тестовое объявление."}	2025-09-24 12:00:46.703379+03	\N	\N
543	UPDATE	core_car	JHMEM56557C404453	{"VIN": "JHMEM56557C404453", "year": 2020, "price": 1000000.00, "status": "available", "make_id": 7, "model_id": 15, "seller_id": 21, "created_at": "2025-09-17T15:03:12.623451+00:00", "description": "fshdjankdnmzv"}	{"VIN": "JHMEM56557C404453", "year": 2020, "price": 1030000.00, "status": "available", "make_id": 7, "model_id": 15, "seller_id": 21, "created_at": "2025-09-17T15:03:12.623451+00:00", "description": "fshdjankdnmzv"}	2025-09-24 12:00:46.703379+03	\N	\N
544	CREATE	User	39	\N	{"id": 39, "email": "seller@mail.ru", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$vQEMSI2PNdtw0GmbQFrNCH$4nrkP+MuVFS4mUhKGwofr4gnJSjduXr6ei7sw317h3Q=", "username": "Seller", "is_active": true, "last_name": "Чистотин", "first_name": "Михаил", "last_login": null, "date_joined": "2025-09-24T09:03:08.031170+00:00", "is_superuser": false, "user_permissions": []}	2025-09-24 12:03:09.099407+03	\N	незнакомец
546	CREATE	User	40	\N	{"id": 40, "email": "Owner@mail.ru", "groups": [], "is_staff": false, "password": "pbkdf2_sha256$1000000$MsSi1glMrbkLrwGqnFxCm7$TPBbmX73bYpV7NTpy+IInCucaTAdg3XcJDqoIAjZbIg=", "username": "Owner", "is_active": true, "last_name": "Чистотин", "first_name": "Михаил", "last_login": null, "date_joined": "2025-09-24T09:03:32.386208+00:00", "is_superuser": false, "user_permissions": []}	2025-09-24 12:03:33.485418+03	\N	незнакомец
547	CREATE	UserRole	64	\N	{"id": 64, "role": 3, "user": 40}	2025-09-24 12:03:33.496139+03	\N	незнакомец
548	INSERT	core_car	WFB1240821D323866	\N	{"VIN": "WFB1240821D323866", "year": 2020, "price": 12331212.00, "status": "available", "make_id": 4, "model_id": 7, "seller_id": 40, "created_at": "2025-09-24T09:14:51.37772+00:00", "description": "123"}	2025-09-24 12:14:51.37817+03	\N	\N
549	CREATE	Car	WFB1240821D323866	\N	{"VIN": "WFB1240821D323866", "make": 4, "year": 2020, "model": 7, "price": 12331212.0, "seller": 40, "status": "available", "description": "123"}	2025-09-24 12:14:51.403147+03	40	user:Owner
550	CREATE	CarImage	34	\N	{"id": 34, "car": "WFB1240821D323866", "image": "car_images/og_og_15886766072427680_qi7FWQh.jpg"}	2025-09-24 12:14:51.472341+03	40	user:Owner
553	DELETE	CarImage	34	{"id": 34, "car": "WFB1240821D323866", "image": "car_images/og_og_15886766072427680_qi7FWQh.jpg"}	\N	2025-09-24 12:20:45.694307+03	40	user:Owner
554	DELETE	core_car	WFB1240821D323866	{"VIN": "WFB1240821D323866", "year": 2020, "price": 12331212.00, "status": "available", "make_id": 4, "model_id": 7, "seller_id": 40, "created_at": "2025-09-24T09:14:51.37772+00:00", "description": "123"}	\N	2025-09-24 12:20:45.691469+03	\N	\N
555	DELETE	Car	WFB1240821D323866	{"VIN": "WFB1240821D323866", "make": 4, "year": 2020, "model": 7, "price": 12331212.0, "seller": 40, "status": "available", "description": "123"}	\N	2025-09-24 12:20:45.703602+03	40	user:Owner
556	INSERT	core_car	WEB1240821F323866	\N	{"VIN": "WEB1240821F323866", "year": 2020, "price": 123123.00, "status": "available", "make_id": 3, "model_id": 5, "seller_id": 40, "created_at": "2025-09-24T09:21:07.135652+00:00", "description": "123"}	2025-09-24 12:21:07.136006+03	\N	\N
557	CREATE	Car	WEB1240821F323866	\N	{"VIN": "WEB1240821F323866", "make": 3, "year": 2020, "model": 5, "price": 123123.0, "seller": 40, "status": "available", "description": "123"}	2025-09-24 12:21:07.154964+03	40	user:Owner
558	CREATE	CarImage	35	\N	{"id": 35, "car": "WEB1240821F323866", "image": "car_images/Cameron_in_main_menu_SpLmQVQ.jpg"}	2025-09-24 12:21:07.220685+03	40	user:Owner
559	CREATE	CarImage	36	\N	{"id": 36, "car": "WEB1240821F323866", "image": "car_images/og_og_15886766072427680_x3J5015.jpg"}	2025-09-24 12:21:07.229606+03	40	user:Owner
560	INSERT	core_order	41	\N	{"id": 41, "car_id": "WEB1240821F323866", "status": "pending", "buyer_id": 40, "order_date": "2025-09-24T09:21:30.778938+00:00", "total_amount": 123123.00}	2025-09-24 12:21:30.778938+03	\N	\N
561	UPDATE	core_car	WEB1240821F323866	{"VIN": "WEB1240821F323866", "year": 2020, "price": 123123.00, "status": "available", "make_id": 3, "model_id": 5, "seller_id": 40, "created_at": "2025-09-24T09:21:07.135652+00:00", "description": "123"}	{"VIN": "WEB1240821F323866", "year": 2020, "price": 123123.00, "status": "reserved", "make_id": 3, "model_id": 5, "seller_id": 40, "created_at": "2025-09-24T09:21:07.135652+00:00", "description": "123"}	2025-09-24 12:21:30.778938+03	\N	\N
562	CREATE	Model	26	\N	{"id": 26, "make": 5, "name": "Tiguan"}	2025-09-24 12:29:48.781715+03	40	user:Owner
563	INSERT	core_car	WEV1240821F323866	\N	{"VIN": "WEV1240821F323866", "year": 2020, "price": 1233213.00, "status": "available", "make_id": 5, "model_id": 26, "seller_id": 40, "created_at": "2025-09-24T09:29:52.396269+00:00", "description": "123123"}	2025-09-24 12:29:52.396541+03	\N	\N
564	CREATE	Car	WEV1240821F323866	\N	{"VIN": "WEV1240821F323866", "make": 5, "year": 2020, "model": 26, "price": 1233213.0, "seller": 40, "status": "available", "description": "123123"}	2025-09-24 12:29:52.41823+03	40	user:Owner
565	CREATE	CarImage	37	\N	{"id": 37, "car": "WEV1240821F323866", "image": "car_images/Cameron_in_main_menu_UcKUyg4.jpg"}	2025-09-24 12:29:52.488079+03	40	user:Owner
566	CREATE	CarImage	38	\N	{"id": 38, "car": "WEV1240821F323866", "image": "car_images/og_og_15886766072427680_KWy5U4o.jpg"}	2025-09-24 12:29:52.495108+03	40	user:Owner
567	INSERT	core_order	42	\N	{"id": 42, "car_id": "DEMO201600007XXXX", "status": "pending", "buyer_id": 40, "order_date": "2025-09-24T09:35:46.794677+00:00", "total_amount": 582244.00}	2025-09-24 12:35:46.794677+03	\N	\N
568	UPDATE	core_car	DEMO201600007XXXX	{"VIN": "DEMO201600007XXXX", "year": 2016, "price": 582244.00, "status": "available", "make_id": 8, "model_id": 18, "seller_id": 28, "created_at": "2025-07-21T08:25:38.785055+00:00", "description": "Hyundai Tucson, 2016 г.в. Тестовое объявление."}	{"VIN": "DEMO201600007XXXX", "year": 2016, "price": 582244.00, "status": "reserved", "make_id": 8, "model_id": 18, "seller_id": 28, "created_at": "2025-07-21T08:25:38.785055+00:00", "description": "Hyundai Tucson, 2016 г.в. Тестовое объявление."}	2025-09-24 12:35:46.794677+03	\N	\N
569	DELETE	CarImage	36	{"id": 36, "car": "WEB1240821F323866", "image": "car_images/og_og_15886766072427680_x3J5015.jpg"}	\N	2025-09-24 12:36:45.870938+03	40	user:Owner
570	DELETE	CarImage	35	{"id": 35, "car": "WEB1240821F323866", "image": "car_images/Cameron_in_main_menu_SpLmQVQ.jpg"}	\N	2025-09-24 12:36:45.875998+03	40	user:Owner
571	DELETE	core_order	41	{"id": 41, "car_id": "WEB1240821F323866", "status": "pending", "buyer_id": 40, "order_date": "2025-09-24T09:21:30.778938+00:00", "total_amount": 123123.00}	\N	2025-09-24 12:36:45.869089+03	\N	\N
572	DELETE	Order	41	{"id": 41, "car": "WEB1240821F323866", "buyer": 40, "status": "pending", "total_amount": 123123.0}	\N	2025-09-24 12:36:45.882686+03	40	user:Owner
593	DELETE	CarImage	39	{"id": 39, "car": "WEV1240821F323866", "image": "car_images/Cameron_in_main_menu_2ZZ9U0M.jpg"}	\N	2025-09-24 13:00:56.444134+03	40	user:Owner
573	DELETE	core_car	WEB1240821F323866	{"VIN": "WEB1240821F323866", "year": 2020, "price": 123123.00, "status": "reserved", "make_id": 3, "model_id": 5, "seller_id": 40, "created_at": "2025-09-24T09:21:07.135652+00:00", "description": "123"}	\N	2025-09-24 12:36:45.869089+03	\N	\N
574	DELETE	Car	WEB1240821F323866	{"VIN": "WEB1240821F323866", "make": 3, "year": 2020, "model": 5, "price": 123123.0, "seller": 40, "status": "reserved", "description": "123"}	\N	2025-09-24 12:36:45.886236+03	40	user:Owner
575	INSERT	core_order	43	\N	{"id": 43, "car_id": "WEV1240821F323866", "status": "pending", "buyer_id": 39, "order_date": "2025-09-24T09:37:08.256961+00:00", "total_amount": 1233213.00}	2025-09-24 12:37:08.256961+03	\N	\N
576	UPDATE	core_car	WEV1240821F323866	{"VIN": "WEV1240821F323866", "year": 2020, "price": 1233213.00, "status": "available", "make_id": 5, "model_id": 26, "seller_id": 40, "created_at": "2025-09-24T09:29:52.396269+00:00", "description": "123123"}	{"VIN": "WEV1240821F323866", "year": 2020, "price": 1233213.00, "status": "reserved", "make_id": 5, "model_id": 26, "seller_id": 40, "created_at": "2025-09-24T09:29:52.396269+00:00", "description": "123123"}	2025-09-24 12:37:08.256961+03	\N	\N
577	UPDATE	core_car	WEV1240821F323866	{"VIN": "WEV1240821F323866", "year": 2020, "price": 1233213.00, "status": "reserved", "make_id": 5, "model_id": 26, "seller_id": 40, "created_at": "2025-09-24T09:29:52.396269+00:00", "description": "123123"}	{"VIN": "WEV1240821F323866", "year": 2020, "price": 1233213.00, "status": "available", "make_id": 5, "model_id": 26, "seller_id": 40, "created_at": "2025-09-24T09:29:52.396269+00:00", "description": "123123"}	2025-09-24 12:37:16.667932+03	\N	\N
578	UPDATE	Car	WEV1240821F323866	{"VIN": "WEV1240821F323866", "make": 5, "year": 2020, "model": 26, "price": 1233213.0, "seller": 40, "status": "reserved", "description": "123123"}	{"VIN": "WEV1240821F323866", "make": 5, "year": 2020, "model": 26, "price": 1233213.0, "seller": 40, "status": "available", "description": "123123"}	2025-09-24 12:37:16.678581+03	40	user:Owner
579	UPDATE	core_order	43	{"id": 43, "car_id": "WEV1240821F323866", "status": "pending", "buyer_id": 39, "order_date": "2025-09-24T09:37:08.256961+00:00", "total_amount": 1233213.00}	{"id": 43, "car_id": "WEV1240821F323866", "status": "cancelled", "buyer_id": 39, "order_date": "2025-09-24T09:37:08.256961+00:00", "total_amount": 1233213.00}	2025-09-24 12:37:16.667932+03	\N	\N
580	UPDATE	Order	43	{"id": 43, "car": "WEV1240821F323866", "buyer": 39, "status": "pending", "total_amount": 1233213.0}	{"id": 43, "car": "WEV1240821F323866", "buyer": 39, "status": "cancelled", "total_amount": 1233213.0}	2025-09-24 12:37:16.682194+03	40	user:Owner
581	INSERT	core_order	44	\N	{"id": 44, "car_id": "WEV1240821F323866", "status": "pending", "buyer_id": 39, "order_date": "2025-09-24T09:45:09.976968+00:00", "total_amount": 1233213.00}	2025-09-24 12:45:09.976968+03	\N	\N
582	UPDATE	core_car	WEV1240821F323866	{"VIN": "WEV1240821F323866", "year": 2020, "price": 1233213.00, "status": "available", "make_id": 5, "model_id": 26, "seller_id": 40, "created_at": "2025-09-24T09:29:52.396269+00:00", "description": "123123"}	{"VIN": "WEV1240821F323866", "year": 2020, "price": 1233213.00, "status": "reserved", "make_id": 5, "model_id": 26, "seller_id": 40, "created_at": "2025-09-24T09:29:52.396269+00:00", "description": "123123"}	2025-09-24 12:45:09.976968+03	\N	\N
583	UPDATE	core_car	WEV1240821F323866	{"VIN": "WEV1240821F323866", "year": 2020, "price": 1233213.00, "status": "reserved", "make_id": 5, "model_id": 26, "seller_id": 40, "created_at": "2025-09-24T09:29:52.396269+00:00", "description": "123123"}	{"VIN": "WEV1240821F323866", "year": 2020, "price": 1233213.00, "status": "available", "make_id": 5, "model_id": 26, "seller_id": 40, "created_at": "2025-09-24T09:29:52.396269+00:00", "description": "123123"}	2025-09-24 12:45:26.945779+03	\N	\N
584	UPDATE	Car	WEV1240821F323866	{"VIN": "WEV1240821F323866", "make": 5, "year": 2020, "model": 26, "price": 1233213.0, "seller": 40, "status": "reserved", "description": "123123"}	{"VIN": "WEV1240821F323866", "make": 5, "year": 2020, "model": 26, "price": 1233213.0, "seller": 40, "status": "available", "description": "123123"}	2025-09-24 12:45:26.955806+03	40	user:Owner
585	UPDATE	core_order	44	{"id": 44, "car_id": "WEV1240821F323866", "status": "pending", "buyer_id": 39, "order_date": "2025-09-24T09:45:09.976968+00:00", "total_amount": 1233213.00}	{"id": 44, "car_id": "WEV1240821F323866", "status": "cancelled", "buyer_id": 39, "order_date": "2025-09-24T09:45:09.976968+00:00", "total_amount": 1233213.00}	2025-09-24 12:45:26.945779+03	\N	\N
586	UPDATE	Order	44	{"id": 44, "car": "WEV1240821F323866", "buyer": 39, "status": "pending", "total_amount": 1233213.0}	{"id": 44, "car": "WEV1240821F323866", "buyer": 39, "status": "cancelled", "total_amount": 1233213.0}	2025-09-24 12:45:26.960388+03	40	user:Owner
587	CREATE	Review	12	\N	{"id": 12, "author": 40, "rating": 3, "target": 24, "comment": "[s[s[[s"}	2025-09-24 12:45:37.869159+03	40	user:Owner
588	UPDATE	Review	12	{"id": 12, "author": 40, "rating": 3, "target": 24, "comment": "[s[s[[s"}	{"id": 12, "author": 40, "rating": 5, "target": 24, "comment": "123123123213"}	2025-09-24 12:45:45.759492+03	40	user:Owner
589	DELETE	Review	12	{"id": 12, "author": 40, "rating": 5, "target": 24, "comment": "123123123213"}	\N	2025-09-24 12:45:48.153532+03	40	user:Owner
590	UPDATE	core_car	WEV1240821F323866	{"VIN": "WEV1240821F323866", "year": 2020, "price": 1233213.00, "status": "available", "make_id": 5, "model_id": 26, "seller_id": 40, "created_at": "2025-09-24T09:29:52.396269+00:00", "description": "123123"}	{"VIN": "WEV1240821F323866", "year": 2020, "price": 123321.00, "status": "unavailable", "make_id": 5, "model_id": 26, "seller_id": 40, "created_at": "2025-09-24T09:29:52.396269+00:00", "description": "123"}	2025-09-24 13:00:53.725858+03	\N	\N
591	UPDATE	Car	WEV1240821F323866	{"VIN": "WEV1240821F323866", "make": 5, "year": 2020, "model": 26, "price": 1233213.0, "seller": 40, "status": "available", "description": "123123"}	{"VIN": "WEV1240821F323866", "make": 5, "year": 2020, "model": 26, "price": 123321.0, "seller": 40, "status": "unavailable", "description": "123"}	2025-09-24 13:00:53.734466+03	40	user:Owner
592	CREATE	CarImage	39	\N	{"id": 39, "car": "WEV1240821F323866", "image": "car_images/Cameron_in_main_menu_2ZZ9U0M.jpg"}	2025-09-24 13:00:53.789922+03	40	user:Owner
594	DELETE	CarImage	38	{"id": 38, "car": "WEV1240821F323866", "image": "car_images/og_og_15886766072427680_KWy5U4o.jpg"}	\N	2025-09-24 13:00:56.446371+03	40	user:Owner
595	DELETE	CarImage	37	{"id": 37, "car": "WEV1240821F323866", "image": "car_images/Cameron_in_main_menu_UcKUyg4.jpg"}	\N	2025-09-24 13:00:56.448856+03	40	user:Owner
596	DELETE	core_order	43	{"id": 43, "car_id": "WEV1240821F323866", "status": "cancelled", "buyer_id": 39, "order_date": "2025-09-24T09:37:08.256961+00:00", "total_amount": 1233213.00}	\N	2025-09-24 13:00:56.442488+03	\N	\N
597	DELETE	core_order	44	{"id": 44, "car_id": "WEV1240821F323866", "status": "cancelled", "buyer_id": 39, "order_date": "2025-09-24T09:45:09.976968+00:00", "total_amount": 1233213.00}	\N	2025-09-24 13:00:56.442488+03	\N	\N
598	DELETE	Order	44	{"id": 44, "car": "WEV1240821F323866", "buyer": 39, "status": "cancelled", "total_amount": 1233213.0}	\N	2025-09-24 13:00:56.453739+03	40	user:Owner
599	DELETE	Order	43	{"id": 43, "car": "WEV1240821F323866", "buyer": 39, "status": "cancelled", "total_amount": 1233213.0}	\N	2025-09-24 13:00:56.456299+03	40	user:Owner
600	DELETE	core_car	WEV1240821F323866	{"VIN": "WEV1240821F323866", "year": 2020, "price": 123321.00, "status": "unavailable", "make_id": 5, "model_id": 26, "seller_id": 40, "created_at": "2025-09-24T09:29:52.396269+00:00", "description": "123"}	\N	2025-09-24 13:00:56.442488+03	\N	\N
601	DELETE	Car	WEV1240821F323866	{"VIN": "WEV1240821F323866", "make": 5, "year": 2020, "model": 26, "price": 123321.0, "seller": 40, "status": "unavailable", "description": "123"}	\N	2025-09-24 13:00:56.45904+03	40	user:Owner
602	DELETE	UserRole	62	{"id": 62, "role": 1, "user": 3}	\N	2025-09-24 15:22:54.06512+03	37	admin:2
603	CREATE	UserRole	65	\N	{"id": 65, "role": 1, "user": 3}	2025-09-24 15:22:54.07608+03	37	admin:2
604	UPDATE	core_car	DEMO201700011XXXX	{"VIN": "DEMO201700011XXXX", "year": 2017, "price": 1890113.00, "status": "reserved", "make_id": 10, "model_id": 22, "seller_id": 25, "created_at": "2025-09-17T08:25:38.823611+00:00", "description": "LADA Granta, 2017 г.в. Тестовое объявление."}	{"VIN": "DEMO201700011XXXX", "year": 2017, "price": 1946816.39, "status": "reserved", "make_id": 10, "model_id": 22, "seller_id": 25, "created_at": "2025-09-17T08:25:38.823611+00:00", "description": "LADA Granta, 2017 г.в. Тестовое объявление."}	2025-09-24 15:22:57.675523+03	\N	\N
605	CREATE	UserRole	66	\N	{"id": 66, "role": 1, "user": 6}	2025-09-24 15:39:50.783527+03	37	admin:2
606	UPDATE	core_car	DEMO201700011XXXX	{"VIN": "DEMO201700011XXXX", "year": 2017, "price": 1946816.39, "status": "reserved", "make_id": 10, "model_id": 22, "seller_id": 25, "created_at": "2025-09-17T08:25:38.823611+00:00", "description": "LADA Granta, 2017 г.в. Тестовое объявление."}	{"VIN": "DEMO201700011XXXX", "year": 2017, "price": 1985752.72, "status": "reserved", "make_id": 10, "model_id": 22, "seller_id": 25, "created_at": "2025-09-17T08:25:38.823611+00:00", "description": "LADA Granta, 2017 г.в. Тестовое объявление."}	2025-09-24 15:56:22.772955+03	\N	\N
607	DELETE	UserRole	65	{"id": 65, "role": 1, "user": 3}	\N	2025-09-24 15:56:25.440402+03	37	admin:2
608	CREATE	UserRole	67	\N	{"id": 67, "role": 1, "user": 3}	2025-09-24 15:56:25.447426+03	37	admin:2
609	INSERT	core_car	USERWN47EG3D	\N	{"VIN": "USERWN47EG3D", "year": 2020, "price": 100000.00, "status": "available", "make_id": 3, "model_id": 3, "seller_id": 42, "created_at": "2025-09-24T18:45:46.629016+00:00", "description": ""}	2025-09-24 21:45:46.629335+03	\N	\N
610	INSERT	core_car	USER7KX0QSP3	\N	{"VIN": "USER7KX0QSP3", "year": 2020, "price": 100000.00, "status": "available", "make_id": 3, "model_id": 3, "seller_id": 42, "created_at": "2025-09-24T18:50:13.92271+00:00", "description": ""}	2025-09-24 21:50:13.922881+03	\N	\N
611	INSERT	core_car	USERQ7C7SJ0G	\N	{"VIN": "USERQ7C7SJ0G", "year": 2020, "price": 100000.00, "status": "available", "make_id": 3, "model_id": 3, "seller_id": 42, "created_at": "2025-09-24T19:00:55.830157+00:00", "description": ""}	2025-09-24 22:00:55.830324+03	\N	\N
\.


--
-- Data for Name: core_backupconfig; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.core_backupconfig (id, last_run_at) FROM stdin;
1	2025-09-24 19:30:10.010293+03
\.


--
-- Data for Name: core_backupfile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.core_backupfile (id, created_at, method, status, file_path, file_size, checksum_sha256, log, created_by_id) FROM stdin;
1	2025-09-24 15:52:08.835675+03	pg_dump	success	C:\\API_CAR_DASHBOARD\\backups\\backup_DB_Car_dash_20250924_155208.sql.gz	37878	c73fd11fc8f1f722a4a7adff9c43ffb05452a70314601c3d441461577752fc88	OK	37
2	2025-09-24 19:30:10.015673+03	pg_dump	success	C:\\API_CAR_DASHBOARD\\backups\\backup_DB_Car_dash_20250924_193010.sql.gz	38409	585b8f062a297cbbee5876384bcd2b1106a0c6a5e9c635b245952cdead42410b	OK	\N
3	2025-09-24 19:52:11.362099+03	pg_dump	success	C:\\API_CAR_DASHBOARD\\backups\\backup_DB_Car_dash_20250924_195211.sql.gz	38409	a3b4be910978c0c6c5cd66113c02d6cb64df76ce3998fd7d9872cd2a6a51f28b	OK	37
4	2025-09-24 22:21:36.686882+03	pg_dump	pending		0			37
\.


--
-- Data for Name: core_car; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.core_car ("VIN", year, price, status, description, created_at, seller_id, make_id, model_id) FROM stdin;
DEMO201200014XXXX	2012	1428731.85	reserved	Mercedes-Benz GLC, 2012 г.в. Тестовое объявление.	2025-09-13 11:25:38.785055+03	26	6	14
DEMO201300006XXXX	2013	2093206.50	sold	Mercedes-Benz E-Class, 2013 г.в. Тестовое объявление.	2025-09-05 11:25:38.785055+03	24	6	13
JHMFB56557C404453	2020	10600000.00	sold	d\r\nd\r\nd\r\nd\r\nd\r\nd\r\nd\r\nd	2025-09-17 18:23:22.982706+03	21	11	23
DEMO202000008XXXX	2020	1629678.00	available	BMW 5 Series, 2020 г.в. Тестовое объявление.	2025-06-29 11:25:38.785055+03	24	4	7
WDB1240821F323866	2021	4000000000.00	sold		2025-09-22 18:59:23.347911+03	13	12	24
DEMO201200009XXXX	2012	3173539.00	available	Hyundai Solaris, 2012 г.в. Тестовое объявление.	2025-08-19 11:25:38.785055+03	24	8	17
DEMO202200012XXXX	2022	1151341.21	available	Kia Rio, 2022 г.в. Тестовое объявление.	2025-07-11 11:25:38.785055+03	28	7	15
DEMO202200022XXXX	2022	2731782.48	available	Kia Rio, 2022 г.в. Тестовое объявление.	2025-08-14 11:25:38.785055+03	24	7	15
DEMO201700005XXXX	2017	1565476.00	sold	Audi Q5, 2017 г.в. Тестовое объявление.	2025-08-29 11:25:38.785055+03	27	5	11
DEMO201600007XXXX	2016	582244.00	reserved	Hyundai Tucson, 2016 г.в. Тестовое объявление.	2025-07-21 11:25:38.785055+03	28	8	18
USERWN47EG3D	2020	100000.00	available		2025-09-24 21:45:46.629016+03	42	3	3
DEMO201500000XXXX	2015	1336213.00	available	BMW 3 Series, 2015 г.в. Тестовое объявление.	2025-08-31 11:25:38.785055+03	26	4	6
DEMO202300003XXXX	2023	3125812.00	available	Toyota RAV4, 2023 г.в. Тестовое объявление.	2025-06-20 11:25:38.785055+03	25	3	5
DEMO201300015XXXX	2013	1284926.00	available	Hyundai Tucson, 2013 г.в. Тестовое объявление.	2025-07-07 11:25:38.785055+03	26	8	18
DEMO201200034XXXX	2012	732654.30	available	Mercedes-Benz GLC, 2012 г.в. Тестовое объявление.	2025-06-19 11:25:38.785055+03	25	6	14
DEMO201500036XXXX	2015	2794796.55	available	Mercedes-Benz E-Class, 2015 г.в. Тестовое объявление.	2025-09-01 11:25:38.785055+03	27	6	13
DEMO201800013XXXX	2018	1608855.15	reserved	Mercedes-Benz C-Class, 2018 г.в. Тестовое объявление.	2025-09-17 11:25:38.828029+03	27	6	12
DEMO202100004XXXX	2021	1629488.64	available	Volkswagen Polo, 2021 г.в. Тестовое объявление.	2025-09-17 11:25:38.801713+03	27	9	19
DEMO202200025XXXX	2022	2529292.00	available	BMW X3, 2022 г.в. Тестовое объявление.	2025-07-02 11:25:38.785055+03	26	4	8
JHMWM56557C404453	2020	32000.00	reserved	2132313	2025-09-22 21:13:41.46073+03	38	12	24
DEMO201900032XXXX	2019	2647996.10	available	Kia Sportage, 2019 г.в. Тестовое объявление.	2025-07-22 11:25:38.785055+03	26	7	16
DEMO201300010XXXX	2013	2054194.92	reserved	Kia Rio, 2013 г.в. Тестовое объявление.	2025-09-17 11:25:38.8214+03	25	7	15
DEMO201200028XXXX	2012	1410288.00	available	Hyundai Tucson, 2012 г.в. Тестовое объявление.	2025-07-07 11:25:38.785055+03	25	8	18
DEMO202000030XXXX	2020	1092592.00	available	Audi Q5, 2020 г.в. Тестовое объявление.	2025-08-15 11:25:38.785055+03	27	5	11
DEMO201700011XXXX	2017	1985752.72	reserved	LADA Granta, 2017 г.в. Тестовое объявление.	2025-09-17 11:25:38.823611+03	25	10	22
DEMO201300033XXXX	2013	1818033.00	available	BMW 3 Series, 2013 г.в. Тестовое объявление.	2025-09-15 11:25:38.785055+03	25	4	6
USER7KX0QSP3	2020	100000.00	available		2025-09-24 21:50:13.92271+03	42	3	3
DEMO201300001XXXX	2013	2876705.00	sold	BMW X3, 2013 г.в. Тестовое объявление.	2025-09-17 11:25:38.793134+03	28	4	8
DEMO201500002XXXX	2015	1375850.00	reserved	Toyota Camry, 2015 г.в. Тестовое объявление.	2025-09-17 11:25:38.795167+03	24	3	3
DEMO201800016XXXX	2018	3096316.00	available	Hyundai Solaris, 2018 г.в. Тестовое объявление.	2025-09-17 11:25:38.835479+03	27	8	17
DEMO201500017XXXX	2015	2754548.00	sold	Audi A6, 2015 г.в. Тестовое объявление.	2025-09-17 11:25:38.837559+03	25	5	10
DEMO201300019XXXX	2013	597620.00	available	Audi Q5, 2013 г.в. Тестовое объявление.	2025-09-17 11:25:38.841552+03	27	5	11
DEMO202200020XXXX	2022	2170667.00	sold	Audi Q5, 2022 г.в. Тестовое объявление.	2025-09-17 11:25:38.844407+03	25	5	11
DEMO202100021XXXX	2021	2363143.00	available	BMW 5 Series, 2021 г.в. Тестовое объявление.	2025-09-17 11:25:38.846449+03	27	4	7
DEMO201800023XXXX	2018	1063361.00	sold	Hyundai Solaris, 2018 г.в. Тестовое объявление.	2025-09-17 11:25:38.850909+03	26	8	17
DEMO202000024XXXX	2020	1149320.00	sold	Toyota RAV4, 2020 г.в. Тестовое объявление.	2025-09-17 11:25:38.854701+03	26	3	5
DEMO201900027XXXX	2019	481691.00	reserved	Toyota RAV4, 2019 г.в. Тестовое объявление.	2025-09-17 11:25:38.861736+03	26	3	5
JHMCM56557C404453	1991	1000000.00	available	123	2025-09-17 17:00:19.677896+03	21	3	3
DEMO201300029XXXX	2013	2634331.00	sold	BMW 3 Series, 2013 г.в. Тестовое объявление.	2025-09-17 11:25:38.866231+03	27	4	6
DEMO201400026XXXX	2014	2795434.95	reserved	Mercedes-Benz C-Class, 2014 г.в. Тестовое объявление.	2025-09-17 11:25:38.85966+03	26	6	12
DEMO201200035XXXX	2012	1785917.00	sold	Toyota Camry, 2012 г.в. Тестовое объявление.	2025-09-17 11:25:38.88016+03	24	3	3
DEMO202300031XXXX	2023	3425254.56	reserved	Volkswagen Polo, 2023 г.в. Тестовое объявление.	2025-09-17 11:25:38.870217+03	28	9	19
DEMO201800037XXXX	2018	1198637.00	sold	LADA Vesta, 2018 г.в. Тестовое объявление.	2025-09-17 11:25:38.884625+03	27	10	21
DEMA201700001XXXX	2025	23920000.00	reserved	iusdghbsildukfjbdjhzgbdskjgbjdfsgdfg\r\nsdfg\r\nsdfg\r\ndsf\r\ngdsf\r\ng\r\ndsfg\r\nsdf\r\ngdsfg\r\ndsfg\r\ndsf\r\ngdsf\r\ng\r\ndsfg\r\ndsf\r\ng	2025-09-17 11:36:04.062721+03	20	9	20
DEMO201700038XXXX	2017	2176617.00	sold	BMW X3, 2017 г.в. Тестовое объявление.	2025-09-17 11:25:38.886626+03	27	4	8
DEMO201200039XXXX	2012	2088716.00	sold	LADA Vesta, 2012 г.в. Тестовое объявление.	2025-09-17 11:25:38.888624+03	24	10	21
WDB1240821D323866	2020	123321.00	reserved	123	2025-09-24 11:57:03.15621+03	13	3	25
DEMO201800018XXXX	2018	1975872.69	available	Kia Sportage, 2018 г.в. Тестовое объявление.	2025-09-17 11:25:38.839554+03	28	7	16
JHMEM56557C404453	2020	1030000.00	available	fshdjankdnmzv	2025-09-17 18:03:12.623451+03	21	7	15
USERQ7C7SJ0G	2020	100000.00	available		2025-09-24 22:00:55.830157+03	42	3	3
\.


--
-- Data for Name: core_carimage; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.core_carimage (id, image, car_id) FROM stdin;
19	car_images/653302_jVf2Plq.jpg	DEMA201700001XXXX
20	car_images/1655380035_18-phonoteka-org-p-oboi-furri-19_X0mwMwy.jpg	DEMA201700001XXXX
21	car_images/Cameron_in_main_menu_4K5GfnO.jpg	JHMCM56557C404453
22	car_images/og_og_15886766072427680_JuQZJKf.jpg	JHMCM56557C404453
23	car_images/1655380035_18-phonoteka-org-p-oboi-furri-19_JOPZqS8.jpg	JHMEM56557C404453
24	car_images/og_og_15886766072427680_uCvjN1a.jpg	JHMEM56557C404453
25	car_images/606506_OtuCmrn.jpg	JHMFB56557C404453
26	car_images/653302_sO7XucX.jpg	JHMFB56557C404453
27	car_images/og_og_15886766072427680_Ct7gOAT.jpg	JHMFB56557C404453
28	car_images/653302_F0fvZbG.jpg	WDB1240821F323866
29	car_images/1655380035_18-phonoteka-org-p-oboi-furri-19_sEyDt6R.jpg	WDB1240821F323866
30	car_images/1655380035_18-phonoteka-org-p-oboi-furri-19_AsZvgDc.jpg	JHMWM56557C404453
31	car_images/Cameron_in_main_menu_wcuwaWF.jpg	JHMWM56557C404453
32	car_images/1655380035_18-phonoteka-org-p-oboi-furri-19_51104Dj.jpg	WDB1240821D323866
33	car_images/Cameron_in_main_menu_wBCLJjU.jpg	WDB1240821D323866
\.


--
-- Data for Name: core_make; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.core_make (id, name) FROM stdin;
3	Toyota
4	BMW
5	Audi
6	Mercedes-Benz
7	Kia
8	Hyundai
9	Volkswagen
10	LADA
11	loser
12	Toyota2
\.


--
-- Data for Name: core_model; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.core_model (id, name, make_id) FROM stdin;
3	Camry	3
4	Corolla	3
5	RAV4	3
6	3 Series	4
7	5 Series	4
8	X3	4
9	A4	5
10	A6	5
11	Q5	5
12	C-Class	6
13	E-Class	6
14	GLC	6
15	Rio	7
16	Sportage	7
17	Solaris	8
18	Tucson	8
19	Polo	9
20	Tiguan	9
21	Vesta	10
22	Granta	10
23	loser	11
24	Camry2	12
25	Camry2	3
26	Tiguan	5
\.


--
-- Data for Name: core_order; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.core_order (id, order_date, status, total_amount, buyer_id, car_id) FROM stdin;
33	2025-09-17 18:05:01.069628+03	cancelled	1000000.00	22	JHMCM56557C404453
34	2025-09-17 18:16:49.326265+03	cancelled	1000000.00	22	JHMEM56557C404453
35	2025-09-17 18:16:52.53991+03	cancelled	1000000.00	22	JHMCM56557C404453
36	2025-09-22 21:13:51.690944+03	pending	1428731.85	38	DEMO201200014XXXX
30	2025-09-17 17:14:39.776584+03	paid	1993530.00	21	DEMO201300006XXXX
37	2025-09-23 12:53:26.884279+03	paid	10600000.00	22	JHMFB56557C404453
7	2025-09-23 11:25:38.793134+03	paid	2876705.00	30	DEMO201300001XXXX
8	2025-09-25 11:25:38.795167+03	pending	1375850.00	30	DEMO201500002XXXX
9	2025-09-20 11:25:38.801713+03	cancelled	1566816.00	33	DEMO202100004XXXX
10	2025-10-02 11:25:38.8214+03	pending	1994364.00	32	DEMO201300010XXXX
11	2025-09-22 11:25:38.823611+03	pending	1890113.00	29	DEMO201700011XXXX
12	2025-09-26 11:25:38.828029+03	pending	1532243.00	32	DEMO201800013XXXX
38	2025-09-24 11:57:40.838337+03	paid	4000000000.00	13	WDB1240821F323866
13	2025-09-21 11:25:38.835479+03	cancelled	3096316.00	32	DEMO201800016XXXX
39	2025-09-24 11:58:10.212324+03	pending	32000.00	13	JHMWM56557C404453
14	2025-10-05 11:25:38.837559+03	paid	2754548.00	29	DEMO201500017XXXX
40	2025-09-24 11:58:35.308793+03	pending	123321.00	13	WDB1240821D323866
15	2025-09-18 11:25:38.839554+03	cancelled	1918323.00	31	DEMO201800018XXXX
16	2025-09-22 11:25:38.841552+03	cancelled	597620.00	33	DEMO201300019XXXX
42	2025-09-24 12:35:46.794677+03	pending	582244.00	40	DEMO201600007XXXX
17	2025-09-19 11:25:38.844407+03	paid	2170667.00	30	DEMO202200020XXXX
18	2025-09-29 11:25:38.846449+03	cancelled	2363143.00	30	DEMO202100021XXXX
19	2025-09-18 11:25:38.850909+03	paid	1063361.00	33	DEMO201800023XXXX
20	2025-10-05 11:25:38.854701+03	paid	1149320.00	33	DEMO202000024XXXX
21	2025-09-24 11:25:38.85966+03	pending	2662319.00	31	DEMO201400026XXXX
22	2025-10-01 11:25:38.861736+03	pending	481691.00	31	DEMO201900027XXXX
23	2025-10-06 11:25:38.866231+03	paid	2634331.00	32	DEMO201300029XXXX
24	2025-10-03 11:25:38.870217+03	pending	3293514.00	30	DEMO202300031XXXX
25	2025-10-01 11:25:38.88016+03	paid	1785917.00	30	DEMO201200035XXXX
26	2025-09-17 11:25:38.884625+03	paid	1198637.00	33	DEMO201800037XXXX
27	2025-10-17 11:25:38.886626+03	paid	2176617.00	29	DEMO201700038XXXX
28	2025-10-10 11:25:38.888624+03	paid	2088716.00	29	DEMO201200039XXXX
31	2025-09-17 17:16:02.856735+03	pending	23000000.00	21	DEMA201700001XXXX
29	2025-09-17 17:10:56.561018+03	paid	1565476.00	21	DEMO201700005XXXX
32	2025-09-17 18:04:39.119723+03	cancelled	1000000.00	22	JHMEM56557C404453
\.


--
-- Data for Name: core_review; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.core_review (id, rating, comment, created_at, author_id, target_id) FROM stdin;
3	3	Были мелкие недочёты, но в целом ок.	2025-09-17 11:25:39.113786+03	33	26
4	5	Отличная сделка, рекомендую!	2025-09-17 11:25:39.119376+03	29	24
5	3	Отличная сделка, рекомендую!	2025-09-17 11:25:39.124553+03	32	27
6	4	Быстро договорились, всё чётко 👍	2025-09-17 11:25:39.127365+03	30	25
11	3	123	2025-09-23 12:53:42.45034+03	22	21
\.


--
-- Data for Name: core_role; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.core_role (id, name) FROM stdin;
1	admin
2	analitic
3	user
4	LOSE
\.


--
-- Data for Name: core_transaction; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.core_transaction (id, amount, transaction_date, status, order_id) FROM stdin;
3	2876705.00	2025-09-17 11:25:38.908328+03	completed	7
4	2754548.00	2025-09-17 11:25:38.959528+03	completed	14
5	2170667.00	2025-09-17 11:25:38.99003+03	completed	17
6	1063361.00	2025-09-17 11:25:39.012067+03	completed	19
7	1149320.00	2025-09-17 11:25:39.027203+03	completed	20
8	2634331.00	2025-09-17 11:25:39.050955+03	completed	23
9	1785917.00	2025-09-17 11:25:39.068796+03	completed	25
10	1198637.00	2025-09-17 11:25:39.083545+03	completed	26
11	2176617.00	2025-09-17 11:25:39.096433+03	completed	27
12	2088716.00	2025-09-17 11:25:39.110684+03	completed	28
13	1565476.00	2025-09-17 17:29:08.68558+03	completed	29
14	1993530.00	2025-09-22 21:44:29.928821+03	completed	30
15	10600000.00	2025-09-23 12:53:38.391367+03	completed	37
16	4000000000.00	2025-09-24 11:57:46.713616+03	completed	38
\.


--
-- Data for Name: core_user; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.core_user (id, password, last_login, is_superuser, username, first_name, last_name, email, is_staff, is_active, date_joined) FROM stdin;
1	pbkdf2_sha256$1000000$k5EQV5YioWpUjoPi00h3eU$MQNgPcHApgF2RmJg0E78GaL2ABwubv/e/RW5XGUjNjM=	\N	t	123			123@mail.ru	t	t	2025-09-12 14:02:22.728855+03
3	pbkdf2_sha256$1000000$0FwedrlKFvKszMegmfsQTB$q0efxt3tpInZUzhxwW6w2sGOZHgzZbab9/5flUSxwhI=	\N	f	Loser2	None	None	user@example.com	f	t	2025-09-12 14:16:12.08136+03
6	pbkdf2_sha256$1000000$s58lGOn3RvBJw4NTMhFx1M$DGlBq3qSuaaX/8P7Z1vmNrle/whzx/PL9Go9Xd5v0S0=	\N	f	gmakzeBDPB6M84	Михаил	Чистотин	userNEW@example.com	f	t	2025-09-12 14:21:01.360835+03
7	pbkdf2_sha256$1000000$w3RpPxvj1ZA9Z0NnksDkml$bS7JWnZf55XgCcL8m+Q2T+3BY0OVrXCEdVM5KdQMf98=	\N	f	gmakzeBDPB6M844	Михаил	Чистотин	userNEW@example.com	f	t	2025-09-12 14:28:21.682825+03
8	pbkdf2_sha256$1000000$UTcDc2X8ZWrwaBYH4n6vHP$p5YT2nWylyhGDtsxibJvdTt2Cx0oWJGaUY39zOljTNQ=	\N	f	CRtywv9nrMhWdkIZTboiCva9lVjEFEGzq0hoHWch7cK7psGNMRyHclqX3B_EMqBGPg58jBMS_kDNLuj47iue8oV	фывфыв	Дщыук	user@example.com	f	t	2025-09-12 14:39:02.993083+03
9	pbkdf2_sha256$1000000$yq2cnAKATPoh2vtgV0TbnU$WlArMJ7W/cd9dX/Ehez9DkIiUESxzzB88VUCcJCVd2M=	\N	f	CRtywv9nrMhWdkIZTboiCva9lVjEFE123Gzq0hoHWch7cK7psGNMRyHclqX3B_EMqBGPg58jBMS_kDNLuj47iue8oV	фывфыв	Дщыук	user@example.com	f	t	2025-09-12 14:42:23.609754+03
12	pbkdf2_sha256$1000000$3xzzTLaUh8INGCqULuAgIM$Y4wQUWKwmrRF59D9SLo3ILYof1GKTZbB5i8z+mOyQxs=	\N	f	FrontCheck	Loser	Yeap	user@example.com	f	t	2025-09-12 16:11:55.720684+03
14	pbkdf2_sha256$1000000$FuTHs0akImNwopn0RTvPMT$jWzADuxawt0gCPi4HJaf1IoqfBTxbVDyDtHdzMpDWqg=	\N	f	NewUserAfterRework	Михаил	Чистотин	aedgy.master@mail.ru	f	t	2025-09-14 13:24:26.243824+03
15	pbkdf2_sha256$1000000$0GiAh5ctupOTvMfqXEitXD$O3dFd5lyiQq2vGlaHL/tMp8KxNWAAMPVHiorj9RoYwc=	\N	f	NewUserAfterRework2	123	123	aedgy.mastersd@mail.ru	f	t	2025-09-14 13:38:19.122543+03
16	pbkdf2_sha256$1000000$i01xV2zQMiii7c1m77dVYu$ruUXToPGCdY7cQMaR0KaSBXkf7/nH7Knz79Ho4CFK0s=	\N	f	NewUserAfterRework23	123321	123321	aedgy.mastersd123123@mail.ru	f	t	2025-09-14 13:50:13.279934+03
17	pbkdf2_sha256$1000000$XhAhyBXhFwyoUKfl7psXDS$0GmZhtDRCzt3yj3x9bgnDWOE0daKD7RT4bVMxcRkWxQ=	\N	f	NewUserTest	NewUserTest	NewUserTest	user@example.com	f	t	2025-09-14 15:25:16.174865+03
18	pbkdf2_sha256$1000000$9QZJzKkY9fPttRRb53Inwk$7qMtIu194lUb/e4rOzINAmA/1IBLT6SLOAGV4g+d+kM=	\N	f	My	12312312	3123123123	My@mail.ru	f	t	2025-09-14 17:29:40.881177+03
19	pbkdf2_sha256$1000000$ztQrg5Aa4JM4L3FL3u0h18$4KOr6poszlS8Q7qPsRwC5UFklEIxe5Wt/H7bUchtLSI=	\N	f	123123123	укцкуцкуцуцкцук	цукуцуцкуцкцукцук	aedgy.ds@mail.ru	f	t	2025-09-14 19:27:18.679353+03
20	pbkdf2_sha256$1000000$VdbYERirvoqz7JGpSrOXEA$FjgKxiFUfMVTgyh/syCD/BwfDaApdmfUIKDzjE2Pj6U=	\N	f	IaNew123321	werawer2123213	awerawer2	aedgy.master@mail.ru	f	t	2025-09-14 19:49:35.331213+03
21	pbkdf2_sha256$1000000$B1ui9Sg6JePADSRYtI8Rda$yaUwyQOokOsH1v0K12UPJK0E/kP2Oj6FPhQAX/+jIWo=	\N	f	NewUserKsta	123	123	NewUserKsta@mail.ru	f	t	2025-09-14 22:46:30.160396+03
22	pbkdf2_sha256$1000000$nCejtm2a4WpOsgQwcYB61K$XflvFk8LOTCngv2c3MW2JtZAMtwhb8Tzw075kCsEmt4=	\N	f	Loser123	Loser123	Loser123	aedgy.master123@mail.ruuuu	f	t	2025-09-17 10:44:52.213136+03
35	pbkdf2_sha256$1000000$UX6UfGJ9kVYcBI1rM9tfO3$3BF3vMkVTDeHBeN360+9Rhg+z756Ep1EB5bzF0txeFk=	\N	t	1			1@mail.ru	t	t	2025-09-17 13:57:48.143694+03
39	pbkdf2_sha256$1000000$vQEMSI2PNdtw0GmbQFrNCH$4nrkP+MuVFS4mUhKGwofr4gnJSjduXr6ei7sw317h3Q=	\N	f	Seller	Михаил	Чистотин	seller@mail.ru	f	t	2025-09-24 12:03:08.03117+03
24	pbkdf2_sha256$1000000$5eKnMqSVjOeaUgprGKkjyX$632+bQN8/U4UceptJ7oGi6sh28qAQ7c6H6B/dQwFA/I=	\N	f	alice	Alice	Ivanova	alice@example.com	f	t	2025-09-17 11:25:32.544444+03
25	pbkdf2_sha256$1000000$WZ6xryiWQhCjtwNrhS6w00$DaZs1A3uAo+rw7StlAI3YqbsbxOHTCU8JWq/M6tjl1U=	\N	f	bob	Bob	Petrov	bob@example.com	f	t	2025-09-17 11:25:33.209625+03
26	pbkdf2_sha256$1000000$UCRtHOuy0hDHr26rfnFwiA$vlm08l8St8Q7NRQYy+pWkfEwc+RhL6BBAHcK+C/S4+s=	\N	f	carol	Carol	Sidorova	carol@example.com	f	t	2025-09-17 11:25:33.808664+03
27	pbkdf2_sha256$1000000$UGJpUX7NW4pPJ5HhMWEEOu$iNK/nghIyaNQAaJLErdv7m49VCKxm7sH/aUYnnEAUDw=	\N	f	dave	Dave	Smirnov	dave@example.com	f	t	2025-09-17 11:25:34.437713+03
28	pbkdf2_sha256$1000000$GXFfyu3URLYZEjIhcAyzEp$nuC4EsQq4aCrPTdj0GRWb/wUEuz5Tf5Ys6Mzj/2WsLw=	\N	f	erin	Erin	Volkova	erin@example.com	f	t	2025-09-17 11:25:35.049881+03
29	pbkdf2_sha256$1000000$cpKsOY8q1zpq4EeGLCBKzD$74BUyS1zosLCjEtmWIPCRFZo5VcPAYd4sND9gF9cCIs=	\N	f	mike	Mikhail	Orlov	mike@example.com	f	t	2025-09-17 11:25:35.67194+03
30	pbkdf2_sha256$1000000$HmXvyZKCmmKNr3qNs5wNzj$VXlDurZSrjlmqh5o8fyxNIxqrPNyZb4YoAyCfqRHMHM=	\N	f	nina	Nina	Kuznetsova	nina@example.com	f	t	2025-09-17 11:25:36.271102+03
31	pbkdf2_sha256$1000000$cB1FRwVtjafWiYYd8OjC5k$KAlpfPW5bKa4BcFNwZnQAtdT4gDnh/5mUhUp/g7d1J4=	\N	f	oleg	Oleg	Karpov	oleg@example.com	f	t	2025-09-17 11:25:36.870276+03
32	pbkdf2_sha256$1000000$L2vsAzCcgGU2GMfgzNkT2F$kioaBQjeaX5m/OYQEw7giVQ3HI2+nDHlpT3aksCDZSQ=	\N	f	pavel	Pavel	Denisov	pavel@example.com	f	t	2025-09-17 11:25:37.479962+03
33	pbkdf2_sha256$1000000$FXAXyNT1aawPEbCZ9bPDHt$yG+2VRlekWLvBeFHyzdYow4XhDz3w8t7fTrFC8fXuHw=	\N	f	rita	Rita	Sorokina	rita@example.com	f	t	2025-09-17 11:25:38.088494+03
34	pbkdf2_sha256$1000000$VDSSHLpVqgLYyhMeR3zl1N$YLRcV+jeDAtDFInhiAAtaWg7FQsuKnYxjE0j0pVuXxM=	\N	t	321			aedgy.master321@mail.ru	t	t	2025-09-17 11:27:30.440944+03
36	pbkdf2_sha256$1000000$oUA2p68WDR8RMGffadijFH$Z2t3k0TZzgFf3slUZHNs2d4VO3oz8gVZzDjYEYXvgQA=	\N	f	Loser123321	Loser123321	Loser123321	aedgy.master123321@mail.ru	f	t	2025-09-17 13:58:55.39659+03
40	pbkdf2_sha256$1000000$MsSi1glMrbkLrwGqnFxCm7$TPBbmX73bYpV7NTpy+IInCucaTAdg3XcJDqoIAjZbIg=	\N	f	Owner	Михаил	Чистотин	Owner@mail.ru	f	t	2025-09-24 12:03:32.386208+03
37	pbkdf2_sha256$1000000$BsGyLh4pikwTPEa0P3J2VI$aMn75fXpNnzaRDCOmUkgdQGrlGwoZ7ETmAmnTv0puX4=	\N	t	2			2@mail.ru	t	t	2025-09-17 20:34:09.321789+03
23	pbkdf2_sha256$1000000$fWfsddRZJh0jiLIwQArT4m$aKOVvVayjodUsdKehTPCNp1U/Nt8jNJ5/0Bt//B//Uw=	\N	t	admin	Admin	User	admin@example.com	t	t	2025-09-17 11:25:31.725898+03
38	pbkdf2_sha256$1000000$xtdn3ZqSE2BcDZBUaBMEjL$yBhxDaNPgaGLPBHhlj/wUkkU3gsRhQQZVLGFabIZPoE=	\N	f	NewUserKsta123	Михаил	Чистотин	NewUserKsta@mail.ru	f	t	2025-09-22 21:12:48.772733+03
13	pbkdf2_sha256$1000000$zKeOYlkQpxN9uEXDTBMLqk$qW7+kFPI5zuOjHhVC3ewCpJiuuaxqAXGDiCzg0XDSdg=	\N	f	NewUser	Михаил	Чистотин	aedgy.master@mail.ru	f	t	2025-09-12 16:25:31.885224+03
41	pbkdf2_sha256$1000000$j5GwcoKf8wJlqDVAPvvfIA$9vKwzTh+p1iXknHT619GmYdukyCo5hqvDYoABIxF8BY=	\N	f	test_user1	Михаил	Чистотин	aedgy.master@mail.ru	f	t	2025-09-24 21:39:07.326016+03
42	pbkdf2_sha256$1000000$gRuvSMMpeld3d6kDIFKZ4Q$73GOJatyw2XyhyGEG0F4vddFnWFXQm/frKk0jAqf9lQ=	\N	f	test_user	Михаил	Чистотин	aedgy.master@mail.ru	f	t	2025-09-24 21:42:41.743878+03
\.


--
-- Data for Name: core_user_groups; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.core_user_groups (id, user_id, group_id) FROM stdin;
\.


--
-- Data for Name: core_user_user_permissions; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.core_user_user_permissions (id, user_id, permission_id) FROM stdin;
\.


--
-- Data for Name: core_userprofile; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.core_userprofile (id, phone_masked, user_id) FROM stdin;
\.


--
-- Data for Name: core_userrole; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.core_userrole (id, role_id, user_id) FROM stdin;
35	1	23
36	3	24
37	3	25
38	3	26
39	3	27
40	3	28
41	3	29
42	3	30
43	3	31
44	3	32
45	3	33
46	2	24
47	1	34
48	2	22
49	1	35
50	3	36
53	1	37
54	1	1
55	2	21
61	1	38
63	3	39
64	3	40
66	1	6
68	3	41
69	3	42
70	1	3
\.


--
-- Data for Name: core_usersettings; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.core_usersettings (id, theme, date_format, number_format, page_size, saved_filters, created_at, updated_at, user_id) FROM stdin;
\.


--
-- Data for Name: django_admin_log; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_admin_log (id, action_time, object_id, object_repr, action_flag, change_message, content_type_id, user_id) FROM stdin;
\.


--
-- Data for Name: django_content_type; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_content_type (id, app_label, model) FROM stdin;
1	admin	logentry
2	auth	permission
3	auth	group
4	contenttypes	contenttype
5	sessions	session
6	core	make
7	core	role
8	core	user
9	core	auditlog
10	core	car
11	core	carimage
12	core	model
13	core	order
14	core	transaction
15	core	userrole
16	core	review
17	authtoken	token
18	authtoken	tokenproxy
19	core	userprofile
20	core	usersettings
21	core	backupfile
22	core	backupconfig
\.


--
-- Data for Name: django_migrations; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_migrations (id, app, name, applied) FROM stdin;
1	contenttypes	0001_initial	2025-09-12 14:02:03.227321+03
2	contenttypes	0002_remove_content_type_name	2025-09-12 14:02:03.23548+03
3	auth	0001_initial	2025-09-12 14:02:03.291065+03
4	auth	0002_alter_permission_name_max_length	2025-09-12 14:02:03.297728+03
5	auth	0003_alter_user_email_max_length	2025-09-12 14:02:03.302062+03
6	auth	0004_alter_user_username_opts	2025-09-12 14:02:03.30799+03
7	auth	0005_alter_user_last_login_null	2025-09-12 14:02:03.316965+03
8	auth	0006_require_contenttypes_0002	2025-09-12 14:02:03.319092+03
9	auth	0007_alter_validators_add_error_messages	2025-09-12 14:02:03.323031+03
10	auth	0008_alter_user_username_max_length	2025-09-12 14:02:03.329102+03
11	auth	0009_alter_user_last_name_max_length	2025-09-12 14:02:03.334535+03
12	auth	0010_alter_group_name_max_length	2025-09-12 14:02:03.346282+03
13	auth	0011_update_proxy_permissions	2025-09-12 14:02:03.35178+03
14	auth	0012_alter_user_first_name_max_length	2025-09-12 14:02:03.359001+03
15	core	0001_initial	2025-09-12 14:02:03.601899+03
16	admin	0001_initial	2025-09-12 14:02:03.637893+03
17	admin	0002_logentry_remove_auto_add	2025-09-12 14:02:03.65119+03
18	admin	0003_logentry_add_action_flag_choices	2025-09-12 14:02:03.664125+03
19	sessions	0001_initial	2025-09-12 14:02:03.678564+03
20	authtoken	0001_initial	2025-09-12 16:01:48.920124+03
21	authtoken	0002_auto_20160226_1747	2025-09-12 16:01:48.955314+03
22	authtoken	0003_tokenproxy	2025-09-12 16:01:48.957709+03
23	authtoken	0004_alter_tokenproxy_options	2025-09-12 16:01:48.963908+03
24	core	0002_alter_auditlog_options_alter_auditlog_action_time_and_more	2025-09-14 17:00:38.273652+03
25	core	0003_auditlog_actor_label	2025-09-14 17:34:07.001011+03
26	core	0004_alter_model_name_model_uniq_model_per_make	2025-09-14 20:35:23.293051+03
27	core	0005_alter_auditlog_record_id	2025-09-14 20:37:38.125439+03
28	core	0006_userprofile	2025-09-17 14:42:32.401107+03
29	core	0007_constraints	2025-09-17 14:52:43.729696+03
30	core	0008_views	2025-09-17 14:52:43.754922+03
31	core	0009_procs_triggers	2025-09-17 14:55:11.605032+03
32	core	0010_remove_car_car_price_gt_zero_and_more	2025-09-17 14:55:11.637257+03
37	core	0011_fix_views	2025-09-24 11:52:29.305768+03
38	core	0012_add_car_checks	2025-09-24 11:52:29.335888+03
39	core	0013_sp_cancel_reservation	2025-09-24 11:52:29.341317+03
40	core	0014_remove_car_car_price_gt_zero_v2_and_more	2025-09-24 11:52:29.370882+03
41	core	0015_usersettings	2025-09-24 13:00:26.687728+03
42	core	0016_merge_20250924_1300	2025-09-24 13:00:26.690661+03
43	core	0017_usersettings	2025-09-24 13:00:26.748413+03
44	core	0018_backupfile	2025-09-24 15:23:57.111715+03
45	core	0019_backupconfig	2025-09-24 16:11:54.986091+03
46	core	0020_backupconfig_last_run_at	2025-09-24 16:20:26.85476+03
47	core	0021_alter_backupconfig_last_run_at	2025-09-24 19:28:24.975057+03
48	core	0022_remove_backupconfig_cron_and_more	2025-09-24 19:43:53.335252+03
\.


--
-- Data for Name: django_session; Type: TABLE DATA; Schema: public; Owner: -
--

COPY public.django_session (session_key, session_data, expire_date) FROM stdin;
\.


--
-- Name: auth_group_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_group_id_seq', 1, false);


--
-- Name: auth_group_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_group_permissions_id_seq', 1, false);


--
-- Name: auth_permission_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.auth_permission_id_seq', 88, true);


--
-- Name: core_auditlog_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.core_auditlog_id_seq', 611, true);


--
-- Name: core_backupfile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.core_backupfile_id_seq', 4, true);


--
-- Name: core_carimage_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.core_carimage_id_seq', 39, true);


--
-- Name: core_make_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.core_make_id_seq', 12, true);


--
-- Name: core_model_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.core_model_id_seq', 26, true);


--
-- Name: core_order_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.core_order_id_seq', 44, true);


--
-- Name: core_review_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.core_review_id_seq', 12, true);


--
-- Name: core_role_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.core_role_id_seq', 4, true);


--
-- Name: core_transaction_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.core_transaction_id_seq', 16, true);


--
-- Name: core_user_groups_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.core_user_groups_id_seq', 1, false);


--
-- Name: core_user_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.core_user_id_seq', 42, true);


--
-- Name: core_user_user_permissions_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.core_user_user_permissions_id_seq', 1, false);


--
-- Name: core_userprofile_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.core_userprofile_id_seq', 1, false);


--
-- Name: core_userrole_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.core_userrole_id_seq', 70, true);


--
-- Name: core_usersettings_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.core_usersettings_id_seq', 1, false);


--
-- Name: django_admin_log_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.django_admin_log_id_seq', 1, false);


--
-- Name: django_content_type_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.django_content_type_id_seq', 22, true);


--
-- Name: django_migrations_id_seq; Type: SEQUENCE SET; Schema: public; Owner: -
--

SELECT pg_catalog.setval('public.django_migrations_id_seq', 48, true);


--
-- Name: auth_group auth_group_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_name_key UNIQUE (name);


--
-- Name: auth_group_permissions auth_group_permissions_group_id_permission_id_0cd325b0_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_permission_id_0cd325b0_uniq UNIQUE (group_id, permission_id);


--
-- Name: auth_group_permissions auth_group_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_pkey PRIMARY KEY (id);


--
-- Name: auth_group auth_group_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group
    ADD CONSTRAINT auth_group_pkey PRIMARY KEY (id);


--
-- Name: auth_permission auth_permission_content_type_id_codename_01ab375a_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_codename_01ab375a_uniq UNIQUE (content_type_id, codename);


--
-- Name: auth_permission auth_permission_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_pkey PRIMARY KEY (id);


--
-- Name: authtoken_token authtoken_token_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_pkey PRIMARY KEY (key);


--
-- Name: authtoken_token authtoken_token_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_key UNIQUE (user_id);


--
-- Name: core_auditlog core_auditlog_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_auditlog
    ADD CONSTRAINT core_auditlog_pkey PRIMARY KEY (id);


--
-- Name: core_backupconfig core_backupconfig_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_backupconfig
    ADD CONSTRAINT core_backupconfig_pkey PRIMARY KEY (id);


--
-- Name: core_backupfile core_backupfile_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_backupfile
    ADD CONSTRAINT core_backupfile_pkey PRIMARY KEY (id);


--
-- Name: core_car core_car_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_car
    ADD CONSTRAINT core_car_pkey PRIMARY KEY ("VIN");


--
-- Name: core_carimage core_carimage_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_carimage
    ADD CONSTRAINT core_carimage_pkey PRIMARY KEY (id);


--
-- Name: core_make core_make_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_make
    ADD CONSTRAINT core_make_name_key UNIQUE (name);


--
-- Name: core_make core_make_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_make
    ADD CONSTRAINT core_make_pkey PRIMARY KEY (id);


--
-- Name: core_model core_model_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_model
    ADD CONSTRAINT core_model_pkey PRIMARY KEY (id);


--
-- Name: core_order core_order_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_order
    ADD CONSTRAINT core_order_pkey PRIMARY KEY (id);


--
-- Name: core_review core_review_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_review
    ADD CONSTRAINT core_review_pkey PRIMARY KEY (id);


--
-- Name: core_role core_role_name_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_role
    ADD CONSTRAINT core_role_name_key UNIQUE (name);


--
-- Name: core_role core_role_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_role
    ADD CONSTRAINT core_role_pkey PRIMARY KEY (id);


--
-- Name: core_transaction core_transaction_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_transaction
    ADD CONSTRAINT core_transaction_pkey PRIMARY KEY (id);


--
-- Name: core_user_groups core_user_groups_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_user_groups
    ADD CONSTRAINT core_user_groups_pkey PRIMARY KEY (id);


--
-- Name: core_user_groups core_user_groups_user_id_group_id_c82fcad1_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_user_groups
    ADD CONSTRAINT core_user_groups_user_id_group_id_c82fcad1_uniq UNIQUE (user_id, group_id);


--
-- Name: core_user core_user_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_user
    ADD CONSTRAINT core_user_pkey PRIMARY KEY (id);


--
-- Name: core_user_user_permissions core_user_user_permissions_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_user_user_permissions
    ADD CONSTRAINT core_user_user_permissions_pkey PRIMARY KEY (id);


--
-- Name: core_user_user_permissions core_user_user_permissions_user_id_permission_id_73ea0daa_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_user_user_permissions
    ADD CONSTRAINT core_user_user_permissions_user_id_permission_id_73ea0daa_uniq UNIQUE (user_id, permission_id);


--
-- Name: core_user core_user_username_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_user
    ADD CONSTRAINT core_user_username_key UNIQUE (username);


--
-- Name: core_userprofile core_userprofile_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_userprofile
    ADD CONSTRAINT core_userprofile_pkey PRIMARY KEY (id);


--
-- Name: core_userprofile core_userprofile_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_userprofile
    ADD CONSTRAINT core_userprofile_user_id_key UNIQUE (user_id);


--
-- Name: core_userrole core_userrole_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_userrole
    ADD CONSTRAINT core_userrole_pkey PRIMARY KEY (id);


--
-- Name: core_usersettings core_usersettings_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_usersettings
    ADD CONSTRAINT core_usersettings_pkey PRIMARY KEY (id);


--
-- Name: core_usersettings core_usersettings_user_id_key; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_usersettings
    ADD CONSTRAINT core_usersettings_user_id_key UNIQUE (user_id);


--
-- Name: django_admin_log django_admin_log_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_pkey PRIMARY KEY (id);


--
-- Name: django_content_type django_content_type_app_label_model_76bd3d3b_uniq; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_app_label_model_76bd3d3b_uniq UNIQUE (app_label, model);


--
-- Name: django_content_type django_content_type_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_content_type
    ADD CONSTRAINT django_content_type_pkey PRIMARY KEY (id);


--
-- Name: django_migrations django_migrations_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_migrations
    ADD CONSTRAINT django_migrations_pkey PRIMARY KEY (id);


--
-- Name: django_session django_session_pkey; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_session
    ADD CONSTRAINT django_session_pkey PRIMARY KEY (session_key);


--
-- Name: core_model uniq_model_per_make; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_model
    ADD CONSTRAINT uniq_model_per_make UNIQUE (make_id, name);


--
-- Name: core_review unique_review_per_user; Type: CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_review
    ADD CONSTRAINT unique_review_per_user UNIQUE (author_id, target_id);


--
-- Name: auth_group_name_a6ea08ec_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_group_name_a6ea08ec_like ON public.auth_group USING btree (name varchar_pattern_ops);


--
-- Name: auth_group_permissions_group_id_b120cbf9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_group_permissions_group_id_b120cbf9 ON public.auth_group_permissions USING btree (group_id);


--
-- Name: auth_group_permissions_permission_id_84c5c92e; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_group_permissions_permission_id_84c5c92e ON public.auth_group_permissions USING btree (permission_id);


--
-- Name: auth_permission_content_type_id_2f476e4b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX auth_permission_content_type_id_2f476e4b ON public.auth_permission USING btree (content_type_id);


--
-- Name: authtoken_token_key_10f0b77e_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX authtoken_token_key_10f0b77e_like ON public.authtoken_token USING btree (key varchar_pattern_ops);


--
-- Name: core_auditl_action__d5c966_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_auditl_action__d5c966_idx ON public.core_auditlog USING btree (action_time DESC);


--
-- Name: core_auditl_action_d9fb24_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_auditl_action_d9fb24_idx ON public.core_auditlog USING btree (action);


--
-- Name: core_auditl_table_n_4a8950_idx; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_auditl_table_n_4a8950_idx ON public.core_auditlog USING btree (table_name);


--
-- Name: core_auditlog_action_time_f504adae; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_auditlog_action_time_f504adae ON public.core_auditlog USING btree (action_time);


--
-- Name: core_auditlog_record_id_56d91507; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_auditlog_record_id_56d91507 ON public.core_auditlog USING btree (record_id);


--
-- Name: core_auditlog_record_id_56d91507_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_auditlog_record_id_56d91507_like ON public.core_auditlog USING btree (record_id varchar_pattern_ops);


--
-- Name: core_auditlog_user_id_3797aaab; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_auditlog_user_id_3797aaab ON public.core_auditlog USING btree (user_id);


--
-- Name: core_backupfile_created_by_id_17b1fe59; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_backupfile_created_by_id_17b1fe59 ON public.core_backupfile USING btree (created_by_id);


--
-- Name: core_car_VIN_59031950_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX "core_car_VIN_59031950_like" ON public.core_car USING btree ("VIN" varchar_pattern_ops);


--
-- Name: core_car_make_id_dad62edd; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_car_make_id_dad62edd ON public.core_car USING btree (make_id);


--
-- Name: core_car_model_id_ab210b11; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_car_model_id_ab210b11 ON public.core_car USING btree (model_id);


--
-- Name: core_car_seller_id_f28e3cc5; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_car_seller_id_f28e3cc5 ON public.core_car USING btree (seller_id);


--
-- Name: core_carimage_car_id_980997b9; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_carimage_car_id_980997b9 ON public.core_carimage USING btree (car_id);


--
-- Name: core_carimage_car_id_980997b9_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_carimage_car_id_980997b9_like ON public.core_carimage USING btree (car_id varchar_pattern_ops);


--
-- Name: core_make_name_07f7e019_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_make_name_07f7e019_like ON public.core_make USING btree (name varchar_pattern_ops);


--
-- Name: core_model_make_id_dafc45de; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_model_make_id_dafc45de ON public.core_model USING btree (make_id);


--
-- Name: core_order_buyer_id_75e0ab1b; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_order_buyer_id_75e0ab1b ON public.core_order USING btree (buyer_id);


--
-- Name: core_order_car_id_5e0a257c; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_order_car_id_5e0a257c ON public.core_order USING btree (car_id);


--
-- Name: core_order_car_id_5e0a257c_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_order_car_id_5e0a257c_like ON public.core_order USING btree (car_id varchar_pattern_ops);


--
-- Name: core_review_author_id_b9ff1c35; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_review_author_id_b9ff1c35 ON public.core_review USING btree (author_id);


--
-- Name: core_review_target_id_f0d3fb81; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_review_target_id_f0d3fb81 ON public.core_review USING btree (target_id);


--
-- Name: core_role_name_ca4cd9c7_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_role_name_ca4cd9c7_like ON public.core_role USING btree (name varchar_pattern_ops);


--
-- Name: core_transaction_order_id_e41a6bc5; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_transaction_order_id_e41a6bc5 ON public.core_transaction USING btree (order_id);


--
-- Name: core_user_groups_group_id_fe8c697f; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_user_groups_group_id_fe8c697f ON public.core_user_groups USING btree (group_id);


--
-- Name: core_user_groups_user_id_70b4d9b8; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_user_groups_user_id_70b4d9b8 ON public.core_user_groups USING btree (user_id);


--
-- Name: core_user_user_permissions_permission_id_35ccf601; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_user_user_permissions_permission_id_35ccf601 ON public.core_user_user_permissions USING btree (permission_id);


--
-- Name: core_user_user_permissions_user_id_085123d3; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_user_user_permissions_user_id_085123d3 ON public.core_user_user_permissions USING btree (user_id);


--
-- Name: core_user_username_36e4f7f7_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_user_username_36e4f7f7_like ON public.core_user USING btree (username varchar_pattern_ops);


--
-- Name: core_userrole_role_id_8272b20d; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_userrole_role_id_8272b20d ON public.core_userrole USING btree (role_id);


--
-- Name: core_userrole_user_id_aca63c51; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX core_userrole_user_id_aca63c51 ON public.core_userrole USING btree (user_id);


--
-- Name: django_admin_log_content_type_id_c4bce8eb; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_admin_log_content_type_id_c4bce8eb ON public.django_admin_log USING btree (content_type_id);


--
-- Name: django_admin_log_user_id_c564eba6; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_admin_log_user_id_c564eba6 ON public.django_admin_log USING btree (user_id);


--
-- Name: django_session_expire_date_a5c62663; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_session_expire_date_a5c62663 ON public.django_session USING btree (expire_date);


--
-- Name: django_session_session_key_c0390e0f_like; Type: INDEX; Schema: public; Owner: -
--

CREATE INDEX django_session_session_key_c0390e0f_like ON public.django_session USING btree (session_key varchar_pattern_ops);


--
-- Name: core_car audit_cars; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_cars AFTER INSERT OR DELETE OR UPDATE ON public.core_car FOR EACH ROW EXECUTE FUNCTION public.audit_row();


--
-- Name: core_order audit_orders; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_orders AFTER INSERT OR DELETE OR UPDATE ON public.core_order FOR EACH ROW EXECUTE FUNCTION public.audit_row();


--
-- Name: core_transaction audit_tx; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER audit_tx AFTER INSERT OR DELETE OR UPDATE ON public.core_transaction FOR EACH ROW EXECUTE FUNCTION public.audit_row();


--
-- Name: core_transaction validate_tx; Type: TRIGGER; Schema: public; Owner: -
--

CREATE TRIGGER validate_tx BEFORE INSERT ON public.core_transaction FOR EACH ROW EXECUTE FUNCTION public.trg_validate_tx();


--
-- Name: auth_group_permissions auth_group_permissio_permission_id_84c5c92e_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissio_permission_id_84c5c92e_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_group_permissions auth_group_permissions_group_id_b120cbf9_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_group_permissions
    ADD CONSTRAINT auth_group_permissions_group_id_b120cbf9_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: auth_permission auth_permission_content_type_id_2f476e4b_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.auth_permission
    ADD CONSTRAINT auth_permission_content_type_id_2f476e4b_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: authtoken_token authtoken_token_user_id_35299eff_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.authtoken_token
    ADD CONSTRAINT authtoken_token_user_id_35299eff_fk_core_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_auditlog core_auditlog_user_id_3797aaab_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_auditlog
    ADD CONSTRAINT core_auditlog_user_id_3797aaab_fk_core_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_backupfile core_backupfile_created_by_id_17b1fe59_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_backupfile
    ADD CONSTRAINT core_backupfile_created_by_id_17b1fe59_fk_core_user_id FOREIGN KEY (created_by_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_car core_car_make_id_dad62edd_fk_core_make_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_car
    ADD CONSTRAINT core_car_make_id_dad62edd_fk_core_make_id FOREIGN KEY (make_id) REFERENCES public.core_make(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_car core_car_model_id_ab210b11_fk_core_model_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_car
    ADD CONSTRAINT core_car_model_id_ab210b11_fk_core_model_id FOREIGN KEY (model_id) REFERENCES public.core_model(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_car core_car_seller_id_f28e3cc5_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_car
    ADD CONSTRAINT core_car_seller_id_f28e3cc5_fk_core_user_id FOREIGN KEY (seller_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_carimage core_carimage_car_id_980997b9_fk_core_car_VIN; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_carimage
    ADD CONSTRAINT "core_carimage_car_id_980997b9_fk_core_car_VIN" FOREIGN KEY (car_id) REFERENCES public.core_car("VIN") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_model core_model_make_id_dafc45de_fk_core_make_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_model
    ADD CONSTRAINT core_model_make_id_dafc45de_fk_core_make_id FOREIGN KEY (make_id) REFERENCES public.core_make(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_order core_order_buyer_id_75e0ab1b_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_order
    ADD CONSTRAINT core_order_buyer_id_75e0ab1b_fk_core_user_id FOREIGN KEY (buyer_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_order core_order_car_id_5e0a257c_fk_core_car_VIN; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_order
    ADD CONSTRAINT "core_order_car_id_5e0a257c_fk_core_car_VIN" FOREIGN KEY (car_id) REFERENCES public.core_car("VIN") DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_review core_review_author_id_b9ff1c35_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_review
    ADD CONSTRAINT core_review_author_id_b9ff1c35_fk_core_user_id FOREIGN KEY (author_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_review core_review_target_id_f0d3fb81_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_review
    ADD CONSTRAINT core_review_target_id_f0d3fb81_fk_core_user_id FOREIGN KEY (target_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_transaction core_transaction_order_id_e41a6bc5_fk_core_order_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_transaction
    ADD CONSTRAINT core_transaction_order_id_e41a6bc5_fk_core_order_id FOREIGN KEY (order_id) REFERENCES public.core_order(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_user_groups core_user_groups_group_id_fe8c697f_fk_auth_group_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_user_groups
    ADD CONSTRAINT core_user_groups_group_id_fe8c697f_fk_auth_group_id FOREIGN KEY (group_id) REFERENCES public.auth_group(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_user_groups core_user_groups_user_id_70b4d9b8_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_user_groups
    ADD CONSTRAINT core_user_groups_user_id_70b4d9b8_fk_core_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_user_user_permissions core_user_user_permi_permission_id_35ccf601_fk_auth_perm; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_user_user_permissions
    ADD CONSTRAINT core_user_user_permi_permission_id_35ccf601_fk_auth_perm FOREIGN KEY (permission_id) REFERENCES public.auth_permission(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_user_user_permissions core_user_user_permissions_user_id_085123d3_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_user_user_permissions
    ADD CONSTRAINT core_user_user_permissions_user_id_085123d3_fk_core_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_userprofile core_userprofile_user_id_5141ad90_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_userprofile
    ADD CONSTRAINT core_userprofile_user_id_5141ad90_fk_core_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_userrole core_userrole_role_id_8272b20d_fk_core_role_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_userrole
    ADD CONSTRAINT core_userrole_role_id_8272b20d_fk_core_role_id FOREIGN KEY (role_id) REFERENCES public.core_role(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_userrole core_userrole_user_id_aca63c51_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_userrole
    ADD CONSTRAINT core_userrole_user_id_aca63c51_fk_core_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: core_usersettings core_usersettings_user_id_116dd0d3_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.core_usersettings
    ADD CONSTRAINT core_usersettings_user_id_116dd0d3_fk_core_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_content_type_id_c4bce8eb_fk_django_co; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_content_type_id_c4bce8eb_fk_django_co FOREIGN KEY (content_type_id) REFERENCES public.django_content_type(id) DEFERRABLE INITIALLY DEFERRED;


--
-- Name: django_admin_log django_admin_log_user_id_c564eba6_fk_core_user_id; Type: FK CONSTRAINT; Schema: public; Owner: -
--

ALTER TABLE ONLY public.django_admin_log
    ADD CONSTRAINT django_admin_log_user_id_c564eba6_fk_core_user_id FOREIGN KEY (user_id) REFERENCES public.core_user(id) DEFERRABLE INITIALLY DEFERRED;


--
-- PostgreSQL database dump complete
--

